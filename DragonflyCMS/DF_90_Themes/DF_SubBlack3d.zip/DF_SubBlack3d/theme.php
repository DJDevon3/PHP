<?php
/*********************************************
  CPG Dragonfly™ CMS
  ********************************************
  Copyright © 2004 - 2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version

  $Source: /cvs/html/themes/cpgnuke/theme.php,v $
  $Revision: 9.4 $
  $Author: djmaze $
  $Date: 2005/04/01 02:27:32 $
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

$gfxcolor = '#C0C000';
$bgcolor1 = "4A4A4A";
$bgcolor2 = "383838";
$bgcolor3 = "383838";
$bgcolor4 = "4A4A4A";
$textcolor1 = "#FFCC00";
$textcolor2 = "#FFCC00";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function OpenTable() {
    echo '<table width="100%" border="0" cellspacing="0" cellpadding="7"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="1"><tr><td bgcolor="#141414"><table width="100%" border="0" cellspacing="1" cellpadding="1"><tr><td bgcolor="#333333"><table width="100%" border="0" cellspacing="0" cellpadding="1"><tr><td bgcolor="#4A4A4A"><table width="100%" border="0" cellspacing="0" cellpadding="4"><tr><td>';
}

function CloseTable() {
    echo "</td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table>";
}

function OpenTable2() {
    echo '<table width="100%" border="10" cellspacing="0" cellpadding="7"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="1"><tr><td bgcolor="#141414"><table width="100%" border="0" cellspacing="1" cellpadding="1"><tr><td bgcolor="#333333"><table width="100%" border="0" cellspacing="0" cellpadding="1"><tr><td bgcolor="#4A4A4A"><table width="100%" border="0" cellspacing="0" cellpadding="4"><tr><td>';
}

function CloseTable2() {
    echo "</td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table>";
}

function themeheader() {
	global $slogan, $sitename, $banners, $mainindex, $adminindex, $cpgtpl, $site_logo, $userinfo, $db, $prefix;
	$sql = "SELECT msg1, link1, link2, link3, link4, link5, link1url, link2url, link3url, link4url, link5url, flash FROM ".$prefix."_themecp";
	$result = $db->sql_query($sql);
	list($msg1, $link1, $link2, $link3, $link4, $link5, $link1url, $link2url, $link3url, $link4url, $link5url, $flash) = $db->sql_fetchrow($result);
	$imgr = $imgl = '';
	// left blocks ?
	if (blocks_visible('l')) {
		$img = hideblock('600') ? 'plus.gif' : 'minus.gif';
		$imgl = '<img align="left" alt="&#8226;" title="Toggle Content" id="pic600" src="themes/DF_SubBlack3d/images/'.$img.'" onclick="blockswitch(\'600\');" style="cursor:pointer" />';
	}
	// right blocks ?
	if (blocks_visible('r')) {
		$img = hideblock('601') ? 'plus.gif' : 'minus.gif';
		$imgr = '<img align="right" alt="&#8226;" title="Toggle Content" id="pic601" src="themes/DF_SubBlack3d/images/'.$img.'" onclick="blockswitch(\'601\');" style="cursor:pointer" />';
	}
	     $login = '<form action="index.php?name=Your_Account" method="post"><a href="index.php?name=Your_Account&file=register">Register</a> or Login:<input class="user" type="text" name="username" value="username" value style="width:100;height:18;">&nbsp;&nbsp;<input type="password" class="user" name="user_password" value="password" value style="width:100;height:18;">&nbsp;&nbsp;<input type="submit" class="noborder" border="0" value="login">&nbsp;&nbsp;</form>';

//THE FLASH DIMENSIONS YOU WILL NEED TO MODIFY YOURSELF IF YOU WANT TO ADD FLASH TO THIS THEME
//ONLY SUPPORT FOR THE THEMECP FLASH IS ADDED
//IT'S UP TO YOU TO INPUT THE CORRECT DIMENSIONS
if ($flash == 1) {
    $flash = '<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="481" HEIGHT="161" id="logo" ALIGN=""><PARAM NAME=movie VALUE="themes/DF_SubBlack3d/images/logo.swf"><PARAM NAME="menu" VALUE="false"> <PARAM NAME="quality" VALUE="best"> <PARAM NAME="wmode" VALUE="transparent"><PARAM NAME="bgcolor" VALUE="#AEBFCC"><EMBED src="themes/DF_subBlack3d/images/logo.swf" menu="false" quality="best" wmode="transparent" bgcolor="#AEBFCC" WIDTH="481" HEIGHT="161" NAME="logo" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT>';
	} else {
	$flash = '<img src="themes/DF_subBlack3d/images/nonflash.jpg" width="481" height="161" alt="logo" />';
	}

	$date = ''.date('F j, Y, g:i a');
	$cpgtpl->assign_vars(array(
		'CSS_FILE'     => ereg('MSIE', $_SERVER['HTTP_USER_AGENT']) ? 'ie' : 'style',
		'PUBLIC_HEADER' => !defined('ADMIN_PAGES'),
		'B_L_VISIBLE'  => hideblock('600') ? 'style="display: none"' : '',
		'B_L_HIDDEN'   => hideblock('600') ? '' : 'style="display: none"',
		'G_LEFTIMAGE'  => $imgl,
		'G_RIGHTIMAGE' => $imgr,
		'S_IS_ADMIN'   => is_admin(),
		'S_CAN_ADMIN'  => can_admin(),
		'S_IS_USER'    => is_user(),
		'S_LOGO'       => $site_logo,
		'S_SITENAME'   => $sitename,
		'S_HOME'       => _HOME,
		'S_DOWNLOADS'  => is_active('Downloads') ? _DownloadsLANG : false,
		'S_FORUMS'     => _ForumsLANG,
		'S_MY_ACCOUNT' => is_user() ? _Your_AccountLANG : _BREG,
		'S_ADMIN'      => _ADMINISTRATION,
		'S_BANNER'     => ($banners) ? viewbanner() : '',
		'U_MAININDEX'  => $mainindex,
		'U_DOWNLOADS'  => getlink('Downloads'),
		'U_FORUMS'     => getlink('Forums'),
		'U_MY_ACCOUNT' => getlink(is_user() ? 'Your_Account' : 'Your_Account&amp;file=register'),
		'U_ADMININDEX' => $adminindex,
		'U_WELCOME'		=> is_user() ? 'Welcome '.$userinfo['username'] : 'Please Register or Login',
        'S_DATE'		=> $date,
		'TCP_MSG1'		=> $msg1,
		'TCP_LINK1'		=> $link1,
		'TCP_LINK2'		=> $link2,
		'TCP_LINK3'		=> $link3,
		'TCP_LINK4'		=> $link4,
		'TCP_LINK5'		=> $link5,
		'TCP_LINK1URL'	=> $link1url,
		'TCP_LINK2URL'	=> $link2url,
		'TCP_LINK3URL'	=> $link3url,
		'TCP_LINK4URL'	=> $link4url,
		'TCP_LINK5URL'	=> $link5url,
		'TCP_FLASH'		=> $flash,
		'TCP_LOGIN'		=> $login,
	));
	blocks('left');
}

function themefooter() {
	global $showblocks, $banners, $cpgtpl, $foot1, $foot2, $foot3, $copyright, $start_time, $db;
	blocks('right');
	$cpgtpl->assign_vars(array(
		'B_R_VISIBLE'   => hideblock('601') ? 'style="display: none"' : '',
		'B_R_HIDDEN'    => hideblock('601') ? '' : 'style="display: none"',
		'S_FOOTER'      => footmsg()
	));
	$cpgtpl->set_filenames(array('footer' => 'footer.html'));
	$cpgtpl->display('footer');
}

/***********************************************************************************

 void themesidebox

 Output the specific block to left or right
	$title	: the title of the block
	$content: all formatted content for the block
	$bid	: the database record ID of the block

************************************************************************************/
function themesidebox($title, $content, $bid=0) {
	global $cpgtpl, $themeblockside;
	$cpgtpl->assign_block_vars($themeblockside.'block', array(
		'S_TITLE'   => $title,
		'S_CONTENT' => $content,
		'S_BID'     => $bid,
		'S_VISIBLE' => hideblock($bid) ? 'style="display:none"' : '',
		'S_HIDDEN'  => hideblock($bid) ? '' : 'style="display:none"',
		'S_IMAGE'   => 'themes/DF_SubBlack3d/images/'.(hideblock($bid) ? 'plus.gif' : 'minus.gif')
	));
	if ($themeblockside == '') {
		$cpgtpl->set_filenames(array('block' => 'block.html'));
		$cpgtpl->display('block');
	}
}
/***********************************************************************************

 string theme_open_form

 Creates start tag for form
	$get_link : link for action default blank
	$form_name : useful for styling and nbbcode
	$legend: optional string value is used in form lagend tag
	$border: optional use 1 to not show border on fieldset from stylesheet
************************************************************************************/
function theme_open_form($link, $form_name=false, $legend=false,$tborder=false) {
	$leg = $legend ? "<legend>$legend</legend>" : '';
	$bord = $tborder ? $tborder : '';
	$form_name	= $form_name ? ' name="'.$form_name.'" id="'.$form_name.'"' :'';
	return '<fieldset '.$bord.'>'.$leg.'<form method="post" action="'.$link.'"'.$form_name.' enctype="multipart/form-data" accept-charset="utf-8">';
}
function theme_close_form() {
	return '</form></fieldset>';
}
/***********************************************************************************

 string theme_yesno_option

 Creates 2 radio buttons with a Yes and No option
	$name : name for the <input>
	$value: current value, 1 = yes, 0 = no

************************************************************************************/
function theme_yesno_option($name, $value=0) {
	$sel[(!$value)] = '';
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	$select .= '<option value="1"'.$sel[1].">"._YES."</option>\n";
	$select .= '<option value="0"'.$sel[0].">"._NO."</option>\n";
	return $select.'</select>';
	//$sel[intval($value)] = ' checked="checked"';
	//return '<input type="radio" name="'.$name.'" value="1"'.$sel[1].' title="'._YES.'" />
	//<label class="yes" for="'.$name.'">'._YES.'</label>
	//<input type="radio" name="'.$name.'" value="0" '.$sel[0].' title="'._NO.'" />
	//<label class="no" for="'.$name.'">'._NO.'</label> ';
}
/***********************************************************************************

 string theme_select_option

 Creates a selection dropdown box of all given variables in the array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1","value2")

************************************************************************************/
function theme_select_option($name, $value, $array) {
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $var) {
		$select .= '<option'.(isset($sel[$var])?$sel[$var]:'').">$var</option>\n";
	}
	return $select.'</select>';
}
/***********************************************************************************

 string theme_select_box

 Creates a selection dropdown box of all given variables in the multi array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1 => title1","value2 => title2")

************************************************************************************/
function theme_select_box($name, $value, $array) {
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $val => $title) {
		$select .= "<option value=\"$val\"".(($val==$value) ? ' selected="selected"' : '').">$title</option>\n";
	}
	return $select.'</select>';
}
