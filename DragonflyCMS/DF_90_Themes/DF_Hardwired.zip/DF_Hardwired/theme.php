<?php
/*********************************************
  CPG Dragonfly� CMS
  ********************************************
  Copyright � 2004 - 2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

$lnkcolor = "#D8E8FF";
$bgcolor1 = "#687483";
$bgcolor2 = "#4F5B6A";
$bgcolor3 = "#4F5B6A";
$bgcolor4 = "#405C82";
$textcolor1 = "#000000";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function OpenTable() {
	echo "<table width=\"100%\" class=\"opentable1\" cellspacing=\"1\" cellpadding=\"5\"><tr><td>";
}

function CloseTable() {
	echo "</td></tr></table><br />";
}

function OpenTable2() {
	echo "<table width=\"100%\" class=\"opentable2\" cellspacing=\"0\" cellpadding=\"5\"><tr><td>";
}

function CloseTable2() {
	echo "</td></tr></table><br />";
}

function themeheader() {
	global $slogan, $sitename, $banners, $mainindex, $adminindex, $cpgtpl, $site_logo, $db, $prefix, $userinfo;
		$sql = "SELECT msg1, msg2, msg3, link1, link2, link3, link4, link5, link6, link7, link8, link9, link10, link1url, link2url, link3url, link4url, link5url, link6url, link7url, link8url, link9url, link10url, searchbox, flash FROM ".$prefix."_themecp";
	$result = $db->sql_query($sql);
	list($msg1, $msg2, $msg3, $link1, $link2, $link3, $link4, $link5, $link6, $link7, $link8, $link9, $link10, $link1url, $link2url, $link3url, $link4url, $link5url, $link6url, $link7url, $link8url, $link9url, $link10url, $searchbox, $flash) = $db->sql_fetchrow($result);
	$imgr = $imgl = '';
	// left blocks ?
	if (blocks_visible('l')) {
		$img = hideblock('600') ? 'plus.gif' : 'minus.gif';
		$imgl = '<img align="left" alt="Toggle Content" title="Toggle Content" id="pic600" src="themes/DF_Hardwired/images/'.$img.'" onclick="blockswitch(\'600\');" style="cursor:pointer" />';
	}
	// right blocks ?
	if (blocks_visible('r')) {
		$img = hideblock('601') ? 'plus.gif' : 'minus.gif';
		$imgr = '<img align="right" alt="Toggle Content" title="Toggle Content" id="pic601" src="themes/DF_Hardwired/images/'.$img.'" onclick="blockswitch(\'601\');" style="cursor:pointer" />';
	}
	$date = ''.date('l, g:i a');
	$cpgtpl->assign_vars(array(
		'CSS_FILE'     => ereg('MSIE', $_SERVER['HTTP_USER_AGENT']) ? 'ie' : 'style',
		'PUBLIC_HEADER' => !defined('ADMIN_PAGES'),
		'B_L_VISIBLE'  => hideblock('600') ? 'style="display: none"' : '',
		'B_L_HIDDEN'   => hideblock('600') ? '' : 'style="display: none"',
		'G_LEFTIMAGE'  => $imgl,
		'G_RIGHTIMAGE' => $imgr,
		'S_IS_ADMIN'   => is_admin(),
		'S_CAN_ADMIN'  => can_admin(),
		'S_IS_USER'    => is_user(),
		'S_LOGO'       => $site_logo,
		'S_SITENAME'   => $sitename,
		'S_HOME'       => _HOME,
		'S_DOWNLOADS'  => is_active('Downloads') ? _DownloadsLANG : false,
		'S_FORUMS'     => _ForumsLANG,
		'S_MY_ACCOUNT' => is_user() ? _Your_AccountLANG : _BREG,
		'S_ADMIN'      => _ADMINISTRATION,
		'S_BANNER'     => ($banners) ? viewbanner() : '',
		'U_MAININDEX'  => $mainindex,
		'U_DOWNLOADS'  => getlink('Downloads'),
		'U_FORUMS'     => getlink('Forums'),
		'U_MY_ACCOUNT' => getlink(is_user() ? 'Your_Account' : 'Your_Account&amp;file=register'),
		'U_ADMININDEX' => $adminindex,
		'U_WELCOME'		=> is_user() ? 'Welcome '.$userinfo['username'] : '',
        'S_NOWTIME'		=> $date,
		'T_MSG1'		=> $msg1,
		'T_MSG2'		=> $msg2,
		'T_MSG3'		=> $msg3,
		'T_LINK1'		=> $link1,
		'T_LINK2'		=> $link2,
		'T_LINK3'		=> $link3,
		'T_LINK4'		=> $link4,
		'T_LINK5'		=> $link5,
		'T_LINK6'		=> $link6,
		'T_LINK7'		=> $link7,
		'T_LINK8'		=> $link8,
		'T_LINK9'		=> $link9,
		'T_LINK10'		=> $link10,
		'T_LINK1URL'	=> $link1url,
		'T_LINK2URL'	=> $link2url,
		'T_LINK3URL'	=> $link3url,
		'T_LINK4URL'	=> $link4url,
		'T_LINK5URL'	=> $link5url,
		'T_LINK6URL'	=> $link6url,
		'T_LINK7URL'	=> $link7url,
		'T_LINK8URL'	=> $link8url,
		'T_LINK9URL'	=> $link9url,
		'T_LINK10URL'	=> $link10url,
		'T_FLASH'		=> $flash,
		'T_SEARCHBOX'	=> $searchbox,
	));
	blocks('left');
}

function themefooter() {
	global $showblocks, $banners, $cpgtpl, $foot1, $foot2, $foot3, $copyright, $start_time, $db;
	blocks('right');
	$cpgtpl->assign_vars(array(
		'B_R_VISIBLE'   => hideblock('601') ? 'style="display: none"' : '',
		'B_R_HIDDEN'    => hideblock('601') ? '' : 'style="display: none"',
		'S_FOOTER'      => footmsg()
	));
	$cpgtpl->set_filenames(array('footer' => 'footer.html'));
	$cpgtpl->display('footer');
}

/***********************************************************************************

 void themesidebox

 Output the specific block to left or right
	$title	: the title of the block
	$content: all formatted content for the block
	$bid	: the database record ID of the block

************************************************************************************/
function themesidebox($title, $content, $bid=0) {
	global $cpgtpl, $themeblockside;
	$cpgtpl->assign_block_vars($themeblockside.'block', array(
		'S_TITLE'   => $title,
		'S_CONTENT' => $content,
		'S_BID'     => $bid,
		'S_VISIBLE' => hideblock($bid) ? 'style="display:none"' : '',
		'S_HIDDEN'  => hideblock($bid) ? '' : 'style="display:none"',
		'S_IMAGE'   => 'themes/DF_Hardwired/images/'.(hideblock($bid) ? 'plus.gif' : 'minus.gif')
	));
	if ($themeblockside == '') {
		$cpgtpl->set_filenames(array('block' => 'block.html'));
		$cpgtpl->display('block');
	}
}
/***********************************************************************************

 string theme_open_form

 Creates start tag for form
	$get_link : link for action default blank
	$form_name : useful for styling and nbbcode
	$legend: optional string value is used in form lagend tag
	$border: optional use 1 to not show border on fieldset from stylesheet
************************************************************************************/
function theme_open_form($link, $form_name=false, $legend=false,$tborder=false) {
	$leg = $legend ? "<legend>$legend</legend>" : '';
	$bord = $tborder ? $tborder : '';
	$form_name	= $form_name ? ' name="'.$form_name.'" id="'.$form_name.'"' :'';
	return '<fieldset '.$bord.'>'.$leg.'<form method="post" action="'.$link.'"'.$form_name.' enctype="multipart/form-data" accept-charset="utf-8">';
}
function theme_close_form() {
	return '</form></fieldset>';
}
/***********************************************************************************

 string theme_yesno_option

 Creates 2 radio buttons with a Yes and No option
	$name : name for the <input>
	$value: current value, 1 = yes, 0 = no

************************************************************************************/
function theme_yesno_option($name, $value=0) {
	$sel[(!$value)] = '';
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	$select .= '<option value="1"'.$sel[1].">"._YES."</option>\n";
	$select .= '<option value="0"'.$sel[0].">"._NO."</option>\n";
	return $select.'</select>';
	//$sel[intval($value)] = ' checked="checked"';
	//return '<input type="radio" name="'.$name.'" value="1"'.$sel[1].' title="'._YES.'" />
	//<label class="yes" for="'.$name.'">'._YES.'</label>
	//<input type="radio" name="'.$name.'" value="0" '.$sel[0].' title="'._NO.'" />
	//<label class="no" for="'.$name.'">'._NO.'</label> ';
}
/***********************************************************************************

 string theme_select_option

 Creates a selection dropdown box of all given variables in the array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1","value2")

************************************************************************************/
function theme_select_option($name, $value, $array) {
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $var) {
		$select .= '<option'.(isset($sel[$var])?$sel[$var]:'').">$var</option>\n";
	}
	return $select.'</select>';
}
/***********************************************************************************

 string theme_select_box

 Creates a selection dropdown box of all given variables in the multi array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1 => title1","value2 => title2")

************************************************************************************/
function theme_select_box($name, $value, $array) {
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $val => $title) {
		$select .= "<option value=\"$val\"".(($val==$value) ? ' selected="selected"' : '').">$title</option>\n";
	}
	return $select.'</select>';
}
