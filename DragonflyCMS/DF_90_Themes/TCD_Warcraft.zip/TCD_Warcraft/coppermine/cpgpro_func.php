<?php
/*********************************************
  CPGPro for Dragonfly CMS
  ********************************************
  Copyright © 2005 by D Mower aka Kuragari
  http://www.DFMods.com
  http://cpgpro.iain-armitage.co.uk

  This block is released under the terms and conditions
  of the GNU GPL version 2 or any later version

  $Revision: 1.0 $
  $Author: Kuragari and TehBooster$
  $Date: 2005/07/01 $
**********************************************/
function new_check($typ, $arg) {
    global $db, $prefix, $CPG_SESS;
    if ($typ == 'album') {
        list($add_date) = $db->sql_ufetchrow('SELECT p.ctime FROM '.$prefix.'_cpg_albums a LEFT JOIN '.$prefix.'_cpg_pictures p ON (a.aid = p.aid) WHERE a.title="'.$arg.'" ORDER BY p.ctime DESC LIMIT 1',SQL_NUM);
        $new_date = (gmtime()-259200);
        return ($add_date > $new_date) ? '<img src="themes/'.$CPG_SESS['theme'].'/images/forums/folder_new_big.gif" alt="Recently Updated" border="0" />' : '<img src="themes/'.$CPG_SESS['theme'].'/images/forums/folder_big.gif" alt="&nbsp;" border="0" />';
    }
    if ($typ == 'cat') {
        list($add_date) = $db->sql_ufetchrow('SELECT p.ctime FROM '.$prefix.'_cpg_categories c LEFT JOIN '.$prefix.'_cpg_albums a ON (a.category = c.cid) LEFT JOIN '.$prefix.'_cpg_pictures p ON (a.aid = p.aid) WHERE c.catname="'.strip_tags($arg).'" ORDER BY p.ctime DESC LIMIT 1',SQL_NUM);
        $new_date = (gmtime()-259200);
        return '<img src="themes/'.$CPG_SESS['theme'].'/images/forums/'.($add_date > $new_date ? 'folder_new_big.gif' : 'folder_big.gif').'" alt="&nbsp;" border="0" />';
    }
}

function get_caption($caption) {
    $pos1 = strpos('alt', $caption);
    $pos2 = strpos('title', $caption);
    return substr($caption, $pos1);
}