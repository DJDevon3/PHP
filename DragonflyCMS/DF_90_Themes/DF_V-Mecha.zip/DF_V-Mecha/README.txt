// Changelog:
// November 11th, 2005
// TreasureCoastDesigns.com Port to Dragonfly 9.0.1
// New forum, gallery, and download template system
// Fully integrated with Mtechniks ThemeCP mod
// Dragonfly port will not work without the mod.
// It's available for download from TCD
// TCD is compliant with CreativeCommons and GPL by retaining vipixels copyrights and readme. :)
// Support for the Dragonfly version should be requested on the TCD site.  Enjoy!
//
// Changelog:
// August 20th, 2004
// Fixing collapse images
//
// August 18th, 2004
// Porting to CPG-Nuke
// width adjustment for many modules that need wider space.
//
// August 17th, 2004
// fixed the unclosed div tag line 128 theme.php
// added a fancy background ;)
//
// Changelog:
// August 15th, 2004
// Fixed minor bug: missing topic images path and incorrect image position
// Added new version Fixed Width, 770 pixels width
// ----------------------------------------------------------------------
// V-Mecha 1.0 free theme for CPGNuke 8.x
// Tested on Mozilla 1.7, Firefox 0.9.x, Camino 0.8, IE 6.x. Opera 7.x, Netscape 7.2, Safari 1.x
// Not Tested on: IE 4.x, Opera 6.x, Safari 1.2
// Known bug: not yet discovered again
// Fixed bug: IE 5.x win/mac sideblock oversize
//	      CSS Navigation scretch out the table
// If you found bugs, please send it to support@vipixel.com
//
// Author of Design: Brumie - http://nuke.vipixel.com
// Code License: GPL
// Purpose of file: Free CPG-Nuke 8.x themes
// Developed at VIPixel.com - www.vipixel.com
// Copyright � 2002,2004 by VIPixel All Rights Reserved
// Design License: CREATIVE COMMONS LICENSE
// ----------------------------------------------------------------------
//
// http://creativecommons.org/licenses/by-nd/2.0/
// Attribution-NoDerivs 2.0
//
// You are free:
//
//    * to copy, distribute, display, and perform the work
//    * to make commercial use of the work
//
// Under the following conditions:
// BY Attribution. You must give the original author credit.
// And	
// No Derivative Works. You may not alter, transform, or build upon this work.
//
//    * For any reuse or distribution, you must make clear to others the license terms of this work.
//    * Any of these conditions can be waived if you get permission from the copyright holder.
//
// ----------------------------------------------------------------------
//
// VIPixel is not liable for any products or services offered by means of the theme.
// You must assume the entire risk of using the theme.
//
// VIPixel
// Art with a digital touch!
//
// www.vipixel.com
// webmaster@vipixel.com
//
// ----------------------------------------------------------------------
//
// F A Q
// _____
//
// Q: Why you're not providing skin module for PHPBB Forums and oh where is the FireworksMX Template graphics source?
// A: we seperate it into Pro version which is available for Donators only.
//
// Q: Can I modified this theme?
// A: Yes you can ;) and please don't remove our small credit.
//
// Q: Can I use it for Commercial site?
// A: Yep, as long as you're not removing VIPixel's Copyright and link back on the main site
//
// Q: Ok, I don't want your copyright and link back is there any way to solve this?
// A: Yes and there's a cost 30 USD for copyright removal, please contact webmaster@vipixel.com
//
// Q: Wow I really love your theme and would like to donate, how?
// A: Woohoo I like this guy, go to our site and you'll find a donate box there.
//
// Q: Aickz! I can't design! I want to modified the graphics, can you help me?
// A: Yep, Our team ready to modified our existing theme with low cost, for details contact webmaster@vipixel.com
//
// Q: Can you modified others exsiting theme?
// A: No, we only modified our themes
//
// Q: Can you build a custom exclusive theme
// A: Yes, for details contact webmaster@vipixel.com
//