<?php
/*********************************************
  CPG Dragonfly� CMS
  ********************************************
  Copyright � 2004 - 2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version
Original by DestineDesigns.com
Port by DJDevon3 of TreasureCoastDesigns.com
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

$gfxcolor = '#3300CC';
$bgcolor1 = '##474646';
$bgcolor2 = '#474646';
$bgcolor3 = '#474646';
$bgcolor4 = '#FFC53A';
$textcolor1 = '#FFFFFF';
$textcolor2 = '#FFFFFF';
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function OpenTable() {
	echo '<br><table border="0" align=center cellpadding="0" cellspacing="0" width="98%"><tr><td width="23" height="23" valign="top"><img src="themes/HL2/images/ttl.jpg" width="23" height="23"></td><td width="100%" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="themes/HL2/images/tt.jpg"><tr><td width="712" height="23" valign="top">&nbsp;</td></tr></table></td><td width="23" valign="top"><img src="themes/HL2/images/ttr.jpg" width="23" height="23"></td><td width="1"></td></tr><tr><td height="24" valign="top" background="themes/HL2/images/tl.jpg"><img name="leftside" src="themes/HL2/images/spacer.gif" width="1" height="1" border="0" alt=""></td><td valign="top" bgcolor="#1b1b1b">';
}
function OpenTable2() {
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" ><tr><td class=row1>\n";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\" ><tr><td>\n";
}

function CloseTable() {
	echo '</td><td valign="top" background="themes/HL2/images/tr.jpg"><img name="rightside" src="themes/HL2/images/spacer.gif" width="1" height="1" border="0" alt=""></td><td></td></tr><tr><td height="23" valign="top"><img src="themes/HL2/images/tbl.jpg" width="23" height="23"></td><td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="themes/HL2/images/tb.jpg"><tr><td width="712" height="23" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td></tr></table></td><td valign="top"><img src="themes/HL2/images/tbr.jpg" width="23" height="23"></td><td></td></tr><tr> <td height="1"><img src="themes/HL2/images/hm.jpg" alt="" width="23" height="1"></td><td></td><td><img src="themes/HL2/images/hm.jpg" alt="" width="23" height="1"></td><td><img src="themes/HL2/images/hm.jpg" alt="" width="1" height="1"></td></tr></table>';
}
function CloseTable2() {
    echo "</td></tr></table></td></tr></table>\n";
}

function themeheader() {
	global $slogan, $sitename, $banners, $mainindex, $adminindex, $cpgtpl, $site_logo;
	$imgr = $imgl = '';
	// left blocks ?
	if (blocks_visible('l')) {
		$img = hideblock('600') ? 'plus.gif' : 'minus.gif';
		$imgl = '<img align="left" alt="Toggle Content" title="Toggle Content" id="pic600" src="themes/HL2/images/'.$img.'" onclick="blockswitch(\'600\');" style="cursor:pointer" />';
	}
	// right blocks ?
	if (blocks_visible('r')) {
		$img = hideblock('601') ? 'plus.gif' : 'minus.gif';
		$imgr = '<img align="right" alt="Toggle Content" title="Toggle Content" id="pic601" src="themes/HL2/images/'.$img.'" onclick="blockswitch(\'601\');" style="cursor:pointer" />';
	}
	$cpgtpl->assign_vars(array(
		'CSS_FILE'     => ereg('MSIE', $_SERVER['HTTP_USER_AGENT']) ? 'ie' : 'style',
		'PUBLIC_HEADER' => !defined('ADMIN_PAGES'),
		'B_L_VISIBLE'  => hideblock('600') ? 'style="display: none"' : '',
		'B_L_HIDDEN'   => hideblock('600') ? '' : 'style="display: none"',
		'G_LEFTIMAGE'  => $imgl,
		'G_RIGHTIMAGE' => $imgr,
		'S_IS_ADMIN'   => is_admin(),
		'S_CAN_ADMIN'  => can_admin(),
		'S_IS_USER'    => is_user(),
		'S_LOGO'       => $site_logo,
		'S_SITENAME'   => $sitename,
		'S_HOME'       => _HOME,
		'S_DOWNLOADS'  => is_active('Downloads') ? _DownloadsLANG : false,
		'S_FORUMS'     => _ForumsLANG,
		'S_MY_ACCOUNT' => is_user() ? _Your_AccountLANG : _BREG,
		'S_ADMIN'      => _ADMINISTRATION,
		'U_MAININDEX'  => $mainindex,
		'U_DOWNLOADS'  => getlink('Downloads'),
		'U_FORUMS'     => getlink('Forums'),
		'U_MY_ACCOUNT' => getlink(is_user() ? 'Your_Account' : 'Your_Account&amp;file=register'),
		'U_ADMININDEX' => $adminindex,
	));
	blocks('left');
}

function themefooter() {
	global $showblocks, $banners, $cpgtpl, $foot1, $foot2, $foot3, $copyright, $start_time, $db;
	blocks('right');
	$cpgtpl->assign_vars(array(
		'B_R_VISIBLE'   => hideblock('601') ? 'style="display: none"' : '',
		'B_R_HIDDEN'    => hideblock('601') ? '' : 'style="display: none"',
		'S_BANNER'     => ($banners) ? viewbanner() : '',
		'S_FOOTER'      => footmsg()
	));
	$cpgtpl->set_filenames(array('footer' => 'footer.html'));
	$cpgtpl->display('footer');
}

/***********************************************************************************

 void themesidebox

 Output the specific block to left or right
	$title	: the title of the block
	$content: all formatted content for the block
	$bid	: the database record ID of the block

************************************************************************************/
function themesidebox($title, $content, $bid=0) {
	global $cpgtpl, $themeblockside;
	$cpgtpl->assign_block_vars($themeblockside.'block', array(
		'S_TITLE'   => $title,
		'S_CONTENT' => $content,
		'S_BID'     => $bid,
		'S_VISIBLE' => hideblock($bid) ? 'style="display:none"' : '',
		'S_HIDDEN'  => hideblock($bid) ? '' : 'style="display:none"',
		'S_IMAGE'   => 'themes/HL2/images/'.(hideblock($bid) ? 'plus.gif' : 'minus.gif')
	));
	if ($themeblockside == '') {
		$cpgtpl->set_filenames(array('block' => 'block.html'));
		$cpgtpl->display('block');
	}
}
/***********************************************************************************

 string theme_open_form

 Creates start tag for form
	$get_link : link for action default blank
	$form_name : useful for styling and nbbcode
	$legend: optional string value is used in form lagend tag
	$border: optional use 1 to not show border on fieldset from stylesheet
************************************************************************************/
function theme_open_form($link, $form_name=false, $legend=false,$tborder=false) {
	$leg = $legend ? "<legend>$legend</legend>" : '';
	$bord = $tborder ? $tborder : '';
	$form_name	= $form_name ? ' name="'.$form_name.'" id="'.$form_name.'"' :'';
	return '<fieldset '.$bord.'>'.$leg.'<form method="post" action="'.$link.'"'.$form_name.' enctype="multipart/form-data" accept-charset="utf-8">';
}
function theme_close_form() {
	return '</form></fieldset>';
}
/***********************************************************************************

 string theme_yesno_option

 Creates 2 radio buttons with a Yes and No option
	$name : name for the <input>
	$value: current value, 1 = yes, 0 = no

************************************************************************************/
function theme_yesno_option($name, $value=0) {
	$sel[(!$value)] = '';
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	$select .= '<option value="1"'.$sel[1].">"._YES."</option>\n";
	$select .= '<option value="0"'.$sel[0].">"._NO."</option>\n";
	return $select.'</select>';
	//$sel[intval($value)] = ' checked="checked"';
	//return '<input type="radio" name="'.$name.'" value="1"'.$sel[1].' title="'._YES.'" />
	//<label class="yes" for="'.$name.'">'._YES.'</label>
	//<input type="radio" name="'.$name.'" value="0" '.$sel[0].' title="'._NO.'" />
	//<label class="no" for="'.$name.'">'._NO.'</label> ';
}
/***********************************************************************************

 string theme_select_option

 Creates a selection dropdown box of all given variables in the array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1","value2")

************************************************************************************/
function theme_select_option($name, $value, $array) {
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $var) {
		$select .= '<option'.(isset($sel[$var])?$sel[$var]:'').">$var</option>\n";
	}
	return $select.'</select>';
}
/***********************************************************************************

 string theme_select_box

 Creates a selection dropdown box of all given variables in the multi array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1 => title1","value2 => title2")

************************************************************************************/
function theme_select_box($name, $value, $array) {
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $val => $title) {
		$select .= "<option value=\"$val\"".(($val==$value) ? ' selected="selected"' : '').">$title</option>\n";
	}
	return $select.'</select>';
}

?>