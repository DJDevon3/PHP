<?php
/*********************************************
  CPG Dragonfly™ CMS
  ********************************************
  Copyright © 2004 - 2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version

  $Source: /cvs/html/themes/cpgnuke/theme.php,v $
  $Revision: 9.4 $
  $Author: djmaze $
  $Date: 2005/04/01 02:27:32 $
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

$gfxcolor = '#C0C000';
$bgcolor1 = '#D8D8D8';
$bgcolor2 = '#D3DFE3';
$bgcolor3 = '#EFEFEF';
$bgcolor4 = '#E8E8E8';
$textcolor1 = '#006600';
$textcolor2 = '#000000';
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function OpenTable() {
	echo '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td width="9" height="1"><img border="0" src="themes/TCD_Aquarium/images/block_border/top_left.gif" width="9" height="9" alt="topleft" /></td><td height="1" ><img border="0" src="themes/TCD_Aquarium/images/block_border/top.gif" width="100%" height="9" alt="topfill" /></td><td width="9" height="1"><img border="0" src="themes/TCD_Aquarium/images/block_border/top_right.gif" width="9" height="9" alt="topright" /></td></tr><tr><td width="9" background="themes/TCD_Aquarium/images/block_border/left_fill.gif" height="100%"></td><td background="themes/TCD_Aquarium/images/Article_BG.jpg">';
}
function CloseTable() {
	echo '</td><td width="9" background="themes/TCD_Aquarium/images/block_border/right_fill.gif" height="100%"></td></tr><tr><td width="9" height="5"><img border="0" src="themes/TCD_Aquarium/images/block_border/bottom_left.gif" alt="bottomleft" width="9" height="9" /></td><td background="themes/TCD_Aquarium/images/block_border/bottom.gif" width="100%" height="9"></td><td width="9" height="5"><img border="0" src="themes/TCD_Aquarium/images/block_border/bottom_right.gif" alt="bottomright" width="9" height="9" /></td></tr></table>';
}

function OpenTable2() {
	echo '<table class="table1"><tr><td>';
}
function CloseTable2() {
	echo '</td></tr></table>';
}

function themeheader() {
	global $slogan, $sitename, $banners, $mainindex, $adminindex, $cpgtpl, $site_logo, $db, $prefix, $userinfo;
		$sql = "SELECT msg1, link1, link2, link3, link4, link5, link1url, link2url, link3url, link4url, link5url, searchbox, flash FROM ".$prefix."_themecp";
	$result = $db->sql_query($sql);
	list($msg1, $link1, $link2, $link3, $link4, $link5, $link1url, $link2url, $link3url, $link4url, $link5url, $searchbox, $flash) = $db->sql_fetchrow($result);
	$imgr = $imgl = '';
	// left blocks ?
	if (blocks_visible('l')) {
		$img = hideblock('600') ? 'plus.gif' : 'minus.gif';
		$imgl = '<img align="left" alt="Toggle Content" title="Toggle Content" id="pic600" src="themes/TCD_Aquarium/images/'.$img.'" onclick="blockswitch(\'600\');" style="cursor:pointer" />';
	}
	// right blocks ?
	if (blocks_visible('r')) {
		$img = hideblock('601') ? 'plus.gif' : 'minus.gif';
		$imgr = '<img align="right" alt="Toggle Content" title="Toggle Content" id="pic601" src="themes/TCD_Aquarium/images/'.$img.'" onclick="blockswitch(\'601\');" style="cursor:pointer" />';
	}
	$indexbodyrollover = '#C7ECEC';
	$viewforumrollover = '#C7ECEC';
	$date = ''.date('F j, Y, g:i a');
	$cpgtpl->assign_vars(array(
		'CSS_FILE'     => ereg('MSIE', $_SERVER['HTTP_USER_AGENT']) ? 'ie' : 'style',
		'PUBLIC_HEADER' => !defined('ADMIN_PAGES'),
		'B_L_VISIBLE'  => hideblock('600') ? 'style="display: none"' : '',
		'B_L_HIDDEN'   => hideblock('600') ? '' : 'style="display: none"',
		'G_LEFTIMAGE'  => $imgl,
		'G_RIGHTIMAGE' => $imgr,
		'S_IS_ADMIN'   => is_admin(),
		'S_CAN_ADMIN'  => can_admin(),
		'S_IS_USER'    => is_user(),
		'S_LOGO'       => $site_logo,
		'S_SITENAME'   => $sitename,
		'S_HOME'       => _HOME,
		'S_DOWNLOADS'  => is_active('Downloads') ? _DownloadsLANG : false,
		'S_FORUMS'     => _ForumsLANG,
		'S_MY_ACCOUNT' => is_user() ? _Your_AccountLANG : _BREG,
		'S_ADMIN'      => _ADMINISTRATION,
		'S_BANNER'     => ($banners) ? viewbanner() : '',
		'U_MAININDEX'  => $mainindex,
		'U_DOWNLOADS'  => getlink('Downloads'),
		'U_FORUMS'     => getlink('Forums'),
		'U_GALLERY'     => getlink('coppermine'),
		'U_MY_ACCOUNT' => getlink(is_user() ? 'Your_Account' : 'Your_Account&amp;file=register'),
		'U_ADMININDEX' => $adminindex,
		'T_INDEXBODYROLLOVER' => $indexbodyrollover,
		'T_VIEWFORUMROLLOVER' => $viewforumrollover,
		'U_WELCOME'		=> is_user() ? 'Welcome '.$userinfo['username'] : '<a href="index.php?name=Your_Account&amp;file=register">Register</a> or <a href="index.php?name=Your_Account">Login</a>',
        'S_NOWTIME'		=> $date,
		'T_MSG1'		=> $msg1,
		'T_LINK1'		=> $link1,
		'T_LINK2'		=> $link2,
		'T_LINK3'		=> $link3,
		'T_LINK4'		=> $link4,
		'T_LINK5'		=> $link5,
		'T_LINK1URL'	=> $link1url,
		'T_LINK2URL'	=> $link2url,
		'T_LINK3URL'	=> $link3url,
		'T_LINK4URL'	=> $link4url,
		'T_LINK5URL'	=> $link5url,
		'T_FLASH'		=> $flash,
		'T_SEARCHBOX'	=> $searchbox,
	));
	blocks('left');
}

function themefooter() {
	global $showblocks, $banners, $cpgtpl, $foot1, $foot2, $foot3, $copyright, $start_time, $db;
	blocks('right');
	$cpgtpl->assign_vars(array(
		'B_R_VISIBLE'   => hideblock('601') ? 'style="display: none"' : '',
		'B_R_HIDDEN'    => hideblock('601') ? '' : 'style="display: none"',
		'S_FOOTER'      => footmsg()
	));
	$cpgtpl->set_filenames(array('footer' => 'footer.html'));
	$cpgtpl->display('footer');
}

/***********************************************************************************

 void themesidebox

 Output the specific block to left or right
	$title	: the title of the block
	$content: all formatted content for the block
	$bid	: the database record ID of the block

************************************************************************************/
function themesidebox($title, $content, $bid=0) {
	global $cpgtpl, $themeblockside;
	$cpgtpl->assign_block_vars($themeblockside.'block', array(
		'S_TITLE'   => $title,
		'S_CONTENT' => $content,
		'S_BID'     => $bid,
		'S_VISIBLE' => hideblock($bid) ? 'style="display:none"' : '',
		'S_HIDDEN'  => hideblock($bid) ? '' : 'style="display:none"',
		'S_IMAGE'   => 'themes/TCD_Aquarium/images/'.(hideblock($bid) ? 'plus.gif' : 'minus.gif')
	));
	if ($themeblockside == '') {
		$cpgtpl->set_filenames(array('block' => 'block.html'));
		$cpgtpl->display('block');
	}
}
/***********************************************************************************

 string theme_open_form

 Creates start tag for form
	$get_link : link for action default blank
	$form_name : useful for styling and nbbcode
	$legend: optional string value is used in form lagend tag
	$border: optional use 1 to not show border on fieldset from stylesheet
************************************************************************************/
function theme_open_form($link, $form_name=false, $legend=false,$tborder=false) {
	$leg = $legend ? "<legend>$legend</legend>" : '';
	$bord = $tborder ? $tborder : '';
	$form_name	= $form_name ? ' name="'.$form_name.'" id="'.$form_name.'"' :'';
	return '<fieldset '.$bord.'>'.$leg.'<form method="post" action="'.$link.'"'.$form_name.' enctype="multipart/form-data" accept-charset="utf-8">';
}
function theme_close_form() {
	return '</form></fieldset>';
}
/***********************************************************************************

 string theme_yesno_option

 Creates 2 radio buttons with a Yes and No option
	$name : name for the <input>
	$value: current value, 1 = yes, 0 = no

************************************************************************************/
function theme_yesno_option($name, $value=0) {
	$sel[(!$value)] = '';
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	$select .= '<option value="1"'.$sel[1].">"._YES."</option>\n";
	$select .= '<option value="0"'.$sel[0].">"._NO."</option>\n";
	return $select.'</select>';
	//$sel[intval($value)] = ' checked="checked"';
	//return '<input type="radio" name="'.$name.'" value="1"'.$sel[1].' title="'._YES.'" />
	//<label class="yes" for="'.$name.'">'._YES.'</label>
	//<input type="radio" name="'.$name.'" value="0" '.$sel[0].' title="'._NO.'" />
	//<label class="no" for="'.$name.'">'._NO.'</label> ';
}
/***********************************************************************************

 string theme_select_option

 Creates a selection dropdown box of all given variables in the array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1","value2")

************************************************************************************/
function theme_select_option($name, $value, $array) {
	$sel[$value] = ' selected="selected"';
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $var) {
		$select .= '<option'.(isset($sel[$var])?$sel[$var]:'').">$var</option>\n";
	}
	return $select.'</select>';
}
/***********************************************************************************

 string theme_select_box

 Creates a selection dropdown box of all given variables in the multi array
	$name : name for the <select>
	$value: current/default value
	$array: array like array("value1 => title1","value2 => title2")

************************************************************************************/
function theme_select_box($name, $value, $array) {
	$select = '<select class="set" name="'.$name.'" id="'.$name."\">\n";
	foreach($array as $val => $title) {
		$select .= "<option value=\"$val\"".(($val==$value) ? ' selected="selected"' : '').">$title</option>\n";
	}
	return $select.'</select>';
}
