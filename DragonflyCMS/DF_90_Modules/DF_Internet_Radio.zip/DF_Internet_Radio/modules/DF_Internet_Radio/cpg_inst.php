<?php
/*********************************************
  DF_Internet_Radio Version 1.0 cpg_inst
  ********************************************
  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Originally by Just4Me.NL for phpnuke

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class DF_Internet_Radio {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function DF_Internet_Radio() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'DF_Internet_Radio';
		$this->description = 'An easy way to play your favorite stations on your site.';
		$this->author = 'Original by www.just4me.nl Ported by DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('internet_radio_settings', 'internet_radio_stations');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'internet_radio_settings', "
			module_auto_start tinyint(1) NOT NULL default '0',
			block_auto_start tinyint(1) NOT NULL default '0',
			popup_auto_start tinyint(1) NOT NULL default '0',
			module_player_height varchar(4) NOT NULL default '',
			module_player_width varchar(4) NOT NULL default '',
			block_player_height varchar(4) NOT NULL default '',
			block_player_width varchar(4) NOT NULL default '',
			popup_player_height varchar(4) NOT NULL default '',
			popup_player_width varchar(4) NOT NULL default '',
			popup_window_height varchar(4) NOT NULL default '',
			popup_window_width varchar(4) NOT NULL default '',
			picture tinyint(1) NOT NULL default '0',
			picture_dir varchar(50) NOT NULL default '',
			defpicture tinyint(1) NOT NULL default '0',
			nopicture_name varchar(50) NOT NULL default '',
			PRIMARY KEY (module_auto_start)", 'internet_radio_settings');

			$installer->add_query('INSERT', 'internet_radio_settings', "'0', '0', '0', '45', '140', '45', '140', '45', '140', '200', '250', '1', 'modules/DF_Internet_Radio/images/', '1', 'radio_on.gif'");

		 $installer->add_query('CREATE', 'internet_radio_stations', "
			radio_id int(10) unsigned NOT NULL auto_increment,
			radio_name varchar(20) NOT NULL default '',
			radio_stream varchar(255) NOT NULL default '',
			radio_url varchar(100) NOT NULL default '',
			radio_picture varchar(100) NOT NULL default '',
			PRIMARY KEY (radio_id)", 'internet_radio_stations');

			$installer->add_query('INSERT', 'internet_radio_stations' ,"'', 'Radio Gets Wild', 'http://listen.radiogetswild.com/radio.asx', 'http://www.RadioGetsWild.com', 'RGW.gif'");
			$installer->add_query('INSERT', 'internet_radio_stations' ,"'', 'Dance Mania', 'http://listen.radiodancemania.com/radio.asx', 'http://www.RadioDanceMania.com/', 'DanceMania.gif'");
			$installer->add_query('INSERT', 'internet_radio_stations' ,"'', 'Radio Paradise', 'http://www.radioparadise.com/musiclinks/rp_128x.ram', 'http://www.RadioParadise.com', 'RadioParadise.gif'");
	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'internet_radio_settings');	
		$installer->add_query('DROP', 'internet_radio_stations');
		return true;
	}
}
?>