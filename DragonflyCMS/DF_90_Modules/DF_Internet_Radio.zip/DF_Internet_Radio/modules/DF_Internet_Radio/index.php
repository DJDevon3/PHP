<?PHP 

/*********************************************
  DF_Internet_Radio Version 1.0 Index
  ********************************************
  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Originally by Just4Me.NL for phpnuke

Ported to DragonflyCMS by TreasureCoastDesigns.com
*/

//******************************************//
// DO NOT CHANGE ANYTHING ON THIS SCRIPT !! //
//       LEAVE COPYRIGHT IN PLACE           //
//******************************************//
if (!defined('CPG_NUKE')) { exit; }
include("header.php");
get_lang('DF_Internet_Radio');
global $prefix, $db, $module_name; 

$result = $db->sql_query("SELECT module_auto_start, popup_window_height, popup_window_width, picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
  list($module_auto_start, $popup_window_height, $popup_window_width, $picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);

if ($module_auto_start == 0) 
{$module_auto_start = "false";}
else
{$module_auto_start = "true";}

// radio station selected from floating block
$radio_id = $_POST['select'];

//radio station selection
$result = $db->sql_query("SELECT radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_name, $radio_stream, $radio_url, $radio_picture) = $db->sql_fetchrow($result);

if ($radio_id != 0){
if ($radio_url !="" AND $radio_url != "http://"){
$url = $radio_url;}
$stationname = $radio_name;
}
else
{$stationname = ""._INRADNOC."";}

$result = $db->sql_query("SELECT radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_picture) = $db->sql_fetchrow($result);
$result = $db->sql_query("SELECT picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
  list($picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);


// picture settings
$picture_name = $radio_picture;
if ($picture == 1 and ($picture_name =="" and $defpicture == 1))
 {$picture_name = $nopicture_name;}

// function to check for real player files
function check_real($t_url){

$temp_url = basename($t_url);
$temp_url = trim($temp_url);
$temp_url = strtolower($temp_url);
$check_ram = substr($temp_url, -3);
$check_rm = substr($temp_url, -2);

if ($check_rm == "rm"){
	return true;
	} elseif ($check_ram == "ram") {
			return true;
		} elseif ($check_rm == "ra") {
				return true;
			} elseif ($check_ram == "pls") {
				return true;
			 } elseif ($check_ram == "rpm") {
			   return true;
				} else {
					return false;
					}
}

// function to check for window media player files
function check_wma($w_url){

$wtemp_url = basename($w_url);
$wtemp_url = trim($wtemp_url);
$wtemp_url = strtolower($wtemp_url);
$check_asx = substr($wtemp_url, -3);
$check_wma = substr($wtemp_url, -3);

if ($check_wma == "wma"){
	return true;
	} elseif ($check_asx == "asx") {
			return true;
		} elseif ($check_wma == "wmp") {
				return true;
			} elseif ($check_wma == "pls") {
				return true;
				} else {
					return false;
					}
}

// script for opening window
echo "<SCRIPT LANGUAGE=\"JavaScript\">

function launch(url) {
  remote = open(url, \"\", \"width=$popup_window_width,height=$popup_window_height,left=0,top=0,resizable=yes,scrollbars=yes,toolbar=no\");
}

</SCRIPT>";
// picture settings
$radio_id = $_POST['select'];
$result = $db->sql_query("SELECT module_auto_start, module_player_height, module_player_width, picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
list($module_auto_start, $module_player_height, $module_player_width, $picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);
$result = $db->sql_query("SELECT radio_id, radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_id, $radio_name, $radio_stream, $radio_url, $radio_picture) = $db->sql_fetchrow($result);

if ($radio_url !=""){
$temp_station_image = "<div class='title'><a href=$url target=\"_blank\">$stationname</a></div>";
	if ($picture == 1 and $radio_picture != ""){
	$temp_station_image .= "<a href=$url target=\"_blank\"><img border=\"0\" src=\"".$picture_dir."".$picture_name."\" alt=\"Missing Station Image\" /></a>";
	}elseif($defpicture == 1 and $radio_picture != ""){
	$temp_station_image .= "<a href=$url target=\"_blank\"><img border=\"0\" src=\"".$picture_dir."".$nopicture_name."\" alt=\"Missing Station Image\" /></a>";
	}
}
else {
$temp_station_image = "$stationname<br />";
if ($picture == 1 and $radio_picture != ""){
$temp_station_image .= "<img border=\"0\" src=\"".$picture_dir."".$picture_name."\" alt=\"Missing Station Image\" />";}
}


if ($module_auto_start == 0) 
{$module_auto_start = "false";}
else
{$module_auto_start = "true";}


if (check_real($radio_stream) == true){
$content2 = "<OBJECT ID='MediaPlayer' CLASSID='clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA' HEIGHT=".$module_player_height." WIDTH=".$module_player_width."><PARAM NAME='controls' VALUE='ControlPanel' /><PARAM NAME='autostart' VALUE=".$module_auto_start." /><PARAM NAME='src' VALUE=".$radio_stream." /><EMBED SRC=".$radio_stream." type='audio/x-pn-realaudio-plugin' CONTROLS='ControlPanel' HEIGHT=".$module_player_height." WIDTH=".$module_player_width." AUTOSTART=".$module_auto_start." pluginspage='http://www.real.com/'></EMBED><noembed><a href=".$radio_stream.">Play ".$stationname."</a></noembed></OBJECT>";

}elseif (check_wma($radio_stream) == true){
$content2 = "<OBJECT ID='MediaPlayer' HEIGHT=".$module_player_height." WIDTH=".$module_player_width." classid='CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6' codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,7,1112' standby='Loading Windows� Media Player...'      type='application/x-oleobject'><PARAM NAME='URL' value=".$radio_stream."><PARAM NAME='ShowControls' VALUE='true'><PARAM NAME='ShowStatusBar' VALUE='true'><PARAM NAME='AutoStart' VALUE=".$module_auto_start."><EMBED type='application/x-mplayer2' pluginspage='http://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/' SRC=".$radio_stream." name='MediaPlayer' controls='smallconsole' height=".$module_player_height." width=".$module_player_width." AutoStart=".$module_auto_start." showcontrols='true'></EMBED><noembed><a href=".$radio_stream.">Play ".$stationname."</a></noembed></OBJECT>";
}

$result2 = $db->sql_query("SELECT radio_id, radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations");
$total_radio_num = $db->sql_numrows($result2);

if ($total_radio_num != 0){
$content2 .= "<br /><form name=\"formm\" method=\"POST\" action=\"index.php?name=".$module_name."\">";
$content2 .= "<select name=\"select\" onchange=\"formm.submit()\">";
$content2 .= "<option>( "._INRADCHO." )</option>";
$result = $db->sql_query("SELECT radio_id, radio_name FROM ".$prefix."_internet_radio_stations ORDER BY radio_name ASC");
while(list($radio_id, $radio_name) = $db->sql_fetchrow($result)) {
$content2 .= "<OPTION VALUE='".$radio_id."'>".$radio_name."</option>";
}
$content2 .= "</select></form>";
}else{
$content2 .= "<br>No Choices<br>";
}

$content3 = "<a href=\"javascript:launch('index.php?name=$module_name&file=popup&radio_id=$total_radio_num')\">"._INRADFLO."</a>";

//PULL EVERYTHING AND ECHO IT
echo "<table align='center' border='2' cellpadding='2' cellspacing='2'><tr><td class='row1' align='center'>$temp_station_image</td></tr><tr><td class='row1' align='center'>$content2</td></tr><tr><td class='row1' align='center'>$content3</td></tr></table>";



?>