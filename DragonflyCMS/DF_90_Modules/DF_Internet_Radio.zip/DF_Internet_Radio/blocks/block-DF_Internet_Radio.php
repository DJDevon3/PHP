<?php

/*********************************************
  DF_Internet_Radio Version 1.0 Block1
  ********************************************
  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Originally by Just4Me.NL for phpnuke

Ported to DragonflyCMS by TreasureCoastDesigns.com
*/

//******************************************//
// DO NOT CHANGE ANYTHING ON THIS SCRIPT !! //
//       LEAVE COPYRIGHT IN PLACE           //
//******************************************//
if (!defined('CPG_NUKE')) { exit; }
get_lang('DF_Internet_Radio');

// setplayer display width change this if it doesn't fit in your template
global $prefix, $db, $module_name; 

$radio_id = $_GET['select'];

// block settings
$result = $db->sql_query("SELECT block_auto_start, popup_window_height, popup_window_width, picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
  list($block_auto_start, $popup_window_height, $popup_window_width, $picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);

if ($block_auto_start == 0) 
{$block_auto_start = "false";}
else
{$block_auto_start = "true";}

// radio station selected from floating block
if(!$radio_id){
$radio_id = $_POST['select'];}

//radio station selection
if ($radio_id != 0){
$result = $db->sql_query("SELECT radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_name, $radio_stream, $radio_url, $radio_picture) = $db->sql_fetchrow($result);
if ($radio_url !="" AND $radio_url != "http://"){
$url = $radio_url;}
$stationname = $radio_name;
$radiostart = "true";}
else
{$stationname = ""._INRADNOC."";}

$result = $db->sql_query("SELECT radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_picture) = $db->sql_fetchrow($result);
$result = $db->sql_query("SELECT picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
  list($picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);


// picture settings
$picture_name = $radio_picture;
if ($picture == 1 and ($picture_name =="" and $defpicture == 1))
 {$picture_name = $nopicture_name;}



// function to check for real player files
function check_real2($t_url){

$temp_url = basename($t_url);
$temp_url = trim($temp_url);
$temp_url = strtolower($temp_url);
$check_ram = substr($temp_url, -3);
$check_rm = substr($temp_url, -2);

if ($check_rm == "rm"){
	return true;
	} elseif ($check_ram == "ram") {
			return true;
		} elseif ($check_rm == "ra") {
				return true;
			} elseif ($check_ram == "pls") {
				return true;
			 } elseif ($check_ram == "rpm") {
			 	return true;	
			  } else {
					return false;
					}
}

// function to check for window media player files
function check_wma2($w_url){

$wtemp_url = basename($w_url);
$wtemp_url = trim($wtemp_url);
$wtemp_url = strtolower($wtemp_url);
$check_asx = substr($wtemp_url, -3);
$check_wma = substr($wtemp_url, -3);

if ($check_wma == "wma"){
	return true;
	} elseif ($check_asx == "asx") {
			return true;
		} elseif ($check_wma == "wmp") {
				return true;
			} elseif ($check_wma == "pls") {
				return true;
				} else {
					return false;
					}
}

// script for opening window
echo "<script type=\"text/javascript\">
function launch(url) {
  remote = open(url, \"\", \"width=$popup_window_width,height=$popup_window_height,left=0,top=0,resizable=yes,scrollbars=yes,toolbar=no\");
}
</script>";

// picture settings
$result = $db->sql_query("SELECT block_auto_start, block_player_height, block_player_width, picture, picture_dir, defpicture, nopicture_name FROM ".$prefix."_internet_radio_settings");
list($block_auto_start, $block_player_height, $block_player_width, $picture, $picture_dir, $defpicture, $nopicture_name) = $db->sql_fetchrow($result);
$result = $db->sql_query("SELECT radio_id, radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations WHERE radio_id='$radio_id'");
list($radio_id, $radio_name, $radio_stream, $radio_url, $radio_picture) = $db->sql_fetchrow($result);


// content to display
if ($radio_url !=""){
$content1 = "<div class='title'><a href=$url target=\"_blank\">$stationname</a></div>";
	if ($picture == 1 and $radio_picture != ""){
	$content1 .= "<a href=$url target=\"_blank\"><img border=\"0\" src=\"".$picture_dir."".$picture_name."\" alt=\"Missing Station Image\" /></a>";
	}elseif($defpicture == 1 and $radio_picture != ""){
	$content1 .= "<a href=$url target=\"_blank\"><img border=\"0\" src=\"".$picture_dir."".$nopicture_name."\" alt=\"Missing Station Image\" /></a>";
	}
}
else {
$content1 = "$stationname<br />";
if ($picture == 1 and $radio_picture != ""){
$content1 .= "<img border=\"0\" src=\"".$picture_dir."".$picture_name."\" alt=\"Missing Station Image\" />";}
}

if ($block_auto_start == 0) 
{$block_autostart = "false";}
else
{$block_autostart = "true";}


if (check_real2($radio_stream) == true){
$content2 = "<OBJECT ID='MediaPlayer' CLASSID='clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA' HEIGHT=".$block_player_height." WIDTH=".$block_player_width."><PARAM NAME='controls' VALUE='ControlPanel' /><PARAM NAME='autostart' VALUE=".$block_auto_start." /><PARAM NAME='src' VALUE=".$radio_stream." /><EMBED SRC=".$radio_stream." type='audio/x-pn-realaudio-plugin' CONTROLS='ControlPanel' HEIGHT=".$block_player_height." WIDTH=".$block_player_width." AUTOSTART=".$block_auto_start." pluginspage='http://www.real.com/'></EMBED><noembed><a href=".$radio_stream.">Play ".$stationname."</a></noembed></OBJECT>";

}elseif (check_wma2($radio_stream) == true){
$content2 = "<OBJECT ID='MediaPlayer' HEIGHT=".$block_player_height." WIDTH=".$block_player_width." classid='CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6' codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,7,1112' standby='Loading Windows� Media Player...'      type='application/x-oleobject'><PARAM NAME='URL' value=".$radio_stream."><PARAM NAME='ShowControls' VALUE='true'><PARAM NAME='ShowStatusBar' VALUE='true'><PARAM NAME='AutoStart' VALUE=".$block_auto_start."><EMBED type='application/x-mplayer2' pluginspage='http://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/' SRC=".$radio_stream." name='MediaPlayer' controls='smallconsole' height=".$block_player_height." width=".$block_player_width." AutoStart=".$block_auto_start." showcontrols='true'></EMBED><noembed><a href=".$radio_stream.">Play ".$stationname."</a></noembed></OBJECT>";
}
$total_radio_num ='';
if ($total_radio_num != 1){
$content2 .= "<br><br><form name=\"formb\" method=\"post\" action=\"\">";
$content2 .= "<select name=\"select\" onchange=\"formb.submit()\">";
$content2 .= "<option>( "._INRADCHO." )</option>";
$result = $db->sql_query("SELECT radio_id, radio_name FROM ".$prefix."_internet_radio_stations ORDER BY radio_name ASC");
while(list($radio_id, $radio_name) = $db->sql_fetchrow($result)) {
$content2 .= "<OPTION VALUE=\"$radio_id\">$radio_name</option>";}
$content2 .= "</select></form>";
}else{
$content2 .= "<br><br>";
}

$total_radio_num ='';
$module_name = 'DF_Internet_Radio';
$result2 = $db->sql_query("SELECT radio_id, radio_name, radio_stream, radio_url, radio_picture FROM ".$prefix."_internet_radio_stations");
$total_radio_num = $db->sql_numrows($result2);
$result = $db->sql_query("SELECT radio_id, radio_name FROM ".$prefix."_internet_radio_stations ORDER BY radio_name ASC");
list($radio_id, $radio_name) = $db->sql_fetchrow($result);
$content3 = "<a href=\"javascript:launch('index.php?name=$module_name&file=popup&radio_id=$radio_id&total_radio_num=$total_radio_num')\">"._INRADFLO."</a>";

$content ="<table align='center' border='0' cellpadding='2' cellspacing='2'><tr><td class='row1' align='center'>$content1</td></tr><tr><td class='row1' align='center'>$content2</td></tr><tr><td class='row1' align='center'>$content3</td></tr></table>";

?>