<?

/*********************************************
  DF_Internet_Radio Version 1.0 Language File
  ********************************************
  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Originally by Just4Me.NL for phpnuke

Ported to DragonflyCMS by TreasureCoastDesigns.com
*/

//******************************************//
// DO NOT CHANGE ANYTHING ON THIS SCRIPT !! //
//       LEAVE COPYRIGHT IN PLACE           //
//******************************************//

define('_INRADDIS','Internet Radio is loaded in a seperate window, this part is now disabled.');
define('_INRADFLO','Load in Pop-Up Window');
define('_INRADNOC','No choice made yet');
define('_INRADSEL','selected station');
define('_INRADCHO','select station');
define('_INRADPROG','Programmed Stations');
define('_INRADEDIT','Change Settings for Station ID#:');
define('_INRADNEW','Add station');
define('_INRADNAME','Station Name');
define('_INRADSTREAM','Stream URL');
define('_INRADURL','Website URL');
define('_INRADPICT','Station Image');
define('_INRADPICTDIR','Leave empty for no picture');
define('_INRADNOST','There are no programmed radio-stations at the moment');
define('_INRADERR1','Please enter a name for the radio station');
define('_INRADERR2','Please enter the stream url for the radio station');
define('_INRADBLSET','Main Settings');
define('_INRADMODNAME','Module name');
define('_INRADPICCHO','Station Image');
define('_INRADPICDIR','Directory for Images');
define('_INRADNOPICNAME','Default Image');
define('_INRADAUTOMODULE','Auto Play in Module');
define('_INRADAUTOBLOCK','Auto Play in Block');
define('_INRADAUTOPOPUP','Auto Play in Popup');
define('_INRADPICDEF','Show default picture');
define('_INRADOPTIONAL','Optional');

define('_INRADMODULEPLAYERHEIGHT','Module Player Height');
define('_INRADMODULEPLAYERWIDTH','Module Player Width');
define('_INRADBLOCKPLAYERHEIGHT','Block Player Height');
define('_INRADBLOCKPLAYERWIDTH','Block Player Width');
define('_INRADPOPUPPLAYERHEIGHT','Popup Player Height');
define('_INRADPOPUPPLAYERWIDTH','Popup Player Width');
define('_INRADPOPUPWINDOWHEIGHT','Popup Window Height');
define('_INRADPOPUPWINDOWWIDTH','Popup Window Width');


?>
