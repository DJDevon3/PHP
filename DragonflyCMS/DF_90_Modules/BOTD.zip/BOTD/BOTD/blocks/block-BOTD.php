<?php
if (!defined('CPG_NUKE')) { exit; }

$day = date('d');
$month = date('m');
$year = date('Y');
$content = "<center><a href='/index.php?name=BabeOfTheDay'><img src='images/babes/$month-$day-$year.jpg' width='120' height='170' border='0' alt='We ran out of babes!' /></a><hr />changes midnight</center>";

'php'?>
