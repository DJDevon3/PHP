<?php
/************************************************************************/
/* THEMECP 2.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) 2004 by Mtechnik                                       */
/* http://mtechnik.net                                                  */
/* Made for PHP-Nuke ported to DragonflyCMS       */
/* ============================================                         */
/************************************************************************/
// Theme Cpanel
// Original Author of file: Mtechnik - http://mtechnik.net
//
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// and 
// SafeCracker4Hire - http://www.kylestubbins.com
//
// Developed at the1theme.com
// Copyright © 2004 by Mtechnik All Rights Reserved
// Copyright © 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from Mtechnik.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos with mtechnik
// or mdesign. Furthermore, these notices must remain visible.
// This theme license does not imply license to resell or
// redistribute any of those items without expressed permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3 and SafeCracker4Hire
// All support should be found either at DragonflyCMS.com or TreasureCoastDesigns.com
// Mtechnik & DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class themecp {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function themecp() {
		$this->radmin = true;
		$this->version = '2.0';
		$this->modname = 'ThemeCP';
		$this->description = 'Theme Control Panel 2.0 based on Mtechnik ThemeCP for PHP-Nuke';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('themecp');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'themecp', "
			msg1 varchar(209) NOT NULL default '',
			msg2 varchar(209) NOT NULL default '',
			msg3 varchar(209) NOT NULL default '',
			link1 varchar(25) NOT NULL default '',
			link2 varchar(25) NOT NULL default '',
			link3 varchar(25) NOT NULL default '',
			link4 varchar(25) NOT NULL default '',
			link5 varchar(25) NOT NULL default '',
			link6 varchar(25) NOT NULL default '',
			link7 varchar(25) NOT NULL default '',
			link8 varchar(25) NOT NULL default '',
			link9 varchar(25) NOT NULL default '',
			link10 varchar(25) NOT NULL default '',
			link1url varchar(255) NOT NULL default '',
			link2url varchar(255) NOT NULL default '',
			link3url varchar(255) NOT NULL default '',
			link4url varchar(255) NOT NULL default '',
			link5url varchar(255) NOT NULL default '',
			link6url varchar(255) NOT NULL default '',
			link7url varchar(255) NOT NULL default '',
			link8url varchar(255) NOT NULL default '',
			link9url varchar(255) NOT NULL default '',
			link10url varchar(255) NOT NULL default '',
			searchbox tinyint(1) NOT NULL default '1',
			flash tinyint(1) NOT NULL default '1',
			PRIMARY KEY (msg1),
			KEY msg1 (msg1)", 'themecp');

			$installer->add_query('INSERT', 'themecp', "'Welcome to the site!', 'Welcome to the site!', 'Welcome to the site!', 'Home', 'Topics', 'Forums', 'Stats', 'Links', 'Archives', 'Downloads', 'Submit News', 'Search', 'Account', 'index.php', 'index.php?name=Topics', 'index.php?name=Forums', 'index.php?name=Statistics', 'index.php?name=Web_Links', 'index.php?name=Stories_Archive', 'index.php?name=Downloads', 'index.php?name=News&file=submit', 'index.php?name=Search', 'index.php?name=Your_Account', '0', '0'");

	return true;
    }

	// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'themecp');	
		return true;
	}
// module upgrader
function upgrade($prev_version) {
  global $installer;
  if ($prev_version == '1.0') {
    $installer->add_query('ADD', 'themecp', "link6 varchar(25) NOT NULL default '' AFTER `link5`");
    $installer->add_query('ADD', 'themecp', "link7 varchar(25) NOT NULL default '' AFTER `link6`");
    $installer->add_query('ADD', 'themecp', "link8 varchar(25) NOT NULL default '' AFTER `link7`");
    $installer->add_query('ADD', 'themecp', "link9 varchar(25) NOT NULL default '' AFTER `link8`");
    $installer->add_query('ADD', 'themecp', "link10 varchar(25) NOT NULL default '' AFTER `link9`");
    $installer->add_query('ADD', 'themecp', "link6url varchar(255) NOT NULL default '' AFTER `link5url`");
    $installer->add_query('ADD', 'themecp', "link7url varchar(255) NOT NULL default '' AFTER `link6url`");
    $installer->add_query('ADD', 'themecp', "link8url varchar(255) NOT NULL default '' AFTER `link7url`");
    $installer->add_query('ADD', 'themecp', "link9url varchar(255) NOT NULL default '' AFTER `link8url`");
    $installer->add_query('ADD', 'themecp', "link10url varchar(255) NOT NULL default '' AFTER `link9url`");
  }
return true;
}
}
?>