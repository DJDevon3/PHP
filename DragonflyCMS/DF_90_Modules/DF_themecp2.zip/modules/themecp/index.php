<?php
/************************************************************************/
/* THEMECP 2.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) 2004 by Mtechnik                                       */
/* http://mtechnik.net                                                  */
/* Made for PHP-Nuke ported to DragonflyCMS       */
/* ============================================                         */
/************************************************************************/
// Theme Cpanel
// Original Author of file: Mtechnik - http://mtechnik.net
//
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// and 
// SafeCracker4Hire - http://www.kylestubbins.com
//
// Developed at the1theme.com
// Copyright � 2004 by Mtechnik All Rights Reserved
// Copyright � 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from Mtechnik.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos with mtechnik
// or mdesign. Furthermore, these notices must remain visible.
// This theme license does not imply license to resell or
// redistribute any of those items without expressed permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3 and SafeCracker4Hire
// All support should be found either at DragonflyCMS.com or TreasureCoastDesigns.com
// Mtechnik & DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
    OpenTable();
    echo '<div align="center">'."\n";
    echo '<b>Theme Control Panel is an administration module only.</b><br /><br />It is only used for customizing themes.'."\n";
    if (can_admin('themecp')) {
        echo '<br /><br /><a href="'.adminlink("themecp").'">Theme Control Panel</a>'."\n";
    }
    CloseTable();
    echo '</div>'."\n";

?>