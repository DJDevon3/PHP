<?php
/*********************************************
  DF_Skype 1.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class DF_Skype {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function DF_Skype() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'DF_Skype';
		$this->description = 'Allow other users of Skype to see your status and call you.';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('skype');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'skype', "
			skype_username varchar(50) NOT NULL default '',
			skype_title varchar(50) NOT NULL default '',
			PRIMARY KEY (skype_username),
			KEY skype_username (skype_username)", 'skype');

			$installer->add_query('INSERT', 'skype', "'Username', 'Lead Developer'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'skype');	
		return true;
	}
}
?>