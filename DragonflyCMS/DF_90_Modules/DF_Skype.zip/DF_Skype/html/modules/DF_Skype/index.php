<?php
/*********************************************
  DF_Skype 1.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
    OpenTable();
    echo '<div align="center">'."\n";
    echo '<b>My Status is an administration module only.</b><br /><br />It is only used for displaying your project status in a remote forum signature.'."\n";
    if (can_admin('MyStatus')) {
        echo '<br /><br /><a href="'.adminlink("MyStatus").'">My Status Control Panel</a>'."\n";
    }
    CloseTable();
    echo '</div>'."\n";

?>