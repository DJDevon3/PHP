<?php
/*********************************************
  DF_Skype 1.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
define("_SKP_SKNAME","Skype me!");
define("_SKP_CALLME","Chat with ");
define("_SKP_CONTACT","Agr&eacute;gate mi contacto");
define("_SKP_CHAT","&iquest;Iniciamos un Chat?");
define("_SKP_PROFILE","Mi Perfil");
define("_SKP_SENDFILE","Env&iacute;ame un fichero");
define("_SKP_VOICEMAIL","Mi Buz&oacute;n de Voz");
define("_SKP_DOWNLOAD","Descarga Skype");
define("_SKP_SELECT","Elige una opci&oacute;n");
?>