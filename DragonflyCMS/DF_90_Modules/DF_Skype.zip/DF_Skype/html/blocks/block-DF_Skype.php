<?php
/*********************************************
  DF_Skype 1.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('CPG_NUKE')) { exit; }
global $db, $prefix;
get_lang('skype');

$result = $db->sql_query("SELECT skype_username, skype_title FROM ".$prefix."_skype");
while (list($skype_username, $skype_title) = $db->sql_fetchrow($result)) {
	$content ='';
$content .= '<div align="center">';
$content .= "<script type=\"text/javascript\" src=\"http://download.skype.com/share/skypebuttons/js/skypeCheck.js\"></script>";
$content .= "<a href=\"skype:".$skype_username."?call\"><img src=\"modules/DF_Skype/images/LiveSupport.gif\" border=\"0\" alt=\"\" /></a><br />";
$content .= ""._SKP_CALLME." ".$skype_title."";
$content .= "<select name='skype_selection' onchange='window.location=this.options[selectedIndex].value'>";
$content .= "<option selected value='#'>"._SKP_SELECT."</option>";
$content .= "<option value='skype:".$skype_username."?userinfo'>"._SKP_PROFILE."</option>";
$content .= "<option value='skype:".$skype_username."?add'>"._SKP_CONTACT."</option>";
$content .= "<option value='skype:".$skype_username."?chat'>"._SKP_CHAT."</option>";
$content .= "<option value='skype:".$skype_username."?voicemail'>"._SKP_VOICEMAIL."</option>";
$content .= "<option value='skype:".$skype_username."?sendfile'>"._SKP_SENDFILE."</option></select>";
$content .= "<br /><br /><a href='http://www.skype.com/download/' target='_blank'>"._SKP_DOWNLOAD."</a>";
$content .= '</div>';
};
?>