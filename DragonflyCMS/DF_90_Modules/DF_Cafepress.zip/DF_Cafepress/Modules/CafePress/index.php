<?php

/*******************************************************************************/
/* DragonflyCMS: CafePress                                */
/* ============================================                                */
/* Version: 1.0  by Wind0hz98 Inc.                                            */
/*                                                                             */
/* Original Copyright 1.01 (c)2004 by Jeff Johnston			                   */
/* http://www.bizwriter.biz                                                    */
/*                                                                             */
/* Copyright 2.00 (c)2004 by Wind0hz98 Inc.     			                   */
/* http://www.wind0hz98.com                                                    */
/*                                                                             */
/* This program is free software; you can redistribute it and/or               */
/* modify it under the terms of the GNU General Public License                 */
/* as published by the Free Software Foundation; either version 2              */
/* of the License, or any later version.                                       */
/*                                                                             */
/* This program is distributed in the hope that it will be useful,             */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of              */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               */
/* GNU General Public License for more details.                                */
/*                                                                             */
/*                                                                             */
/* If you do not have a CafePress account, you can use the following link to   */
/* sign up! http://www.cafepress.com/cp/info/storeref.aspx?refby=wind0hz98     */
/*                                                                             */
/*******************************************************************************/

if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
$module_name = basename(dirname(__FILE__));
$pagetitle .= _CAFEPRESS;
get_lang($module_name);
include "modules/CafePress/config.php";
OpenTable();
echo"<h1><font color=\"$textcolor1\"><center>$sitename CafePress Merchandise</center></font></h1>";
CloseTable();
echo "<br><br>";

// WRITE CAFEPRESS JAVASCRIPT TO PAGE //
echo "<table width=\"99%\" bgcolor=\"#FFFFFF\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\">";
echo " <tr><td align=\"center\">";
echo '<script language="JavaScript1.1" src="http://www.cafepress.com/commonscripts.js"></script>';

if ($item) { // Script has been called with a specific item, bring up detail page.
	$detail = $url . $item;

	$fp = fsockopen ("www.cafepress.com", 80, $errno, $errstr, 30);
	if (!$fp) {
	    echo "$errstr ($errno)<br>\n";
	} else {
	    fputs ($fp, "GET /$item HTTP/1.0\r\nHost: www.cafepress.com\r\nUser-Agent: MS Internet Explorer\r\n\r\n");
	    while (!feof($fp)) {
	        $content .= fgets($fp,1024);
	    }
	    fclose ($fp);
	}

	$null = eregi("$start(.*)$end", $content, $cparray);
	$pattern = "/\/cp/";
	$replacement = "http://www.cafepress.com/cp";
	$itemdetail = preg_replace($pattern, $replacement, $cparray[1]);

	$largeImgPattern = "/<a href=\"\//";
	$largeImgReplacement = "<a href=\"index.php?name=$module_name&file=index&item=";
	$itemdetail = preg_replace($largeImgPattern, $largeImgReplacement, $itemdetail);

	// The next four lines aren't truly necessary. They 1)make the add to cart button pop up //
	// in its own window with the keep shopping button returning you to your custom store //
	// 2)add a view cart button (vey handy) and 3) change the link to the CP legal questions page //

	$itemdetail = preg_replace("/<form method=\"post\" action=\"http:\/\/www.cafepress.com\/cp\/addtocart.aspx\">/i", "<form method=\"post\" name=cart action=\"http://www.cafepress.com/cp/addtocart.aspx?keepshopping=javascript:self.close()\" target=\"cartWin\">", $itemdetail); 
	$itemdetail = preg_replace("/<input type=\"submit\"/", "<input type=submit onClick=\"cartWin = window.open ('','cartWin','toolbar=yes,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=no,width=800,height=500'); cartWin.focus(); return true;\"", $itemdetail);  
	$itemdetail = preg_replace("/Value=\"Add to Cart\"><\/td>/", "Value=\"Add to Cart\" >&nbsp;&nbsp;&nbsp;<input type=image src=viewcart_btn.gif onClick=\"cartWin = window.open ('http://www.cafepress.com/cp/viewcart.aspx','cartWin','toolbar=yes,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=no,width=800,height=500'); cartWin.focus(); return true;\"></td>", $itemdetail);  
	$itemdetail = preg_replace("/law.  <a href=\"http:\/\/www.cafepress.comhttp:\/\/www.cafepress.com/" , "law. <a href=\"http://www.cafepress.com", $itemdetail);

	echo "<script>";
	echo "function e (z, h, w, b, g) {";
	echo "document.write('<div style=\"width:'+w+';height:'+h+';background:white url(http://zoom.cafepress.com/'+(z%10)+'/'+z+'_zoom.jpg) no-repeat center center;\"><img border=\"'+b+'\" class=\"imageborder\" src=\"http://www.cafepress.com/cp/img/'+(g?'zoom':'spacer')+'.gif\" width=\"'+w+'\" height=\"'+h+'\"></div>')";
	echo "}";
	echo "</script>";

	echo $itemdetail;
} else { // No item was requested when script was called, show items from all stores in the $stores variable.
	$allitems = $url . $stores;

	// connect to CP
	$reqheader = "GET /$stores HTTP/1.0\r\nHost: www.cafepress.com\r\nUser-Agent: MS Internet Explorer\r\n\r\n"; 
	$socket = @fsockopen("www.cafepress.com", 80, &$errno, &$errstr); 
	if ($socket) 
	{ 
		fputs($socket, $reqheader); 
		while (!feof($socket)) 
		{ 
			$content .= fgets($socket, 4096); 
		} 
	} 
	fclose($socket);

	$null = eregi("$start(.*)$end", $content, $cparray);
	$pattern = "/<a href=\"\//";
	$replacement = "<a href=\"index.php?name=$module_name&file=index&item=";
	$storeitems = preg_replace($pattern, $replacement, $cparray[1]);
	$storeitems = preg_replace("/\/cp\/img\/saletag.gif/", "http://www.cafepress.com/cp/img/saletag.gif", $storeitems);
	$storeitems = preg_replace("/\/cp\/img\/fathersday_prodtag.gif/", "http://www.cafepress.com/cp/img/fathersday_prodtag.gif", $storeitems);
	$storeitems = preg_replace("/\/cp\/popupsurvey.aspx/", "http://www.cafepress.com/cp/popupsurvey.aspx", $storeitems);
	echo $storeitems;
}

echo "</td></tr></table>";
echo "<br><br>";

OpenTable();
echo"<br><center><a href=\"http://www.cafepress.com/cp/info/storeref.aspx?refby=wind0hz98\"><img src=\"http://www.cafepress.com/cp/banners/cp_referral_468x60.gif\" width=\"468\" height=\"60\" alt=\"Design and Sell Merchandise Online for Free\" border=\"0\"></center><br></a>";
CloseTable();

?>

