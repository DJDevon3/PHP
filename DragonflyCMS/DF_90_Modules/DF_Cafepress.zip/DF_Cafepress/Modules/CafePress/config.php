<?php

/*******************************************************************************/
/* PHP-NUKE: Web Portal System: CafePress Addon                                */
/* ============================================                                */
/* Version: 2.00  by Wind0hz98 Inc.                                            */
/*                                                                             */
/* Original Copyright 1.01 (c)2004 by Jeff Johnston			                   */
/* http://www.bizwriter.biz                                                    */
/*                                                                             */
/* Copyright 2.00 (c)2004 by Wind0hz98 Inc.     			                   */
/* http://www.wind0hz98.com                                                    */
/* DRAGONFLY REVISION 1.0 by DJDevon3     									  */
/* http://www.TreasureCoastDesigns.com                                         */
/*                                                                             */
/* This program is free software; you can redistribute it and/or               */
/* modify it under the terms of the GNU General Public License                 */
/* as published by the Free Software Foundation; either version 2              */
/* of the License, or any later version.                                       */
/*                                                                             */
/* This program is distributed in the hope that it will be useful,             */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of              */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               */
/* GNU General Public License for more details.                                */
/*                                                                             */
/*                                                                             */
/* If you do not have a CafePress account, you can use the following link to   */
/* sign up! http://www.cafepress.com/cp/info/storeref.aspx?refby=wind0hz98     */
/*                                                                             */
/*******************************************************************************/


$start = '<!-- Start Main Content -->';
$end = '<!-- End Content, Start Footer Include -->';
///////////////////////DO NOT CHANGE ABOVE THIS LINE//////////////////////////

//EDIT VARIABLE TO BE A LIST OF YOUR STORES//

////////////// Use below line as an example of how to combine multiple stores
////////////// They will all show up in the same main window though.  Sorry don't know a way around that. :(
////////////// Uncomment the slashes in it to activate the $stores variable.

//$stores = 'AnalogSkins,LegendaryGamers,FloridaRaves'; 

////////////// Use below line as an example of how to display 1 store
////////////// Uncomment the slashes in it to activate the $stores variable.

$stores = 'LegendaryGamers';

//////////////////////DO NOT CHANGE BELOW THIS LINE///////////////////////
$url = 'http://www.cafepress.com/';
$item = $_GET['item'];


?>
