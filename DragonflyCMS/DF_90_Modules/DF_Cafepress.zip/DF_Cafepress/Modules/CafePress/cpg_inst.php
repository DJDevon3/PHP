<?php
/**********************************************************************
Dragonfly CafePress Version 1.0
Released under the GNU General Public License
***********************************************************************
Ported to CPG Dragonfly™ CMS by: DJDevon3
Original CafePress 2.0 by: www.wind0hz98.com
**********************************************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class CafePress {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function CafePress() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'CafePress';
		$this->description = 'A simple way to display your CafePress store - Ported by DJDevon3 of TreasureCoastDesigns.com';
		$this->author = 'Wind0hz98 Inc.';
		$this->website = 'www.wind0hz98.com';
		$this->dbtables = array('CafePress');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'CafePress', "
			blank varchar(209) NOT NULL default '',
			PRIMARY KEY (blank),
			KEY blank (blank)", 'CafePress');

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'CafePress');	
		return true;
	}
}
?>