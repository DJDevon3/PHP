<?php
/*********************************************
  CPG Dragonfly� CMS
  ********************************************
  Copyright � 2004-2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version

  $Source: /cvs/html/language/english/news.php,v $
  $Revision: 9.5 $
  $Author: phoenix $
  $Date: 2005/06/07 23:38:16 $
Encoding test: n-array summation ? latin ae w/ acute ?
*******************************************************/
if (!defined('CPG_NUKE')) { exit; }
define('_CAFEPRESS','Online Store');
define('_PRINTER','Printer Friendly Page');
define('_PDATE','Date:');
define('_PTOPIC','Topic:');
define('_COMESFROM','This article comes from');
define('_THEURL','The URL for this story is:');
define('_DATE','Date');
define('_TITLE','Title');

?>