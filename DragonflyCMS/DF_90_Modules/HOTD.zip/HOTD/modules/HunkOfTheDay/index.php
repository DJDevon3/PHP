<?php
/**
* CPG Dragonfly CMS
* Copyright (c) 2004-2005 by CPG-Nuke Dev Team, www.dragonflycms.com
* Released under the GNU GPL version 2 or any later version
*/

// protect against direct access
if (!defined('CPG_NUKE')) { exit; }

// initiate the page title
$pagetitle .= 'Hunk of the Day';

// include the header in the page generation
require_once('header.php');

// start a new table in which we will show some text
OpenTable();
echo "<center>New hunk at the stroke of midnight</center>";
CloseTable();

OpenTable();

// show the text on the page
$day = date('d');
$month = date('m');
$year = date('Y');
echo "<table border=\"1\" width=\"100%\"><tr><td> ";
echo "<center><b><big>Hunk of the Day</big></b></center><br>";
echo "<center><img src='images/hunks/$month-$day-$year.jpg' border='no'></center>";
echo "</td></tr></table>";

// close the table that we have created
CloseTable();

// there isn't any need to include the footer, as the index page handles this already
// require('footer.php');

