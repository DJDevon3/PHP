<?php
/*********************************************
  DF_Skype 2.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
define("_SKP_SKNAME","Skype Me!");
define("_SKP_CALLME","Chat with ");
define("_SKP_CONTACT","Add Me 2 Friends");
define("_SKP_CHAT","Start Text Chat");
define("_SKP_PROFILE","View My Profile");
define("_SKP_SENDFILE","Send File");
define("_SKP_VOICEMAIL","Leave Voice Mail");
define("_SKP_DOWNLOAD","Download Skype Here");
define("_SKP_SELECT","Or select an option");
define("_SKP_USERNAME","Username:");
define("_SKP_TITLE","Optional Title: (leave blank if none wanted)");
define("_SKP_BUTTON_NAME","Live Status Button Type:");
?>