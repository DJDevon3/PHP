<?php
/*********************************************
  DF_Skype 2.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
    OpenTable();
    echo '<div align="center">'."\n";
    echo '<b>DF_Skype is an administration module only.</b><br /><br />There is no public view of this module yet.'."\n";
    if (can_admin('MyStatus')) {
        echo '<br /><br /><a href="'.adminlink("DF_Skype").'">Skype Administration</a>'."\n";
    }
    CloseTable();
    echo '</div>'."\n";

?>