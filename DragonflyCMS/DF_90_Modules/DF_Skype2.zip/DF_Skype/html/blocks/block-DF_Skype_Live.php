<?php
/*********************************************
  DF_Skype 2.0 
  ********************************************
*   Credit to Skype for Xoops by Mel Bezos, <http://www.bezoops.net>

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com

**********************************************/
if (!defined('CPG_NUKE')) { exit; }
global $db, $prefix;
get_lang('skype');

$result = $db->sql_query("SELECT skype_username, skype_title, button_name FROM ".$prefix."_skype");
while (list($skype_username, $skype_title, $button_name) = $db->sql_fetchrow($result)) {
	$content ='';
$content .= '<div align="center">';
$content .= '<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>';
$content .= '<a href="skype:'.$skype_username.'?call" onclick="return skypeCheck();"><img src="http://mystatus.skype.com/'.$button_name.'/'.$skype_username.'" border="0" width="114" height="20" alt="My status" /></a><br />';
if (isset($skype_title)) {
	$content .= ""._SKP_CALLME." ".$skype_title."";
}
$content .= '<br /><br /><a href="http://www.skype.com/download/" target="blank">'._SKP_DOWNLOAD.'</a>';
$content .= '</div>';
};
?>