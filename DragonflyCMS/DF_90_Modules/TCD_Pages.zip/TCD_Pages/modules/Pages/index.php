<?php
if (!defined('CPG_NUKE')) { exit; }
/*---------------------------------------------------------
  Description:
  iframe Module - CPG-Nuke Compatible
  By: Stephen2417 aka HomeSlice (stephen2417@gmail.com)
  www.stephen2417.com
  Copyright � 2004 by Stephen2417
 ---------------------------------------------------------
  Instructions:
  Save as index.php, Upload to /modules/NAME/
  (change the name if you wish to have more than one)
  then fill in the config (url and size).
  ---------------------------------------------------------*/
/*--------------------[START CONFIG]-----------------------*/
$url = 'http://www.TreasureCoastDesigns.com/modules/Pages/pages.html'; /* URL */
$size = array(
'width'  => '100%', /* Width */
'height' => '100%'  /* Height */
);
$pagetitle .= 'Pages';
/*---------------------[END CONFIG]------------------------*/

require_once('header.php');
OpenTable();
echo '<center>'
    .'<iframe src="'.$url.'" width="'.$size['width'].'" height="'.$size['height'].'" BORDER=0 FRAMEBORDER=0 FRAMESPACING=0>'
    .'Your browser dosen\'t support iframe\'s, Get Firefox - getfirefox.com'
    .'</iframe>'
    .'</center>';
CloseTable();
?>