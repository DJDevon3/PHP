<?php

if (!defined('CPG_NUKE')) { exit; }

/************************************************************************/
/* Cafepress Block 1.0 : For Dragonfly 9.0.x						    */
/* =================================================================    */
/*                                                                      */
/* Copyright (c) 2002 by Carl W. Brooks (info@palmloyal.com)            */
/* http://www.palmloyal.com                                             */
/*                                                                      */
/* Modified by 'American' for DF. This version does NOT have the Sell   */
/* Your Own Logo Items affiliate signup code. Change "YourID" to your   */
/* CafePress ID and upload to /blocks - August 7, 2005                  */
/*                                                                      */
/* To use this block you only need to download .jpg images				*/
/* from CafePress.com site and copy them to the /images/cafepress       */
/* directory, then edit the $cafepress_id variable to fit your ID       */
/* of the Associates program.									        */
/*																	    */
/* You can redistribute it and/or modify							    */
/* This script is distributed under the terms							*/
/* of the GNU General Public License as published by					*/
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
global $module_name, $db, $prefix;

$result = $db->sql_query("SELECT store1, store2, store3, store4, store5, store6, store7, store8 FROM ".$prefix."_cafepress");
    list($store1, $store2, $store3, $store4, $store5, $store6, $store7, $store8) = $db->sql_fetchrow($result);

$url = 'http://www.cafepress.com/';
$item = $_GET['item'];
$cafepress_id = $store1;
$content ='<script language="JavaScript1.1" src="http://www.cafepress.com/commonscripts.js"></script>';
mt_srand((double)microtime()*1000000);
$imgs = dir('modules/'.$module_name.'/images');
while ($file = $imgs->read()) {
    if (eregi("gif", $file) || eregi("jpg", $file) || eregi("png", $file)) {
   $imglist = $file;
    }
}
closedir($imgs->handle);
$imglist = explode(" ", $imglist);
$a = sizeof($imglist)-2;
$random = mt_rand(0, $a);
$image = $imglist[$random];
$prodid = explode(".", $image);
if (($prodid) AND ($image)) {
$content = "<center><a href=\"index.php?name=CafePress&amp;file=index&amp;item=".$cafepress_id.$prodid[0]."\">";
$content .= "<img src=\"".$imgs."/".$image."\" border=\"0\" width=\"150\" height=\"150\" alt=\"When you purchase items you are supporting us!\"></a></center>";
   }

$content .= "<center><a href=\"index.php?name=CafePress&amp;file=index&amp;item=".$cafepress_id."\">See More Items...</a></center>";


?>