<?php
/*********************************************
  CPG Dragonfly™ CMS
  ********************************************
  Copyright © 2004-2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version
*******************************************************/
if (!defined('CPG_NUKE')) { exit; }
define('_CAFEPRESS','Online Store');
define('_PRINTER','Printer Friendly Page');
define('_PDATE','Date:');
define('_PTOPIC','Topic:');
define('_COMESFROM','This article comes from');
define('_THEURL','The URL for this story is:');
define('_DATE','Date');
define("_CAFECONFIG","CafePress Module by <a href=\"http://www.wind0hz98.com\" target=\"_blank\">Wind0hz98 Inc.</a>");
define("_CAFECONFIG2","Ported by <a href=\"http://www.TreasureCoastDesigns.com\" target=\"_blank\">DJDevon3</a>");
define('_STORE1','Store 1');
define('_STORE2','Store 2');
define('_STORE3','Store 3');
define('_STORE4','Store 4');
define('_STORE5','Store 5');
define('_STORE6','Store 6');
define('_STORE7','Store 7');
define('_STORE8','Store 8');
?>