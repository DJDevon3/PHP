<?php
/**********************************************************************
Dragonfly CafePress Version 1.0
Released under the GNU General Public License
***********************************************************************
Ported to CPG Dragonfly™ CMS by: DJDevon3
Original CafePress 2.0 by: www.wind0hz98.com
**********************************************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class cafepress {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function cafepress() {
		$this->radmin = true;
		$this->version = '2.0';
		$this->modname = 'CafePress';
		$this->description = 'A simple way to display your CafePress store';
		$this->author = 'Original by Wind0hz98 Inc. Ported by TCD';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('cafepress');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'cafepress', "
			store1 varchar(50) NOT NULL default '',
			store2 varchar(50) NOT NULL default '',
			store3 varchar(50) NOT NULL default '',
			store4 varchar(50) NOT NULL default '',
			store5 varchar(50) NOT NULL default '',
			store6 varchar(50) NOT NULL default '',
			store7 varchar(50) NOT NULL default '',
			store8 varchar(50) NOT NULL default '',
			PRIMARY KEY (store1),
			KEY store1 (store1)", 'store1');

			$installer->add_query('INSERT', 'cafepress', "'Store 1 Name','','','','','','',''");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'cafepress');	
		return true;
	}
}
?>