<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
require_once('services.php');
    global $prefix, $db, $module_name, $Default_Theme;
    $result = $db->sql_query("SELECT * FROM ".$prefix."_speedtest");
    list($isp, $start_image, $progress_image, $graph_image, $bar_height, $bar_width, $meter_display, $stlog, $payload_size, $message1, $message2) = $db->sql_fetchrow($result);
?>

<html>
<head>
<title><?php echo $isp; ?> <? echo""._ST_WINDOWTITLE."" ?> </title>
<link rel="stylesheet" href="themes/<?php echo $Default_Theme; ?>/style/style.css">
</head>
<body>

<?php
$kbps = round($_GET['kbps'], 2);
$ksec = round($kbps / 8, 2);
$mbps = round($kbps / 1024, 2);
$msec = round($mbps / 8, 2);
?>

<div align="center"><? echo ""._ST_YOURRESULTS."" ?>:<br />

<?php
if ($mbps > 1){
    echo "<div align='center' class='pagetitle'>";
    printf ("%.2f", $mbps);
    echo "&nbsp;Mb<br /></div>";
    }else{
    echo "<div align='center' class='pagetitle'>";
    printf ("%.2f", $kbps);
    echo "&nbsp;kb<br /></div>";
    }
if ($msec > 1){
    echo "<div align='center' class='pagetitle'>"._ST_WHATMEAN." " . $msec . " "._ST_MBPERSEK."<br /></div>";
    }else{
    echo "<div align='center' class='pagetitle'>"._ST_WHATMEAN_." " . $ksec . " "._ST_KBPERSEK."<br /></div>";
    }
?>

<table cellspacing="0" cellpadding="2" border="0"><tr><td class="table1">
<table cellspacing="0" cellpadding="0" border="0">

<?php
$service_speeds = array();
foreach(array_keys($services) as $service){
    array_push ($service_speeds, $service);
    }
$max_in_array = max ($service_speeds);
if ($kbps > $max_in_array){
    $bar_scale = 400 / $kbps;
    }else{
    $bar_scale = 0.075;
    }
foreach(array_keys($services) as $service){
    if (($service > $kbps) && $you_out == False){
        $bar_size = $kbps * $bar_scale;
        $you_bar_height = $bar_height + 1;
        echo "<tr>\n";
        echo "<td class='row1' align='left'><font class='content'><b>".$kbps." kbps</b></td>\n";
        echo "<td align='center'>&nbsp;</td>\n";
        if ($mbps > 1){
            echo "<td class='row1'><img src='modules/".$module_name."/images/".$graph_image."' height=".$bar_height." width=".$bar_size." alt=\"\" />&nbsp;<b>"._ST_YOURCURRENTRESULTS." " . $mbps . " Mb</b></td>\n";
            }else{
            echo "<td class='row1'><img src='modules/".$module_name."/images/".$graph_image."' height=".$bar_height." width=".$bar_size." alt=\"\" />&nbsp;<b>"._ST_YOURCURRENTRESULTS." " . $kbps . "Kb</b></td>\n";
            }
        echo "</tr>\n";
        $you_out = True;
        }
    $name = $services[$service]["name"];
    $image = $services[$service]["image"];
    $bar_size = $service * $bar_scale;
    echo "<tr>\n";
    echo "<td class='row1'>".$service." kbps</td>\n";
    echo "<td align=\"center\">&nbsp;</td>\n";
    echo "<td class='row1'><img src=".$image." height=".$bar_height." width=".$bar_size." alt=\"\" />&nbsp;$name</td>\n";
    echo "</tr>\n";
    }
if ($you_out == False){
    $bar_size = $kbps * $bar_scale;
    $you_bar_height = $bar_height + 5;
    echo "<tr>\n";
    echo "<td class='row1'><b>".$kbps." kbps</b></td>\n";
    echo "<td align=\"center\">&nbsp;</td>\n";
    echo "<td class='row1'><img src='modules/".$module_name."/images/".$graph_image."' height=".$bar_height." width=".$bar_size." alt=\"\" />&nbsp;<b>"._ST_YOURCURRENTRESULTS."</b></td>\n";
    echo "</tr>\n";
    }
?>

</table>
</table>
<br />

<?php
if ($meter_display == 1){
    $linkpath = "?name=".$module_name."&amp;file=initialmeter";
    }else{
    $linkpath = "?name=".$module_name."&amp;file=meter";
    }


	echo "<a href=".$linkpath.">"._ST_REPEATTEST."</a>&nbsp;&nbsp;";
	echo "<a href=\"javascript:window.close()\">"._ST_CLOSEWINDOW."</a>";
	echo "<br /><br />";

?>
</div>
</body>
</html>

<?php

if ($kbps != "" && $stlog = '1'){
    $ip = $_SERVER['REMOTE_ADDR'];
    $name = gethostbyaddr($ip);
    $result = $db->sql_query("INSERT INTO ".$prefix."_speedtest_results (speed, ip, name) VALUES ($kbps, '$ip', '$name')");
    }else {
        die("The entry was not entered into the database.");
    }
?>
