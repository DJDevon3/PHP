<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class Speed_Test {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function Speed_Test() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'Speed_Test';
		$this->description = 'Connectivity Bandwidth Speed Test';
		$this->author = 'DJDevon3';
		$this->website = 'TreasureCoastDesigns.com';
		$this->dbtables = array('speedtest', 'speedtest_results');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'speedtest', "
			isp varchar(255) NOT NULL default '',
			start_image varchar(50) NOT NULL default '',
			progress_image varchar(50) NOT NULL default '',
			graph_image varchar(50) NOT NULL default '',
			bar_height varchar(5) NOT NULL default '',
			pop_width varchar(5) NOT NULL default '',
			pop_height varchar(5) NOT NULL default '',
			meter_display char(1) NOT NULL default '',
			stlog char(1) NOT NULL default '',
			payload_size varchar(10) NOT NULL default '',
			message1 blob NOT NULL default '',
			message2 blob NOT NULL default '',
			PRIMARY KEY (isp),
			KEY isp (isp)", 'speedtest');

		$installer->add_query('CREATE', 'speedtest_results', "
			speed varchar(10) NOT NULL default '',
			ip varchar(21) NOT NULL default '',
			name varchar(50) NOT NULL default '',
			PRIMARY KEY (speed),
			KEY ip (ip)", 'speedtest_results');

			$installer->add_query('INSERT', 'speedtest', "'TreasureCoastDesigns.com', 'English-Start.gif', 'ProgressBar.gif', '5.gif', '15', '600', '370', '1', '0', '512', 'Welcome to our internet connectivity speed test.<br />Speed Test will check the bandwidth of your Internet connection and compare it against DSL, cable modem, and other broadband connections. It is as easy as 1-2-3...', 'What is Speed Test?<br />When you click the \'Go\' button, then our server send you KB file. Download times are then used to calculate the bandwidth speed from your computer to our Internet site. Your bandwidth speed may be affected by many factors.<br /><br />Why use Speed Test?<br />Often, users perform this test simply out of curiosity, to see what the actual throughput is from their computer to our Internet site.  It can also be a good troubleshooting tool for connectivity issues to websites.<br /><br /> What can affect Speed Test results?<br /><li>Being outside of the our server country or far away from the location of our servers.</li><li>Performing other downloads at the same time that this test is executed.</li><li>Executing programs that use your bandwidth while this test is being run</li><li>Broadband users: The quality of your connection is paramount. In many cases, users will find they have line noise. This is primarily caused by stray electromagnetic energy creeping into their wiring, which degrades the quality of signals in hard-wired circuits, e.g. telephone lines, cable systems, LAN connections. This causes data error correction to take place, thereby limiting the throughput to your computer.</li><li>Dial-up users: Please note, 56K modems are limited by FCC regulations to 53K.</li><li>When our server is ower burdened.</li>'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'speedtest');	
		$installer->add_query('DROP', 'speedtest_results');	
		return true;
	}
}
?>