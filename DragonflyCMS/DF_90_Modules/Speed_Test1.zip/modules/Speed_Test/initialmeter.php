<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
    global $prefix, $db, $module_name, $Default_Theme;
	$result = $db->sql_query("SELECT progress_image FROM ".$prefix."_speedtest");
    list($progress_image) = $db->sql_fetchrow($result);
?>

<html>
    <head>
        <title><?php echo $isp; ?> <? echo ""._ST_WINDOWTITLEINITIAL."" ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Expires" content="Fri, Jun 12 1981 08:20:00 GMT" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Cache-Control" content="no-cache" />
<link rel="stylesheet" href="themes/<?php echo $Default_Theme; ?>/style/style.css">
    </head>
<body>
	<?php         
		echo "<table border='0' cellpadding='0' cellspacing='0' align='center'><tr valign='middle'>";
		echo "<td height='450' align='center' class='title'>"._ST_INITIALNOTE1."";
		echo "<br /><br />";
		echo ""._ST_INITIALNOTE2."";
		echo "<br /><br />";
		echo "<img src='modules/".$module_name."/images/".$progress_image."' border='0' alt='' />";
		echo "</td></tr></table>";
	?>
<script language="javascript" type="text/javascript">
<!--
    time      = new Date();
    starttime = time.getTime();
// -->
</script>

<?php

    $data_file = "modules/".$module_name."/payload.bin";
    if ( $fd = fopen ($data_file, "rb") ) {
        $test_kbytes = 128;

        $contents = fread ($fd, $test_kbytes * 1024);

        echo "<!-- $contents -->";
        fclose ($fd);
    } else {
        die("Error: Step 1 Initialization Failure");
    }

?>

<script language="javascript" type="text/javascript">
<!--
    time         = new Date();
    endtime      = time.getTime();
    if (endtime == starttime)
        {downloadtime = 0
        }
    else
    {downloadtime = (endtime - starttime)/1000;
    }

    kbytes_of_data = <?php echo $test_kbytes; ?>;
    linespeed      = kbytes_of_data/downloadtime;
    kbps           = (Math.round((linespeed*8)*10*1.024))/10;

    nextpage='?name=<?php echo $module_name; ?>&file=meter&kbps=' + kbps;
    document.location.href=nextpage
// -->
</script>
</body>
</html>
