<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
$services = array(
       "56.0" => array ("name" => "56k modem "
         , "image" => "modules/".$module_name."/images/1.gif"
        )
     , "64.0" => array ("name" => "64k super modem"
         , "image" => "modules/".$module_name."/images/1.gif"
        )
     , "128.0" => array ("name" => "128k ISDN "
         , "image" => "modules/".$module_name."/images/2.gif"
        )
     , "256.0" => array ("name" => "256k ADSL "
         , "image" => "modules/".$module_name."/images/2.gif"
        )
     , "512.0" => array ("name" => "512k ADSL Pro "
         , "image" => "modules/".$module_name."/images/2.gif"
        )
     , "768.0" => array ("name" => "768k"
         , "image" => "modules/".$module_name."/images/2.gif"
        )
     , "1000.0" => array ("name" => "1 Mb "
         , "image" => "modules/".$module_name."/images/3.gif"
        )
     , "1500.0" => array ("name" => "1.5 Mb"
         , "image" => "modules/".$module_name."/images/3.gif"
        )
     , "2000.0" => array ("name" => "2 Mb "
         , "image" => "modules/".$module_name."/images/3.gif"
        )
     , "3000.0" => array ("name" => "3 Mb"
         , "image" => "modules/".$module_name."/images/4.gif"
        )
     , "6000.0" => array ("name" => "6 Mb"
         , "image" => "modules/".$module_name."/images/4.gif"
        )
    );
