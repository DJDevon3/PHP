<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
require_once('header.php');

    global $prefix, $db, $module_name;
    $result = $db->sql_query("SELECT start_image, pop_width, pop_height, message1, message2 FROM ".$prefix."_speedtest");
    list($start_image, $pop_width, $pop_height, $message1, $message2) = $db->sql_fetchrow($result);

echo "<script language=\"javascript\" type=\"text/javascript\">\n";
echo "<!--\n";
echo "function OpenMeter(meter_page){\n";
echo "window.open(meter_page,\"meter\",\"width=".$pop_width.",height=".$pop_height."\"); \n";
echo "}\n";
echo "//-->\n";
echo "</script>\n\n";

OpenTable();
echo "<table border='0' cellspacing='0' cellpadding='20'><tr><td align='center'><b>".$message1."</b></td></tr>";
echo "<tr><td class='content'><hr />".$message2."</td></tr>\n";
echo "<tr><td align='center'><hr />";
echo "<a href=\"?name=".$module_name."&file=initialmeter\" onclick=\"OpenMeter('?name=".$module_name."&file=initialmeter');return false\"><img src=\"modules/".$module_name."/images/".$start_image."\" border=\"0\" alt=\""._ST_START."\" title=\""._ST_START."\" /><br /></a>\n";
echo "</td></tr></table>\n";
CloseTable();

?>