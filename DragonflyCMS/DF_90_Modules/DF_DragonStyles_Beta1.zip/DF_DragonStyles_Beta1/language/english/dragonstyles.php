<?php
/************************************************************************/
/* THEMECP 1.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) 2004 by Mtechnik                                       */
/* http://mtechnik.net                                                  */
/* Made for PHP-Nuke ported to DragonflyCMS       */
/* ============================================                         */
/************************************************************************/
// Theme Cpanel
// Original Author of file: Mtechnik - http://mtechnik.net
//
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// and 
// SafeCracker4Hire - http://www.kylestubbins.com
//
// Developed at the1theme.com
// Copyright � 2004 by Mtechnik All Rights Reserved
// Copyright � 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from Mtechnik.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos with mtechnik
// or mdesign. Furthermore, these notices must remain visible.
// This theme license does not imply license to resell or
// redistribute any of those items without expressed permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3 and SafeCracker4Hire
// All support should be found either at DragonflyCMS.com or TreasureCoastDesigns.com
// Mtechnik & DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
define("_THEMECONFIG","DragonStyles by <a href=\"http://www.TreasureCoastDesigns.com\" target=\"_blank\">DJDevon3</a>");
define("_THEMECONFIG2","Based on Mtechniks ThemeCP Module");
define("_DRAGONSTYLES","Dragonfly Theme Control Panel");
define("_THEMESETUP","For DragonStyles Compatible Themes");
define("_MSG1","Message 1 input");
define("_MSG2","Message 2 input");
define("_MSG3","Message 3 input");
define("_LINK1NAME","Link1 name");
define("_LINK2NAME","Link2 name");
define("_LINK3NAME","Link3 name");
define("_LINK4NAME","Link4 name");
define("_LINK5NAME","Link5 name");
define("_LINK6NAME","Link6 name");
define("_LINK7NAME","Link7 name");
define("_LINK8NAME","Link8 name");
define("_LINK9NAME","Link9 name");
define("_LINK10NAME","Link10 name");
define("_LINK1URL","Link1 url");
define("_LINK2URL","Link2 url");
define("_LINK3URL","Link3 url");
define("_LINK4URL","Link4 url");
define("_LINK5URL","Link5 url");
define("_LINK6URL","Link6 url");
define("_LINK7URL","Link7 url");
define("_LINK8URL","Link8 url");
define("_LINK9URL","Link9 url");
define("_LINK10URL","Link10 url");
define("_FLASH","Flash Fx:");
define("_SEARCHBOX","SearchBox:");
define("_DSON","On");
define("_DSOFF","Off");
//End theme cpanel

?>