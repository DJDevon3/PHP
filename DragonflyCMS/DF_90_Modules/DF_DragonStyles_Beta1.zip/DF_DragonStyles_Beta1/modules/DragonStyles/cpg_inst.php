<?php
/**********************************************************************
Dragon Styles Version 1.0
Release Date:
Released under the GNU General Public License
***********************************************************************
DragonStyles Team: DJDevon3,
**********************************************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class DragonStyles {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function DragonStyles() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'DragonStyles';
		$this->description = 'A comprehensive Theme Control Panel for DragonflyCMS';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('dragonstyles_module, dragonstyles_news, dragonstyles_bb, dragonstyles_gallery');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'dragonstyles_modules', "
			msg1 varchar(209) NOT NULL default '',
			msg2 varchar(209) NOT NULL default '',
			msg3 varchar(209) NOT NULL default '',
			link1 varchar(25) NOT NULL default '',
			link2 varchar(25) NOT NULL default '',
			link3 varchar(25) NOT NULL default '',
			link4 varchar(25) NOT NULL default '',
			link5 varchar(25) NOT NULL default '',
			link6 varchar(25) NOT NULL default '',
			link7 varchar(25) NOT NULL default '',
			link8 varchar(25) NOT NULL default '',
			link9 varchar(25) NOT NULL default '',
			link10 varchar(25) NOT NULL default '',
			link1url varchar(255) NOT NULL default '',
			link2url varchar(255) NOT NULL default '',
			link3url varchar(255) NOT NULL default '',
			link4url varchar(255) NOT NULL default '',
			link5url varchar(255) NOT NULL default '',
			link6url varchar(255) NOT NULL default '',
			link7url varchar(255) NOT NULL default '',
			link8url varchar(255) NOT NULL default '',
			link9url varchar(255) NOT NULL default '',
			link10url varchar(255) NOT NULL default '',
			searchbox tinyint(1) NOT NULL default '1',
			flash tinyint(1) NOT NULL default '1',
			blockheadbg varchar(50) NOT NULL default '',
			cellpic1 varchar(50) NOT NULL default '',
			cellpic2 varchar(50) NOT NULL default '',
			cellpic3 varchar(50) NOT NULL default '',
			blockheadborder varchar(6) NOT NULL default '0',
			blockcontentcolor varchar(6) NOT NULL default '',
			blockcontentborder varchar(6) NOT NULL default '0',
			gfxcheck varchar(10) NOT NULL default '',
			textcolor1 varchar(6) NOT NULL default '',
			textcolor2 varchar(6) NOT NULL default '',
			textcolor3 varchar(6) NOT NULL default '',
			textcolor4 varchar(6) NOT NULL default '',
			backgroundcolor1 varchar(6) NOT NULL default '',
			backgroundcolor2 varchar(6) NOT NULL default '',
			bodytext varchar(6) NOT NULL default '',
			bodylink varchar(6) NOT NULL default '',
			bodyhover varchar(6) NOT NULL default '',
			PRIMARY KEY (msg1),
			KEY msg1 (msg1)", 'dragonstyles_modules');

			$installer->add_query('INSERT', 'dragonstyles_modules', "'DragonStyle Rocks!', 'Message 2', 'Message 3', 'Home', 'Gallery', 'Forums', 'Downloads', 'Links', 'Surveys', 'Tell Friend', 'Top 10', 'Our Sponsors', 'Contact Us', 'index.php', 'index.php?name=coppermine', 'index.php?name=Forums', 'index.php?name=Downloads', 'index.php?name=Web_Links', 'index.php?name=Surveys', 'index.php?name=Tell_a_Friend', 'index.php?name=Top', 'index.php?name=Our_Sponsors', 'index.php?name=Contact','0', '0', 'images/cellpic3.gif', 'images/cellpic3.gif', 'images/cellpic3.gif', 'images/cellpic3.gif', '006699', 'EFEFEF', '006699', 'AEFF00', 'FF0000', '000000', '000000', '000000', 'cccccc', '006699', 'FFFFFF', '006699', '000000'");

		$installer->add_query('CREATE', 'dragonstyles_news', "
			newstext varchar(7) NOT NULL default '',
			newslink varchar(7) NOT NULL default '',
			newshover varchar(7) NOT NULL default '',
			PRIMARY KEY (newstext),
			KEY newstext (newstext)", 'dragonstyles_news');

			$installer->add_query('INSERT', 'dragonstyles_news', "'000000', 'DCDCDC', 'AEFF00'");

		$installer->add_query('CREATE', 'dragonstyles_bb', "
			forumtext varchar(6) NOT NULL default '',
			forumhover varchar(6) NOT NULL default '',
			forumcodebg varchar(6) NOT NULL default '',
			forumquotebg varchar(255) NOT NULL default '',
			forumrank1 varchar(255) NOT NULL default '',
			forumrank2 varchar(255) NOT NULL default '',
			forumrank3 varchar(255) NOT NULL default '',
			forumrank4 varchar(255) NOT NULL default '',
			forumrank5 varchar(255) NOT NULL default '',
			forumheader1 varchar(255) NOT NULL default '',
			forumheader2 varchar(255) NOT NULL default '',
			forummarquee varchar(255) NOT NULL default '',
			PRIMARY KEY (forumtext),
			KEY forumtext (forumtext)", 'dragonstyles_bb');

			$installer->add_query('INSERT', 'dragonstyles_bb', "'000000', 'AEFF00', 'FEFE00', 'FEFE00', 'images/ranks/rank1.gif', 'images/ranks/rank2.gif', 'images/ranks/rank3.gif', 'images/ranks/rank4.gif', 'images/ranks/rank5.gif', 'AEFF00', 'AEFF00', 'Welcome to the Forums'");

		$installer->add_query('CREATE', 'dragonstyles_gallery', "
			cellpic varchar(255) NOT NULL default '',
			mainmenubg varchar(255) NOT NULL default '',
			textcolor varchar(255) NOT NULL default '',
			hover varchar(255) NOT NULL default '',
			backgroundcolor1 varchar(255) NOT NULL default '',
			backgroundcolor2 varchar(255) NOT NULL default '',
			PRIMARY KEY (cellpic),
			KEY cellpic (cellpic)", 'dragonstyles_gallery');

			$installer->add_query('INSERT', 'dragonstyles_gallery', "'images/cellpic1.gif', 'images/cellpic2.gif', 'FFFFFF', 'AEFF00', '000000', '000000'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'dragonstyles_modules');
		$installer->add_query('DROP', 'dragonstyles_news');
		$installer->add_query('DROP', 'dragonstyles_bb');
		$installer->add_query('DROP', 'dragonstyles_gallery');
		return true;
	}
}
?>