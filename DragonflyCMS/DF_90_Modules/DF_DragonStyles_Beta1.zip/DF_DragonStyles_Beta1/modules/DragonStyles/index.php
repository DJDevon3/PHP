<?php

if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
    OpenTable();
    echo '<div align="center">'."\n";
    echo '<b>Dragon Styles is an administration module only.</b><br /><br />It is only used for customizing themes.'."\n";
    if (can_admin('autoheader')) {
        echo '<br /><br /><a href="'.adminlink("DragonStyles").'">Theme Control Panel</a>'."\n";
    }
    CloseTable();
    echo '</div>'."\n";

?>