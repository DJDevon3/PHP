<?
/************************************************************************/
/* MyStatus 1.0 FOR DRAGONFLYCMS                            */
/* ============================================                         */
/* Copyright (c) 2004 by DJDevon3                                       */
/* http://www.TreasureCoastDesigns.com                        */
/* Made for DragonflyCMS                                */
/* ============================================                         */
/************************************************************************/
// My Status
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// Copyright � 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from DJDevon3.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
//Code Contributions: DJMaze, T31os, Anthony, xFSUNOLESx, Biggles, DarkGrue from DragonflyCMS.com

include('includes/cmsinit.inc');

list($themestatus, $modulestatus, $documentstatus, $themepercent, $modulepercent, $documentpercent, $themename, $modulename, $documentname) = 
    $db->sql_ufetchrow("SELECT themestatus, modulestatus, documentstatus, themepercent, modulepercent, documentpercent, themename, modulename, documentname FROM {$prefix}_mystatus");

$image = "modules/MyStatus/StatusSig.gif"; //Specify the name of the gif signature img you want to use (MUST BE A GIF)
$im = imagecreatefromgif($image);

/* 
Deciphering the ImageColorAllocate 
( 2, 0, 0) Simple RGB Values
1st # = Red Value 
2nd # = Green Value 
3rd # = Blue Value 
*/

// Allocate colors
$red = ImageColorAllocate ($im, 255, 0, 0);
//$blue = ImageColorAllocate ($im, 0, 0, 255);
//$green = ImageColorAllocate ($im, 0, 255, 0);
$white = ImageColorAllocate ($im, 255, 255, 255);
$black = ImageColorAllocate ($im, 0, 0, 0);
$lightblue = ImageColorAllocate ($im, 153, 204, 255);
$lime = imagecolorallocate ($im, 153, 255, 0);
//$orange = ImageColorAllocate ($im, 255, 153, 0);
//$yellow = ImageColorAllocate ($im, 255, 255, 0);

// Theme Status
imageellipse ($im, 105, 14, 6, 6, $black);
if ($themestatus) {
    $status1 = " Active ";
    imagefilledellipse ($im, 105, 14, 4, 4, $lime);
	ImageString($im, 10, 30, 30, "$themename", $lightblue);
	ImageString($im, 12, 425, 15, "$themepercent", $black);
} else {
    $status1 = " Non-Active";
    imagefilledellipse ($im, 105, 14, 4, 4, $red);
}

// Module Status
imageellipse ($im, 197, 14, 6, 6, $black);
if ( $modulestatus ) {
    $status2 = " Active";
    imagefilledellipse ($im, 197, 14, 4, 4, $lime);
	ImageString($im, 10, 30, 30, "$modulename", $lightblue);
	ImageString($im, 12, 425, 15, "$modulepercent", $black);
} else {
    $status2 = " Non-Active";
    imagefilledellipse ($im, 197, 14, 4, 4, $red);
}

// Document Status
imageellipse ($im, 300, 14, 6, 6, $black);
if ( $documentstatus ) {
    $status3 = " Active ";
    imagefilledellipse ($im, 300, 14, 4, 4, $lime);
	ImageString($im, 10, 30, 30, "$documentname", $lightblue);
	ImageString($im, 12, 425, 15, "$documentpercent", $black);
} else {
    $status3 = " Non-Active";
    imagefilledellipse ($im, 300, 14, 4, 4, $red);
}

/* 
Deciphering the ImageString 
( 2, 0, 0) 
1st # = Font Size 
2nd # = Pixels from left 
3rd # = Pixels from top 
*/

// Start a new output buffer.
ob_start(); 

imagegif($im);
$img_data = ob_get_contents();
$img_length = ob_get_length();

ob_end_clean();

imagedestroy ($im);

// Send appropriate headers.
header('Content-Type: image/gif');
header("Content-Length: $img_length");
header('Cache-Control: public', TRUE);

// Push image to client.
echo $img_data; 