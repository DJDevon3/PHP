<?php
/************************************************************************/
/* MyStatus 1.0 FOR DRAGONFLYCMS										*/
/* ============================================                         */
/* Copyright (c) 2004 by DJDevon3                                       */
/* http://www.TreasureCoastDesigns.com									*/
/* Made for DragonflyCMS												*/
/* ============================================                         */
/************************************************************************/
// My Status
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// Copyright © 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from DJDevon3.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class MyStatus {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function MyStatus() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'MyStatus';
		$this->description = 'For remote display of your project status in a forum signature.';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('mystatus');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'mystatus', "
			themestatus tinyint(1) NOT NULL default '0',
			modulestatus tinyint(1) NOT NULL default '0',
			documentstatus tinyint(1) NOT NULL default '0',
			themepercent varchar(3) NOT NULL default '',
			modulepercent varchar(3) NOT NULL default '',
			documentpercent varchar(3) NOT NULL default '',
			themename varchar(180) NOT NULL default '',
			modulename varchar(180) NOT NULL default '',
			documentname varchar(180) NOT NULL default '',
			PRIMARY KEY (themestatus),
			KEY themestatus (themestatus)", 'mystatus');

			$installer->add_query('INSERT', 'mystatus', "'0', '0', '0', '50', '50', '50', 'Theme Name', 'Module Name', 'Document Name'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'mystatus');	
		return true;
	}
}
?>