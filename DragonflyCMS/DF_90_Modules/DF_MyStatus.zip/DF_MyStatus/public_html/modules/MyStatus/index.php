<?php
/************************************************************************/
/* MyStatus 1.0 FOR DRAGONFLYCMS										*/
/* ============================================                         */
/* Copyright (c) 2004 by DJDevon3                                       */
/* http://www.TreasureCoastDesigns.com									*/
/* Made for DragonflyCMS												*/
/* ============================================                         */
/************************************************************************/
// My Status
// DJDevon3 - http://www.TreasureCoastDesigns.com 
// Copyright � 2005 by TCD All Rights Reserved
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written 
// permission from DJDevon3.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// DJDevon3 are not liable for any products or services affected by means of the script.
// The user must assume the entire risk of using the program.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');
    OpenTable();
    echo '<div align="center">'."\n";
    echo '<b>My Status is an administration module only.</b><br /><br />It is only used for displaying your project status in a remote forum signature.'."\n";
    if (can_admin('MyStatus')) {
        echo '<br /><br /><a href="'.adminlink("MyStatus").'">My Status Control Panel</a>'."\n";
    }
    CloseTable();
    echo '</div>'."\n";

?>