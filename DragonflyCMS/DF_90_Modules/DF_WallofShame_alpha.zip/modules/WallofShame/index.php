<?php
/*WALL OF SHAME MODULE FOR DRAGONFLYCMS 9.0.6.1
Autor: DJDevon3
Support: www.TreasureCoastDesigns.com
Version: 1.0
License: Open Source GPL
Notes: Please contact author for any modification help or possible license changes or violations.
*/

if (!defined('CPG_NUKE')) { exit; }
require_once('header.php');
global $admin, $prefix, $db, $module_name;

Opentable();
$result3=$db->sql_query("SELECT * FROM ".$prefix."_wallofshame"); 
$total = $db->sql_numrows($result3); 
echo "<table width=\"100%\" border=\"0\" valign=\"top\"><tr><td colspan=\"2\"><center><img src=\"modules/WallofShame/images/WallLogo.gif\" alt=\"The Wall of Shame\" border=\"0\"></center></td></tr></table>";
Closetable();

Opentable();
echo "<center><strong>There are $total lamers on the wall. </strong></center>";
Closetable();

Opentable();
if(!isset($_GET['page'])){ 
    $page = 1; 
} else { 
    $page = $_GET['page']; 
} 
// set number of cheaters to display on each page
$result = $db->sql_query("SELECT results FROM ".$prefix."_wallofshame_cfg");
list($results) = $db->sql_fetchrow($result);

$startinglimit = (($page * $result) - $result);
$sql = $db->sql_query("SELECT * FROM ".$prefix."_wallofshame ORDER BY timestamp ASC LIMIT $startinglimit, $results"); 
while($row = $db->sql_fetchrow($sql)){ 
$name = $row["name"]; 
$timestamp = $row["timestamp"]; 
$violation = $row["violation"];
$server = $row["server"];
$guid = $row["guid"];
$alias = $row["alias"];
$cheatericon = $row["cheatericon"];
$screenshot = $row["screenshot"];
$details = $row["details"];
if ($screenshot == "n/a") {
$dllink = "n/a";
}
else {
$dllink = "<a href='$screenshot'>$name</a>";
}

$cheatericon = $row["cheatericon"];
if ($cheatericon == "n/a") {
$icondisplay = "n/a";
}
else {
$icondisplay = "<img src=\"$cheatericon\" width=\"200\" height=\"200\" border=\"0\" alt=\"$name\"></img>";
}
   echo "<div align=\"center\">";
   echo "<table border=\"0\" cellpadding=\"5\"><tr>";
   echo "<td class=\"cat\" colspan=\"3\"><a href=\"$screenshot\"><big><b><u>$name</u></b></big></a></td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Timestamp:</td>";
   echo " <td width=\"329\" class=\"row1\">$timestamp</td>";
   echo "<td width=\"213\" rowspan=\"7\" valign=\"middle\" align=\"center\" class=\"row2\">$icondisplay</td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Violation:</td>";
   echo "<td width=\"329\" class=\"row1\">$violation</td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Server:</td>";
   echo "<td width=\"329\" class=\"row1\">$server</td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Aliases:</td>";
   echo "<td width=\"329\" class=\"row1\">$alias</td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Details:</td>";
   echo "<td width=\"329\" class=\"row1\">$details</td></tr><tr>";
   echo "<td width=\"129\" class=\"row1\">Guid:</td>";
   echo "<td width=\"329\" class=\"row1\">$guid</td></tr>";
   echo "</table>";
   echo "<br><br></div>";
} 

$total_results = $db->sql_freeresult($db->sql_query("SELECT COUNT(*) as Num FROM ".$prefix."_wallofshame"),0);
$total_pages = ceil($total_results / $result); 

echo "<br><br>Page:<br>";

if($page > 1){
    $prev = ($page - 1);
    echo "<a href=\"index.php?name=WallofShame&amp;page=$prev\">[&lt;&lt; Previous]</a>&nbsp;"; 
} 

for($i = 1; $i <= $total_pages; $i++){ 
    if(($page) == $i){
        echo "$i&nbsp;";
        } else { 
            echo "<a href=\"index.php?name=WallofShame&amp;page=$i\">$i</a>&nbsp;";
    } 
} 

if($page < $total_pages){ 
    $next = ($page + 1); 
    echo "<a href=\"index.php?name=WallofShame&amp;page=$next\">[Next &gt;&gt;]</a>"; 
} 

Closetable();
?> 