<?php
/*WALL OF SHAME MODULE FOR DRAGONFLYCMS 9.0.6.1
Autor: DJDevon3
Support: www.TreasureCoastDesigns.com
Version: 1.0
License: Open Source GPL
Notes: Please contact author for any modification help or possible license changes or violations.
*/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class wallofshame {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function wallofshame() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'Wall of Shame';
		$this->description = 'Introduce the world to all the lamers!';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('wallofshame');
	}

// module installer
	function install() {
		global $installer, $prefix;
		$installer->add_query('CREATE', 'wallofshame', "
			shid int(3) NOT NULL auto_increment,
			name varchar(40) NOT NULL default '',
			timestamp varchar(40) NOT NULL default '',
			violation varchar(40) NOT NULL default '',
			server varchar(40) NOT NULL default '',
			guid varchar(40) NOT NULL default '',
			alias text default '',
			cheatericon varchar(125) NOT NULL default '',
			screenshot varchar(125) NOT NULL default '',
			details text default '',
			counter int(11) NOT NULL default '0',
			PRIMARY KEY (shid),
			KEY shid (shid)", 'wallofshame');

			$installer->add_query('CREATE', 'wallofshame_cfg', "
			results varchar(40) NOT NULL default '',
			PRIMARY KEY (results)", 'wallofshame_cfg');

			$installer->add_query('INSERT', 'wallofshame', "'1', 'Cheater', '12-31-06', 'violation', 'server', 'guid', 'aliases', 'modules/WallofShame/images/busted.gif', 'modules/WallofShame/images/screenshot.jpg', 'details', 'counter'");
			$installer->add_query('INSERT', 'wallofshame_cfg', "'25'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'wallofshame');
		$installer->add_query('DROP', 'wallofshame_cfg');
		return true;
	}
}
?>