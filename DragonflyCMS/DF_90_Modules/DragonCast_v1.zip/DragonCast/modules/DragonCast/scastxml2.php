<?
/*********************************************
  DragonCast 1.0 Scast2
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
// DO NOT EDIT UNLESS YOU KNOW WHAT YOUR DOING
if (!defined('CPG_NUKE')) { exit; }
$success = '';
$success1 = '';
$success2 = '';
$page = '';
global $prefix, $db;
$sql = "SELECT host1name, host, port, password, title, djname, cstmsg, server1msg, activatehost2, host2name, host2, port2, password2, title2, djname2, cstmsg2, server2msg, refresh, extip1, extip2, bgrnd, text, link, vlink, alink, tblhdr, cell, hdrtext, bdytext, height FROM ".$prefix."_dragoncast";
$result = $db->sql_query($sql);
while ($row = $db->sql_fetchrow($result)) {
$host1name = $row['host1name'];
$host = $row['host'];
$port = $row['port'];
$password = $row['password'];
$title = $row['title'];
$djname = $row['djname'];
$cstmsg = $row['cstmsg'];
$server1msg = $row['server1msg'];
$activatehost2 = $row['activatehost2'];
$host2name = $row['host2name'];
$host2 = $row['host2'];
$port2 = $row['port2'];
$password2 = $row['password2'];
$title2 = $row['title2'];
$djname2 = $row['djname2'];
$cstmsg2 = $row['cstmsg2'];
$server2msg = $row['server2msg'];
$refresh = $row['refresh'];
$extip1 = $row['extip1'];
$extip2 = $row['extip2'];
$bgrnd = $row['bgrnd'];
$text = $row['text'];
$link = $row['link'];
$vlink = $row['vlink'];
$alink = $row['alink'];
$tblhdr = $row['tblhdr'];
$cell = $row['cell'];
$hdrtext = $row['hdrtext'];
$bdytext = $row['bdytext'];
$height = $row['height'];
}
if($extip2==""){
$listenlink = "http://$host2:$port2/listen.pls";  //make link to stream
}else {
$listenlink = "http://$extip2:$port2/listen.pls";  //make link to stream
}
$fp = @fsockopen($host2, $port2, $errno, $errstr, 1); //open connection
if(!$fp) {
$success=2;
}
if($success!=2){ //if connection
 fputs($fp,"GET /7.html HTTP/1.0\r\nUser-Agent: DragonCast (Mozilla Compatible)\r\n\r\n"); //get 7.html
 while(!feof($fp)) {
  $page .= fgets($fp, 1000);
 }
 fclose($fp); //close connection
 $page = ereg_replace(".*<body>", "", $page); //extract data
 $page = ereg_replace("</body>.*", ",", $page); //extract data
 $numbers = explode(",",$page); //extract data
 $currentlisteners=$numbers[0]; //set variable
 $connected=$numbers[1]; //set variable
 if($connected==1) //if DSP is connected
  $wordconnected="yes"; //set variable
 else //if no DSP connection
  $wordconnected="no"; //set variable
 $peaklisteners=$numbers[2]; //set variable
 $maxlisteners=$numbers[3]; //set variable
 $reportedlisteners=$numbers[4]; //set variable
}

if($connected==1){  //only do if DSP is connected
 $fp = @fsockopen($host2, $port2, $errno, $errstr, 1);  //open connection
  if(!$fp) { //if no connection
   $success1=2; //dummy variable to see if successful connect
  }
 if($success1!=2){ //only do if connected
  fputs($fp,"GET /index.html HTTP/1.0\r\nUser-Agent: DragonCast (Mozilla Compatible)\r\n\r\n"); //get index.html
  while(!feof($fp)) {
   $page .= fgets($fp, 1000);
  }
  $pageed = ereg_replace(".*Stream is up at ", "", $page); //extract data
  $bitrate = ereg_replace(" kbps.*", "", $pageed); //extract data
  fclose($fp); //close connection
 }
}
$fp = @fsockopen($host2, $port2, $errno, $errstr, 1); //open connection yet again
 if(!$fp) {  //if connection
  $success2=2;
 }
if($success2!=2){ //if connected
 fputs($fp,"GET /admin.cgi?pass=$password2&mode=viewxml HTTP/1.0\r\nUser-Agent: DragonCast (Mozilla Compatible)\r\n\r\n");  //get XML page
 while(!feof($fp)) {
  $page .= fgets($fp, 1000);
 }

 $loop = array("AVERAGETIME", "SERVERGENRE", "SERVERURL", "SERVERTITLE", "SONGTITLE", "SONGURL", "IRC", "ICQ", "AIM", "WEBHITS", "STREAMHITS", "INDEX", "LISTEN", "PALM7", "LOGIN", "LOGINFAIL", "PLAYED", "COOKIE", "ADMIN", "UPDINFO", "KICKSRC", "KICKDST", "UNBANDST", "BANDST", "VIEWBAN", "UNRIPDST", "VIEWRIP", "VIEWXML", "VIEWLOG", "INVALID"); //define all the variables to get (delte any ones you don't want)

 $y=0; //dummy variable for while loop
 for($y!=''; isset($loop[$y]); $y++){
// while($loop[$y]!=''){ //while there are things in loop
  $pageed = ereg_replace(".*<$loop[$y]>", "", $page); // extract data
  $phpname = strtolower($loop[$y]); //make names in loop lowercase for variable names
  $$phpname = ereg_replace("</$loop[$y]>.*", "", $pageed); //finish extracting data
  if($loop[$y]=='SERVERGENRE' || $loop[$y]=='SERVERTITLE' || $loop[$y]=='SONGTITLE') //if for code clean-up (if you have problems with variables with URL encoding (i.e. %20 for space put them in this loop)
   $$phpname = urldecode($$phpname); // replace URL code with regular text (i.e. %20 = space)
//  $y++; //update dummy variable for while loop
 }
 $pageed = ereg_replace(".*<SONGHISTORY>", "", $page); //extract data
 $pageed = ereg_replace("<SONGHISTORY>.*", "", $pageed); //extract data
 $songatime = explode("<SONG>", $pageed); //break data down for each song
 $r=1; //dummy variable
 for($r!=''; isset($songatime[$r]); $r++){
// while($songatime[$r]!=""){ //while loop for each song
  $t=$r-1; //correction for first value in array from explode is worthless
  $playedat[$t] = ereg_replace(".*<PLAYEDAT>", "", $songatime[$r]); // extract data
  $playedat[$t] = ereg_replace("</PLAYEDAT>.*", "", $playedat[$t]); //extract data
  $song[$t] = ereg_replace(".*<TITLE>", "", $songatime[$r]); //extract data
  $song[$t] = ereg_replace("</TITLE>.*", "", $song[$t]); //extract data
  $song[$t] = urldecode($song[$t]); //cleans-up the URL code thing again
//  $r++; //update loop variable
 }
 $pageed = ereg_replace(".*<LISTENERS>", "", $page); //extract data
 $pageed = ereg_replace("</LISTENERS>.*", "", $pageed); //extract data
 $listeninfo = explode("<LISTENER>", $pageed); //break apart data
 $r=1; //dummy loop variable
 for($r!=''; isset($listeninfo[$r]); $r++){
// while($listeninfo[$r]!=""){ //while loop for extraction
  $t=$r-1; //correction for first value in array from explode is worthless
  $hostname[$t] = ereg_replace(".*<HOSTNAME>", "", $listeninfo[$r]); //extract data
  $hostname[$t] = ereg_replace("</HOSTNAME>.*", "", $hostname[$t]); //extract data
  $pointer[$t] = ereg_replace(".*<POINTER>", "", $listeninfo[$r]); //extract data
  $pointer[$t] = ereg_replace("</POINTER>.*", "", $pointer[$t]); //extract data
  $useragent[$t] = ereg_replace(".*<USERAGENT>", "", $listeninfo[$r]); //extract data
  $useragent[$t] = ereg_replace("</USERAGENT>.*", "", $useragent[$t]);  //extract data
  $underruns[$t] = ereg_replace(".*<UNDERRUNS>", "", $listeninfo[$r]);  //extract data
  $underruns[$t] = ereg_replace("</UNDERRUNS>.*", "", $underruns[$t]);  //extract data
  $connecttime[$t] = ereg_replace(".*<CONNECTTIME>", "", $listeninfo[$r]);  //extract data
  $connecttime[$t] = ereg_replace("</CONNECTTIME>.*", "", $connecttime[$t]);  //extract data
//  $r++;  //update loop variable
 }
 fclose($fp);  //close connection 
}
//Leave this. It writes over real value so if someone were to use
//include to get this page they cannot use echo $password to get your password.
$password = "(REMOVED FOR SECURITY REASONS)";
$password2 = "(REMOVED FOR SECURITY REASONS)";
?>