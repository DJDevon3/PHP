<?php
/*********************************************
  DragonCast 1.0 DragonCast
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
$pagetitle = "- $module_name";
include("modules/$module_name/version.php");
echo "<link rel=\"stylesheet\" href=\"themes/$ThemeSel/style/style.css\" type=\"text/css\">";
echo "<style type=\"text/css\">body {background-color: transparent}</style><font class=\"content\">";
echo"<table border=\"0\" width=\"100%\">"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\">"
  . "      <p align=\"center\">Nuke-Cast $version</td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\">BY</td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\"><a href=\"http://www.urbanclubbers.com/modules.php?name=Feedback\" target=\"_blank\">DJ"
  . "      DiZ-E</a></td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\"><a href=\"http://www.urbanclubbers.com\" target=\"_blank\"><br>WebSite</a></td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\">"
  . "      <p align=\"center\">DragonCast $version</td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\">BY</td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\"><a href=\"http://www.treasurecoastdesigns.com/index.php?name=Feedback\" target=\"_blank\">Devon"
  . "      </a></td>"
  . "  </tr>"
  . "  <tr>"
  . "    <td width=\"100%\" align=\"center\"><a href=\"http://www.treasurecoastdesigns.com\" target=\"_blank\"><br>WebSite</a></td>"
  . "  </tr>"
  . "</table><a href=\"javascript:history.go(-1)\">Go Back</a></font>"
  ."";
?>