<?php
/*********************************************
  DragonCast 1.0 BlockRadio
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = basename(dirname(__FILE__));
get_lang($module_name);


global $nukeurl;

echo "<link rel=\"stylesheet\" href=\"themes/$ThemeSel/style/style.css\" type=\"text/css\">";
echo "<style type=\"text/css\">body {background-color: transparent}</style>";
switch ($op) {
        case "host2":
        host2();
        break;
        default:
        index();
}

function index() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml.php");
echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiowma(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";

echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiorm(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host1rm\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";


if($refresh==""){
echo "<meta http-equiv=\"refresh\" content=\"60\"><font class=\"content\">";
}
else {
echo "<meta http-equiv=\"refresh\" content=\"$refresh\"><font class=\"content\">";
}
if($activatehost2==1){
echo "<center><b><u>$host1name</u></b></center>";
}

echo "<center>"._NOWPLAYING.":";
if($connected==1){

if($song[0]==""){
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\"><b><font color=\"red\">"._DCERROR."</font></b></marquee><br>";
} else {
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\">$song[0]</marquee>";
}

}
else {
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\">$cstmsg</marquee>";
}
echo "<br><b>"._TUNEINUSING."</b><br>";
echo "<a href=\"javascript:openradiowma()\"><img src=\"modules/DragonCast/images/small_windowsmedia.gif\" border=\"0\" alt=\"Windows Media Player\"></a> <a href=\"javascript:openradiorm()\"><img src=\"modules/DragonCast/images/small_real.gif\" border=\"0\" alt=\"RealMedia Player\"></a> <a href=\"$listenlink\">";
echo "<img src=\"modules/DragonCast/images/small_winamp.gif\" border=\"0\" alt=\"WinAMP\"></a> <a href=\"$listenlink\"><img src=\"modules/DragonCast/images/small_itunes.gif\" border=\"0\" alt=\"iTunes\"></a><br><br><a href=\"index.php?name=DragonCast\" target=\"_parent\"><img src=\"modules/DragonCast/images/radio-logo.gif\" width=\"112\" height=\"27\" border=\"0\">";
echo "<br>"._RADIOSTATS."</a></center>";
if($currentlisteners==""){
echo "<center>"._LISTENERS." 0/0</center><br />";
} else {
echo "<center>"._LISTENERS." $currentlisteners/$maxlisteners</center><br />";
}
if($activatehost2==1){
echo "<center>"._SWITCHTO.":<br><a href=\"index.php?name=DragonCast&file=BlockRadio\"><u>$host1name</u></a><br /><a href=\"index.php?name=DragonCast&file=BlockRadio&op=host2\">$host2name</a></center>";
}
}

function host2() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml2.php");
echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiowma(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host2wma\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";

echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiorm(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host2rm\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";

if($refresh==""){
echo "<meta http-equiv=\"refresh\" content=\"60\"><font class=\"content\">";
}
else {
echo "<meta http-equiv=\"refresh\" content=\"$refresh\"><font class=\"content\">";
}
if($activatehost2==1){
echo "<center><b><u>$host2name</u></b><br>";
}
echo ""._NOWPLAYING.":";
if($connected==1){

if($song[0]==""){
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\"><b><font color=\"red\">"._DCERROR."</font></b></marquee><br>";
} else {
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\">$song[0]</marquee><br>";
}

}
else {
echo "<marquee width=\"100%\" scrolldelay=\"100\" scrollamount=\"5\">$cstmsg2</marquee><br>";
}
echo "<br><b>"._TUNEINUSING."</b><br><br>";
echo "<a href=\"javascript:openradiowma()\"><img src=\"modules/DragonCast/images/small_windowsmedia.gif\" border=\"0\" alt=\"Windows Media Player\"></a> <a href=\"javascript:openradiorm()\"><img src=\"modules/DragonCast/images/small_real.gif\" border=\"0\" alt=\"RealMedia Player\"></a> <a href=\"$listenlink\">";
echo "<img src=\"modules/DragonCast/images/small_winamp.gif\" border=\"0\" alt=\"WinAMP\"></a> <a href=\"$listenlink\"><img src=\"modules/DragonCast/images/small_itunes.gif\" border=\"0\" alt=\"iTunes\"></a><br><br><a href=\"index.php?name=DragonCast&op=host2\" target=\"_parent\"><img src=\"modules/DragonCast/images/radio-logo.gif\" width=\"112\" height=\"27\" border=\"0\">";
echo "<br>"._RADIOSTATS."</a></center>";
if($currentlisteners==""){
echo "<center>"._LISTENERS." 0/0</center>";
} else {
echo "<center>"._LISTENERS." $currentlisteners/$maxlisteners</center>";
}
if($activatehost2==1){
echo "<center>"._SWITCHTO.":<br><a href=\"index.php?name=DragonCast&file=BlockRadio\">$host1name</a><br /><a href=\"index.php?name=DragonCast&file=BlockRadio&op=host2\"><u>$host2name</u></a></center>";
}
echo "<a href=\"index.php?name=DragonCast&file=DragonCast\">� $nukeurl</a></font>";
}

?>