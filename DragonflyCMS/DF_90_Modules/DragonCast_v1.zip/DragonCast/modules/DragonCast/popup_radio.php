<?php
/*********************************************
  DragonCast 1.0 Popup Radio
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
echo "<link rel=\"stylesheet\" href=\"themes/$ThemeSel/style/style.css\" type=\"text/css\">";
switch ($op) {
        case "host2wma":
        host2wma();
        break;
        case "host1rm":
        host1rm();
        break;
        case "host2rm":
        host2rm();
        break;

        default:
        host1wma();
}
function host1wma() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml.php");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html>\n";
echo "<head>\n";
echo "<title>$title</title>\n";
echo "\n\n\n</head>\n\n";
if($extip1==""){
$listen = "http://$host:$port";
}
else {
$listen = "http://$extip1:$port";
}
echo "<center><font><h4>$title</h4></font>";
echo"      <!-- begin embedded WindowsMedia file... -->"
  . "      <table border='0' cellpadding='0' align=\"center\">"
  . "      <tr><td>"
  . "      <OBJECT id='mediaPlayer' width=\"320\" height=\"45\" "
  . "      classid='CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95' "
  . "      codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701'"
  . "      standby='Loading Microsoft Windows Media Player components...' type='application/x-oleobject'>"
  . "      <param name='fileName' value=\"$listen\">"
  . "      <param name='animationatStart' value='true'>"
  . "      <param name='transparentatStart' value='true'>"
  . "      <param name='autoStart' value=\"true\">"
  . "      <param name='showControls' value=\"true\">"
  . "      <param name='loop' value=\"true\">"
  . "      <EMBED type='application/x-mplayer2'"
  . "        pluginspage='http://microsoft.com/windows/mediaplayer/en/download/'"
  . "        id='mediaPlayer' name='mediaPlayer' displaysize='4' autosize='-1' "
  . "        bgcolor='darkblue' showcontrols=\"true\" showtracker='-1' "
  . "        showdisplay='0' showstatusbar='-1' videoborder3d='-1' width=\"320\" height=\"45\""
  . "        src=\"$listen\" autostart=\"true\" designtimesp='5311' loop=\"true\">"
  . "      </EMBED>"
  . "      </OBJECT>"
  . "        </td></tr>"
  . "      </table></center>"
 ."";
}

function host2wma() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml2.php");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html>\n";
echo "<head>\n";
echo "<title>$title2</title>\n";
echo "\n\n\n</head>\n\n";
if($extip2==""){
$listen = "http://$host2:$port2";
}
else {
$listen = "http://$extip2:$port2";
}
echo "<center><font><h4>$title2</h4></font>";
echo"      <!-- begin embedded WindowsMedia file... -->"
  . "      <table border='0' cellpadding='0' align=\"center\">"
  . "      <tr><td>"
  . "      <OBJECT id='mediaPlayer' width=\"320\" height=\"45\" "
  . "      classid='CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95' "
  . "      codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701'"
  . "      standby='Loading Microsoft Windows Media Player components...' type='application/x-oleobject'>"
  . "      <param name='fileName' value=\"$listen\">"
  . "      <param name='animationatStart' value='true'>"
  . "      <param name='transparentatStart' value='true'>"
  . "      <param name='autoStart' value=\"true\">"
  . "      <param name='showControls' value=\"true\">"
  . "      <param name='loop' value=\"true\">"
  . "      <EMBED type='application/x-mplayer2'"
  . "        pluginspage='http://microsoft.com/windows/mediaplayer/en/download/'"
  . "        id='mediaPlayer' name='mediaPlayer' displaysize='4' autosize='-1' "
  . "        bgcolor='darkblue' showcontrols=\"true\" showtracker='-1' "
  . "        showdisplay='0' showstatusbar='-1' videoborder3d='-1' width=\"320\" height=\"45\""
  . "        src=\"$listen\" autostart=\"true\" designtimesp='5311' loop=\"true\">"
  . "      </EMBED>"
  . "      </OBJECT>"
  . "        </td></tr>"
  . "      </table></center>"
 ."";
}

function host1rm() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml.php");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html>\n";
echo "<head>\n";
echo "<title>$title</title>\n";
echo "\n\n\n</head>\n\n";
if($extip1==""){
$listen = "http://$host:$port";
}
else {
$listen = "http://$extip1:$port";
}
echo "<link rel=\"stylesheet\" href=\"themes/$ThemeSel/style/style.css\" type=\"text/css\">";
echo "<center><font><h4>$title</h4></font>";

echo"<OBJECT ID=RVOCX CLASSID=\"clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA\" WIDTH=\"320\" HEIGHT=\"45\">"
  . "                <PARAM name=\"src\" value=$listen>"
  . "                <PARAM name=\"autostart\" value=\"False\">"
  . "                <PARAM name=\"controls\" value=\"ControlPanel\">"
  . "                <PARAM name=\"console\" value=\"video\">"
  . "                <EMBED TYPE=\" audio/x-pn-realaudio-plugin \" "
  . "SRC=\"$listen\""
  . "WIDTH=\"320\""
  . "HEIGHT=\"45\""
  . "AUTOSTART=\"true\""
  . "CONTROLS=\"ControlPanel\""
  . "CONSOLE=\"audio\"> </EMBED>"
  . "            </OBJECT>"
 ."";
}

function host2rm() {
$module_name = basename(dirname(__FILE__));
include ("modules/$module_name/scastxml2.php");
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html>\n";
echo "<head>\n";
echo "<title>$title2</title>\n";
echo "\n\n\n</head>\n\n";
if($extip2==""){
$listen = "http://$host2:$port2";
}
else {
$listen = "http://$extip2:$port2";
}
echo "<link rel=\"stylesheet\" href=\"themes/$ThemeSel/style/style.css\" type=\"text/css\">";
echo "<center><font><h4>$title2</h4></font>";

echo"<OBJECT ID=RVOCX CLASSID=\"clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA\" WIDTH=\"320\" HEIGHT=\"45\">"
  . "                <PARAM name=\"src\" value=$listen>"
  . "                <PARAM name=\"autostart\" value=\"False\">"
  . "                <PARAM name=\"controls\" value=\"ControlPanel\">"
  . "                <PARAM name=\"console\" value=\"video\">"
  . "                <EMBED TYPE=\" audio/x-pn-realaudio-plugin \" "
  . "SRC=\"$listen\""
  . "WIDTH=\"320\""
  . "HEIGHT=\"45\""
  . "AUTOSTART=\"true\""
  . "CONTROLS=\"ControlPanel\""
  . "CONSOLE=\"audio\"> </EMBED>"
  . "            </OBJECT>"
 ."";
}
?>