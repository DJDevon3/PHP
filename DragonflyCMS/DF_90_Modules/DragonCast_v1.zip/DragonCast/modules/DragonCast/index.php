<?php
/*********************************************
  DragonCast 1.0 Mod Index
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of www.TreasureCoastDesigns.com
and
Sarah of www.DiagonAlly.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

$mode = isset($_POST['mode']) ? $_POST['mode'] : (isset($_GET['mode']) ? $_GET['mode']:'');
switch ($mode) {
        case "host2":
        host2();
        break;
        default:
        index();
}

// SERVER 1 INDEX
function index() {
	global $admin, $module_name;
include ("modules/$module_name/scastxml.php");
include("header.php");
$indexmsg = '';
echo '<center><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td class="pagetitle">'.$title.'</td></tr></table></center>';

OpenTable();
if(is_admin($admin)){
echo '<a href="'.adminlink("$module_name&amp;mode=general").'"><img src="modules/'.$module_name.'/images/general.gif" border="0" alt="Dragoncast Administration" align="right" /></a>';
}
echo '<center><br /><img src="modules/'.$module_name.'/images/DCTemplate.gif"><br /><br /></center>';
if($activatehost2==1){
echo '<center><a href="'.getlink("$module_name").'"><u>'.$host1name.'</u>  </a><a href="'.getlink("$module_name&amp;mode=host2").'">'.$host2name.'</a></center>';
}
echo"<center><b>$indexmsg</b></center>";
if($connected==1){
if($song[0]==""){
echo'<center><b><font color="red">'._DCERROR.'</font></b></center>';
} else {

echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiowma(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";
echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiorm(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host1rm\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";

echo '<table border="0" cellpadding="0" cellspacing="0" bgcolor='.$tblhdr.' width="100%"><tr><td width="25%" align="center">'._COMPAT.'<br />
<a href="javascript:openradiowma()"><img src="modules/DragonCast/images/windowsmedia.gif" border="0" alt="Windows Media Player" title="Launch Windows Media Player"></a>&nbsp;&nbsp;<a href="javascript:openradiorm()"><img src="modules/DragonCast/images/real.gif" border="0"  alt="RealMedia Player" title="Launch RealPlayer"></a>&nbsp;&nbsp;<a href='.$listenlink.'><img src=modules/DragonCast/images/winamp.gif border=0 alt="WinAMP" title="Launch WinAMP"></a>&nbsp;&nbsp;<a href='.$listenlink.'><img src="modules/DragonCast/images/itunes.gif" border="0" alt="iTunes" title="Launch iTunes"></a><br>
	<font size='.$hdrtext.'></center></td>
	
<td width="25%"><font size='.$hdrtext.'><b><center><img src="modules/DragonCast/images/online.gif"></center></td>
<td width="25%"><font size='.$hdrtext.'><b><center>'._CURRENTLISTEN.' '.$currentlisteners.'/'.$maxlisteners.'</center></font></td></tr></table>

<center><br />
<hr />
	<b><font face=Arial size='.$hdrtext.'>'._STREAMINFO.'</font></b>
	<hr /></center>
	
<table border="0" cellpadding="2" cellspacing="2" bgcolor='.$bgrnd.' width="100%"><tr><td width="100%"><font size='.$hdrtext.'><b>'._CURRENTPLY.'</td></tr><tr><td width="100%" bgcolor='.$tblhdr.'><font size='.$bdytext.'>'.$song[0].' <hr /></td></tr>';
// Note if you do not want the last 6 songs showing just comment out this echo statement with /*c-style*/ comments
  echo'<tr><td width="100%"><font size='.$hdrtext.'><b>'._PASTSONGS.'</td>
  </tr>
  <tr>
    <td width="100%" bgcolor='.$tblhdr.'><font size='.$bdytext.'>1.'.$song[1].'<br /><br />2.'.$song[2].'<br /><br />3.'.$song[3].'<br /><br />4.'.$song[4].'<br /><br />5.'.$song[5].'<br /><br />6.'.$song[6].'<br /><br />7.'.$song[7].'<br /><br />8.'.$song[8].'<br /><br />9.'.$song[9].'</td>
  </tr></font>
</table>';
// Detailed Stats
echo'<center><hr /><b><font size='.$hdrtext.'>'._DETAILSTAT.'</font></b><hr /></center><table border="0" cellpadding="4" cellspacing="4" width="100%">
	  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._GENRE.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$servergenre.'</td>
  </tr>
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._TOTALHITS.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$webhits.'</td>
  </tr>
	<tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._PEAKSTAT.'</font></td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$peaklisteners.' '._TOTALLISTENERS.'</td>
  </tr> 
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._AVRGTIME.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$averagetime.' '._DCSECONDS.'</td>
  </tr>
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._BITRATE.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$bitrate.' kbps</td>
  </tr>
</table>
<center><hr /><b><font size='.$hdrtext.'>'._SERVERMESSAGE.'</font></b><hr /></center>
<table border="0" cellpadding="4" cellspacing="4" width="100%">
	<tr>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$server1msg.'</font>
</td></tr></table>';

}
}
else {
CloseTable();
OpenTable();
echo'<center><b>'.$cstmsg.'</b></center>';
}
CloseTable();
}

// SERVER 2 INDEX
function host2() {
	global $admin, $module_name;
include ("modules/$module_name/scastxml2.php");
include("header.php");
$indexmsg = '';
echo '<center><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td class="pagetitle">'.$title2.'</td></tr></table></center>';

if($activatehost2==1){

OpenTable();
if(is_admin($admin)){
echo '<a href="'.adminlink("$module_name&amp;mode=general").'"><img src="modules/'.$module_name.'/images/general.gif" border="0" alt="Dragoncast Administration" align="right" /></a>';
}
echo '<center><br /><img src="modules/'.$module_name.'/images/DCTemplate.gif"><br /><br /></center>';

echo '<center><a href="'.getlink("$module_name").'"><u>'.$host1name.'</u>  </a><a href="'.getlink("$module_name&amp;mode=host2").'">'.$host2name.'</a></center>';
if($connected==1){
if($song[0]==""){
echo"<center><b><font color=\"red\">Error: Cant Retrieve Stats</font></b></center>";
} else {


echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiowma(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host2wma\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";
echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
echo "function openradiorm(){\n";
echo "	window.open (\"index.php?name=DragonCast&file=popup_radio&op=host2rm\",\"Radio\",\"toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,copyhistory=no,width=345,height=120\");\n";
echo "}\n";
echo "//-->\n";
echo "</SCRIPT>\n\n";

echo '<table border="0" cellpadding="0" cellspacing="0" bgcolor='.$tblhdr.' width="100%"><tr><td width="25%" align="center">'._COMPAT.'<br />
<a href="javascript:openradiowma()"><img src="modules/DragonCast/images/windowsmedia.gif" border="0" alt="Windows Media Player" title="Launch Windows Media Player"></a>&nbsp;&nbsp;<a href="javascript:openradiorm()"><img src="modules/DragonCast/images/real.gif" border="0"  alt="RealMedia Player" title="Launch RealPlayer"></a>&nbsp;&nbsp;<a href='.$listenlink.'><img src=modules/DragonCast/images/winamp.gif border=0 alt="WinAMP" title="Launch WinAMP"></a>&nbsp;&nbsp;<a href='.$listenlink.'><img src="modules/DragonCast/images/itunes.gif" border="0" alt="iTunes" title="Launch iTunes"></a><br>
	<font size='.$hdrtext.'></center></td>
	
<td width="25%"><font size='.$hdrtext.'><b><center><img src="modules/DragonCast/images/online.gif"></center></td>
<td width="25%"><font size='.$hdrtext.'><b><center>'._CURRENTLISTEN.' '.$currentlisteners.'/'.$maxlisteners.'</center></font></td></tr></table>

<center><br />
<hr />
	<b><font face=Arial size='.$hdrtext.'>'._STREAMINFO.'</font></b>
	<hr /></center>
	
<table border="0" cellpadding="2" cellspacing="2" bgcolor='.$bgrnd.' width="100%"><tr><td width="100%"><font size='.$hdrtext.'><b>'._CURRENTPLY.'</td></tr><tr><td width="100%" bgcolor='.$tblhdr.'><font size='.$bdytext.'>'.$song[0].' <hr /></td></tr>';
// Note if you do not want the last 6 songs showing just comment out this echo statement with /*c-style*/ comments
  echo'<tr><td width="100%"><font size='.$hdrtext.'><b>'._PASTSONGS.'</td>
  </tr>
  <tr>
    <td width="100%" bgcolor='.$tblhdr.'><font size='.$bdytext.'>1.'.$song[1].'<br /><br />2.'.$song[2].'<br /><br />3.'.$song[3].'<br /><br />4.'.$song[4].'<br /><br />5.'.$song[5].'<br /><br />6.'.$song[6].'<br /><br />7.'.$song[7].'<br /><br />8.'.$song[8].'<br /><br />9.'.$song[9].'</td>
  </tr></font>
</table>';



	// Detailed Stats
echo'<center><hr /><b><font size='.$hdrtext.'>'._DETAILSTAT.'</font></b><hr /></center><table border="0" cellpadding="4" cellspacing="4" width="100%">
	  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._GENRE.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$servergenre.'</td>
  </tr>
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._TOTALHITS.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$webhits.'</td>
  </tr>
	<tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._PEAKSTAT.'</font></td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$peaklisteners.' '._TOTALLISTENERS.'</td>
  </tr> 
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._AVRGTIME.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$averagetime.' '._DCSECONDS.'</td>
  </tr>
  <tr>
    <td width="31%" bgcolor='.$cell.'><font size='.$hdrtext.'><b>'._BITRATE.'</td>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$bitrate.' kbps</td>
  </tr>
</table>
<center><hr /><b><font size='.$hdrtext.'>'._SERVERMESSAGE.'</font></b><hr /></center>
<table border="0" cellpadding="4" cellspacing="4" width="100%">
	<tr>
    <td width="100%" bgcolor='.$cell.'><font size='.$bdytext.'>'.$server2msg.'</font>
</td></tr></table>';

}
}
else {
CloseTable();
OpenTable();
echo"<center><b>$cstmsg2</b></center>";
}
CloseTable();
} else {
OpenTable();
echo"<center><b>"._SVRDISABLED."</b></center>";
if(is_admin($admin)){
echo '<center>'._CLICK.' <a href="'.adminlink("$module_name&amp;mode=sc2").'">HERE</a> '._TGTSS.'</center>';
}
CloseTable();
}
}
?>