<?php
/*********************************************
  DragonCast 1.0 cpg_inst
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class dragoncast {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function dragoncast() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'DragonCast';
		$this->description = 'A Shoutcasting Management Module';
		$this->author = 'Original by UrbanClubber.com Ported by DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('themecp');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'dragoncast', "
			id int(11) NOT NULL default '',
			host1name varchar(255) NOT NULL default '',
			host varchar(255) NOT NULL default '',
			port varchar(255) NOT NULL default '',
			password varchar(255) NOT NULL default '',
			title varchar(255) NOT NULL default '',
			djname varchar(255) NOT NULL default '',
			cstmsg varchar(255) NOT NULL default '',
			server1msg varchar(255) NOT NULL default '',
			activatehost2 varchar(255) NOT NULL default '',
			host2name varchar(255) NOT NULL default '',
			host2 varchar(255) NOT NULL default '',
			port2 varchar(255) NOT NULL default '',
			password2 varchar(255) NOT NULL default '',
			title2 varchar(255) NOT NULL default '',
			djname2 varchar(255) NOT NULL default '',
			cstmsg2 varchar(255) NOT NULL default '',
			server2msg varchar(255) NOT NULL default '',
			refresh varchar(255) NOT NULL default '',
			extip1 varchar(255) NOT NULL default '',
			extip2 varchar(255) NOT NULL default '',
			bgrnd varchar(255) NOT NULL default '',
			text varchar(255) NOT NULL default '',
			link varchar(255) NOT NULL default '',
			vlink varchar(255) NOT NULL default '',
			alink varchar(255) NOT NULL default '',
			tblhdr varchar(255) NOT NULL default '',
			cell varchar(255) NOT NULL default '',
			hdrtext varchar(255) NOT NULL default '',
			bdytext varchar(255) NOT NULL default '',
			height varchar(255) NOT NULL default '',
			PRIMARY KEY (id),
			KEY id (id)", 'dragoncast');

			$installer->add_query('INSERT', 'dragoncast', "'1', 'Low Speed', '192.168.1.1', '8000', 'changeme', 'My Radio Station', 'DJ Name', 'Our server is temporarily down, please try again later!', 'Server Message 1 (footer)', '0', 'Low Speed', '192.168.1.2', '8000', 'changeme', 'My Radio', 'DJ Name', 'Our server is temporarily down, please try again later!', 'Server Message 2 (footer)', '60', '', '', 'FFFFFF', 'FFFFCC', '000000', 'FFFFCC', '800080', '5C5C5C', '333333', '2', '1', ''");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'dragoncast');	
		return true;
	}
}
?>