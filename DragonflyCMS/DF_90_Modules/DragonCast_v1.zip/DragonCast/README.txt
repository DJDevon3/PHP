/*********************************************
  DragonCast 1.0 - A NukeCast Port for DragonflyCMS
  ********************************************
  Original NukeCast Copyright 2005 by UrbanClubbers.com
  http://UrbanClubbers.com

Ported to DragonflyCMS by 
DJDevon3 of http://TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/

DRAGONFLYCMS CHANGE LOG:
=========================================================

1.0 Ported to DragonflyCMS 3-23-06 reverting to Version 1.0 for DragonflyCMS
Thanks to www.ConvictRadio.com and www.RadioGetsWild.com
for allowing us to use their shoutcast server for testing.

**********************************************************
----------------------------------------------------------
OLD PHP-Nuke Change Log:
1.9.p1 Fixed issues with admin page. "error when saving settings".


1.9 Fixed Some issues with admin page (hopefully no more issuses)

1.8 Fixed Some issues with admin page when Updating Server info

1.7 Added Kick/Ban options to the admin (who's Listening)
    Fixed issues with SQL errors
    Fixed Error "Warning: open_basedir restriction in effect."

1.6 Fixed issue with "Who's Listening" to show more then the current 20 users
    Added iTunes icon to the Listen Links
    Added Support for language packs
    [ Currently in English only More Coming Soon ]
    
1.5 Added Admin interface for easy setup and config
    Added Who's Listening page in the admin menu
    Added Status Messages in the admin to diagnose problems

1.4 Fixed error "Warning: Call-time pass-by-reference has been deprecated"
    Added Support for 2 ShoutCast Servers
    Added Refreshing block and Block refresh time in config
    Added support for use on internal LAN with "external ip setting"

1.3 Fixed errors when server isent present

1.2 Fixed when stream goes offline to show offline message

1.1 Fixed errors when shoutcast server goes offline

---------------------------------------------------------------------------


included files
==============

admin/links/links.nuke-cast.php

images/admin/Nuke-Cast.gif

blocks/block-Live_Radio.php
blocks/block-Live_Radio_SC1.php
blocks/block-Live_Radio_SC2.php

modules/Nuke-Cast/admin.php
modules/Nuke-Cast/BlockRadio.php
modules/Nuke-Cast/BlockRadio2.php
modules/Nuke-Cast/copyright.php
modules/Nuke-Cast/index.php
modules/Nuke-Cast/install.php
modules/Nuke-Cast/nuke-cast.php
modules/Nuke-Cast/popup_radio.php
modules/Nuke-Cast/scastxml.php
modules/Nuke-Cast/scastxml2.php
modules/Nuke-Cast/version.php

modules/Nuke-Cast/images/itunes.gif
modules/Nuke-Cast/images/online.gif
modules/Nuke-Cast/images/radio_blank.gif
modules/Nuke-Cast/images/radio-logo.gif
modules/Nuke-Cast/images/real.gif
modules/Nuke-Cast/images/tunein.gif
modules/Nuke-Cast/images/winamp.gif
modules/Nuke-Cast/images/windowsmedia.gif

modules/Nuke-Cast/language/lang-english.php

---------------------------------------------------------------------------


NEW INSTALL INSTRUCTIONS
========================

1. Copy files from html-root to your php-nuke root

2. login as admin run install file http://www.yoursite.com/modules.php?name=Nuke-Cast&file=install

3. edit Nuke-Cast Sever Configuration

4  enable Nuke-Cast module and add "Live Radio" block.

4. enjoy :)
---------------------------------------------------------------------------


UPDATE FROM OLDER VERSION OF NUKE-CAST
======================================

Update from 1.4 and lower
-------------------------

1. Copy files from html-root to your php-nuke root

2. login as admin run install file http://www.yoursite.com/modules.php?name=Nuke-Cast&file=install

3. edit Nuke-Cast Sever Configuration

Update from 1.5 - 1.8
---------------------
1. Copy files from html-root to your php-nuke root

2. Thats it enjoy :)
---------------------------------------------------------------------------

################ Nuke-Cast v1.9.p1 - http://www.urbanclubbers.com ################
Woohoo ok this is my first PHP-Nuke Module so if you have any feedback you
can visit http://www.urbanclubbers.com use the feedback option on the left menu
################ Nuke-Cast v1.9 - http://www.urbanclubbers.com ################