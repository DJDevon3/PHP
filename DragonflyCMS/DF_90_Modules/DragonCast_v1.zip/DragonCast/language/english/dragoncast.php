<?php
/*********************************************
  DragonCast 1.0 Language English
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
define("_CURRENTLISTEN","Current Listeners");
define("_BITRATE","Bitrate");
define("_COMPAT","Choose Your Media Player");
define("_CURRENTPLY","Currently Playing");
define("_PASTSONGS","Past 9 Songs");
define("_STREAMINFO","Streaming Information");
define("_DETAILSTAT","Detailed Server Status");
define("_TOTALLISTEN","Total Listeners");
define("_TOTALHITS","Total hits to server");
define("_CANHANDLE","can handle");
define("_LISTENERS","Listeners");
define("_DJICQ","DJ's ICQ");
define("_CONTACT","Contact");
define("_CONTACTDJICQ","via ICQ");
define("_CONTACTDJ2ICQ","via ICQ");
define("_DJAOL","DJ's Aol IM handle");
define("_SERVERMESSAGE","Server Message");
define("_AVRGTIME","Average time spent listening");
define("_DCSECONDS","Seconds");
define("_GENRE","Genre for this station");
define("_PEAKSTAT","Peak Stats");
define("_PEAKED","has peaked @");
define("_TOTALLISTENERS","total listeners");
define("_DCERROR","Error: Cant Retrieve Stats");
define("_SVRDISABLED","Server Disabled");
define("_CLICK","Click");
define("_HERE","Here");
define("_TGTSS","to goto Server Settings to Enable Server");
/* BlockRadio.php */
define("_NOWPLAYING","Now Playing");
define("_SWITCHTO","Switch to");
define("_TUNEINUSING","TUNE IN USING");
define("_RADIOSTATS","Radio Status");
