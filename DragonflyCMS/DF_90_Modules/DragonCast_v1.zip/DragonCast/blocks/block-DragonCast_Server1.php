<?php
/*********************************************
  DragonCast 1.0 DragonCast Live Block
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = "DragonCast";
include ("modules/$module_name/scastxml.php");


$content = "<iframe src=\"index.php?name=$module_name&file=BlockRadio\" hspace=0 vspace=0 width=100% height=190 marginwidth=0 marginheight=0 frameborder=0 scrolling=no allowtransparency=true></iframe><a href=\"http://www.urbanclubbers.com/modules.php?name=Nuke-Cast&file=nuke-cast\" target=\"nuke-cast\"></a>";
?>