<?php
/*********************************************
  DragonCast 1.0 Server 2 Block
  ********************************************
  Copyright 2005 by UrbanClubbers.com
  UrbanClubbers.com

  Please see the included ReadMe.txt for the
  terms and conditions that govern your use of
  this module

Ported to DragonflyCMS by 
DJDevon3 of TreasureCoastDesigns.com
and
Sarah of http://diagonally.org
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = "DragonCast";
include ("modules/$module_name/scastxml2.php");
if($height == "") {
$height = "190";
}
$content = "<iframe src=\"index.php?name=$module_name&file=BlockRadio2&op=host2\" hspace=0 vspace=0 width=100% height=$height marginwidth=0 marginheight=0 frameborder=0 scrolling=no allowtransparency=true></iframe>";
?>