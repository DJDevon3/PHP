<?php
/*********************************************
  CPG-Dragonfly™ CMS
  ********************************************
  Copyright © 2004 - 2005 by CPG Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version

  $Source: /cvs/modules/Shoutblock/modules/Shoutblock/cpg_inst.php,v $
  $Revision: 9.2 $
  $Author: djmaze $
  $Date: 2005/02/10 00:55:53 $
**********************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class Shoutblock {
    var $radmin;
    var $version;
    var $modname;
    var $description;
    var $author;
    var $website;
    var $dbtables;
// class constructor
    function Shoutblock() {
        $this->radmin = true;
        $this->version = '3.0';
        $this->modname = 'Shout Block';
        $this->description = 'Allow site users to shout to one another. Based on original Shoutblock by Quiecom';
        $this->author = 'Dragonfly Developer Team';
        $this->website = 'www.DragonflyCMS.org';
        $this->dbtables = array('shoutblock', 'shoutblock_ipblock', 'shoutblock_nameblock');
    }

// module installer
    function install() {
        global $installer;
        $installer->add_query('CREATE', 'shoutblock', '
    id INT(10) UNSIGNED NOT NULL auto_increment,
    name varchar(20) NOT NULL,
    comment text NOT NULL,
    time INT(10) NOT NULL,
    PRIMARY KEY (id)', 'shoutblock');
        $installer->add_query('CREATE', 'shoutblock_ipblock', '
    id int(9) NOT NULL auto_increment,
    name varchar(50) NOT NULL,
    PRIMARY KEY (id)', 'shoutblock_ipblock');
        $installer->add_query('CREATE', 'shoutblock_nameblock', '
    id int(9) NOT NULL auto_increment,
    name varchar(50) NOT NULL,
    PRIMARY KEY (id)', 'shoutblock_nameblock');

        $installer->add_query('INSERT', 'shoutblock', "1, 'Admin', 'Shouts Cleared! :D', ".gmtime());

        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'color1', '#CCCCCC'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'color2', '#696969'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'date', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'time', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'number', '10'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'ipblock', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'nameblock', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'censor', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'urlonoff', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'delyourlastpost', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'anonymouspost', '0'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'height', '150'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'themecolors', '1'");
        $installer->add_query('INSERT', 'config_custom', "'Shoutblock', 'username', 'Anonymous'");
        return true;
    }

// module uninstaller
    function uninstall() {
        global $installer;
        $installer->add_query('DROP', 'shoutblock');
        $installer->add_query('DROP', 'shoutblock_ipblock');
        $installer->add_query('DROP', 'shoutblock_nameblock');
        $installer->add_query('DELETE', 'config_custom', "cfg_name='Shoutblock'");
    }

// module upgrader
    function upgrade($prev_version) {
        global $db, $prefix;
//        $db->sql_query('DELETE FROM '.$prefix.'_credits WHERE modname="Downloads v2"');
    }
}
