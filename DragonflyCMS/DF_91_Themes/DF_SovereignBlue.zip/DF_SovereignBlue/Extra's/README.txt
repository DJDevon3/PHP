=========================================
** CREDITS:                            **
** Created by xtremethemes.com based   **
** on the 'cpgnuke' theme available    **
** from dragonflycms.org               **
** =================================== **
** INFORMATION:                        **
** Theme: Sovereign (blue)             **
** Version: 1.1.4                      **
** Last updated: 2006/1/19             **
** =================================== **
** LICENSE:                            **
** This theme is released under the    **
** terms and conditions of the GNU     **
** GPL version 2 or any later          **
** revisions.                          **
** =================================== **
** NOTICE:                             **
** I ask that you not alter            **
** or remove the xtremethemes.com      **
** credit image/link in the footer     **
** of this theme.                      **
=========================================

UPGRADE INFORMATION:

  CAUTION: Don't overwrite your existing
  /images/head_left.jpg and /images/head_bg.jpg images
  if you have already customized them for your site.

NEED HELP WITH YOUR LOGO OR GRAPHICS?

  Check out the graphics request forum at:
  http://xtremethemes.com/Forums/viewforum/f=6.html

REVISION HISTORY:

  For more detailed information about this theme and 
  revision history, visit:
  http://xtremethemes.com/Downloads/details/id=1.html

QUESTIONS OR COMMENTS:

  Please post your comments or questions in the Xtreme 
  Themes forums at http://xtremethemes.com/Forums.html

INSTRUCTIONS FOR INSTALLATION:

  1. Unzip the downloaded file to your computer.
  2. Upload the /sovereignBlue folder to your /themes
     directory.
  3. OPTIONAL: This step installs the 'online status' hack.
     upload /extras/online_status_hack/viewtopic.php to your
     /modules/forums/ directory. This will overwrite one of the
     core dragonfly files, and will now show member online status
     in each forum post. If you don't want to overwrite this core
     file, the theme will still work fine, it just won't show the
     online status...
  4. Install is complete - see the README in the /extras
     folder for instructions and files to use for 
     customization of your theme.

INSTALLING IN SUBDIRECTORY:

  If you are running dragonfly in a subdirectory, you must 
  overwrite 2 files that were installed in step 2 of the 
  installation instructions (above). Upload the 2 files in 
  /extras/original_forum_files/ to your 
  /themes/sovereignBlue/template/forums/ directory. 
  FAILURE TO DO THIS WILL RESULT IN BROKEN FORUM LINKS.

NO WARRANTY:

  XTREMETHEMES.COM WILL NOT BE RESPONSIBLE FOR ANY 
  DOWNTIME/DAMAGES YOUR WEBSITE MAY SUFFER. 
  XTREMETHEMES.COM MAKES NO WARRANTIES OF ANY KIND, 
  EXPRESSED OR IMPLIED FOR SERVICES/FILES WE PROVIDE.
  XTREMETHEMES.COM DISCLAIMS ANY WARRANTY OR 
  MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.




