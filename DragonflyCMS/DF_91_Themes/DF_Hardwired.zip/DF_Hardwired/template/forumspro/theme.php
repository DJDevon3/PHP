<?php
/*********************************************
  ForumsPro 
  Copyright � 2005 by ForumsPro Dev Team
  http://www.myndworx.com
  ********************************************
  
  CPG Dragonfly� CMS
  ********************************************
  Copyright � 2004 - 2005 by CPG-Nuke Dev Team
  http://www.dragonflycms.com

  Dragonfly is released under the terms and conditions
  of the GNU GPL version 2 or any later version  

  $Source$
  $Revision: 177 $
  $Author: jday29 $
  $Date: 2006-05-02 23:11:11 -0500 (Tue, 02 May 2006) $
**********************************************/
if (!defined('CPG_NUKE')) { exit; }

global $cpgtpl, $CPG_SESS, $currentlang;

$theme = basename(dirname(dirname(dirname(__FILE__))));
$language = (file_exists('themes/'.$theme.'/images/forumspro/'.$currentlang.'/folder/big.gif') ? $currentlang : 'english');

$cpgtpl->assign_vars(array(
	'I_ADMIN_ANNOUNCE' => "themes/$theme/images/forumspro/$language/admin/announce.gif",
	'I_ADMIN_DELETE_POST' => "themes/$theme/images/forumspro/$language/admin/delete_post.gif",
	'I_ADMIN_DELETE_TOPIC' => "themes/$theme/images/forumspro/$language/admin/delete_topic.gif",
	'I_ADMIN_IP' => "themes/$theme/images/forumspro/$language/admin/ip.gif",
	'I_ADMIN_LOCK' => "themes/$theme/images/forumspro/$language/admin/lock.gif",
	'I_ADMIN_MERGE' => "themes/$theme/images/forumspro/$language/admin/merge.gif",
	'I_ADMIN_MOVE' => "themes/$theme/images/forumspro/$language/admin/move.gif",
	'I_ADMIN_NORMALISE' => "themes/$theme/images/forumspro/$language/admin/normalise.gif",
	'I_ADMIN_REPORT' => "themes/$theme/images/forumspro/$language/admin/report.gif",
	'I_ADMIN_SPLIT' => "themes/$theme/images/forumspro/$language/admin/split.gif",
	'I_ADMIN_STICKY' => "themes/$theme/images/forumspro/$language/admin/sticky.gif",
	'I_ADMIN_UNLOCK' => "themes/$theme/images/forumspro/$language/admin/unlock.gif",
	'I_FOLDER_BIG_NEW' => "themes/$theme/images/forumspro/$language/folder/big_new.gif",
	'I_FOLDER_BIG' => "themes/$theme/images/forumspro/$language/folder/big.gif",
	'I_FOLDER_BIG_LOCK' => "themes/$theme/images/forumspro/$language/folder/big_lock.gif",
	'I_FOLDER_BIG_SUB_NEW' => "themes/$theme/images/forumspro/$language/folder/big_sub_new.gif",
	'I_FOLDER_BIG_SUB' => "themes/$theme/images/forumspro/$language/folder/big_sub.gif",
	'I_FOLDER_BIG_SUB_LOCK' => "themes/$theme/images/forumspro/$language/folder/big_sub_lock.gif",
	'I_FOLDER_LINK_INTERNAL' => "themes/$theme/images/forumspro/$language/folder/linkinternal.gif",
	'I_FOLDER_LINK_EXTERNAL' => "themes/$theme/images/forumspro/$language/folder/linkexternal.gif",
	'I_FOLDER_NEW' => "themes/$theme/images/forumspro/$language/folder/new.gif",
	'I_FOLDER_NO_NEW' => "themes/$theme/images/forumspro/$language/folder/no_new.gif",
	'I_FOLDER_ANNOUNCE' => "themes/$theme/images/forumspro/$language/folder/announce.gif",
	'I_FOLDER_ANNOUNCE_NEW' => "themes/$theme/images/forumspro/$language/folder/announce_new.gif",
	'I_FOLDER_STICKY' => "themes/$theme/images/forumspro/$language/folder/sticky.gif",
	'I_FOLDER_STICKY_NEW' => "themes/$theme/images/forumspro/$language/folder/sticky_new.gif",
	'I_FOLDER_HOT_NEW' => "themes/$theme/images/forumspro/$language/folder/hot_new.gif",
	'I_FOLDER_HOT' => "themes/$theme/images/forumspro/$language/folder/hot.gif",
	'I_FOLDER_LOCK_NEW' => "themes/$theme/images/forumspro/$language/folder/lock_new.gif",
	'I_FOLDER_LOCK' => "themes/$theme/images/forumspro/$language/folder/lock.gif",
	'I_ICON_LATEST_REPLY' => "themes/$theme/images/forumspro/$language/icon_latest_reply.gif",
	'I_ICON_NEWEST_REPLY' => "themes/$theme/images/forumspro/$language/icon_newest_reply.gif",
	'I_ICON_MINIPOST_NEW' => "themes/$theme/images/forumspro/$language/icon_minipost_new.gif",
	'I_ICON_MINIPOST' => "themes/$theme/images/forumspro/$language/icon_minipost.gif",
	'I_ICON_MINI_FAQ' => "themes/$theme/images/forumspro/$language/icon_mini_faq.gif",
	'I_ICON_MINI_SEARCH' => "themes/$theme/images/forumspro/$language/icon_mini_search.gif",
	'I_ICON_MINI_RANKS' => "themes/$theme/images/forumspro/$language/icon_mini_ranks.gif",
	'I_ICON_MINI_ACRONYMS' => "themes/$theme/images/forumspro/$language/icon_mini_acronyms.gif",
	'I_ICON_MINI_WATCH' => "themes/$theme/images/forumspro/$language/icon_mini_watch.gif",
	'I_ICON_MINI_MESSAGE' => "themes/$theme/images/forumspro/$language/icon_mini_message.gif",
	'I_ICON_MINI_LOGIN' => "themes/$theme/images/forumspro/$language/icon_mini_login.gif",
	'I_ICON_DISK' => "themes/$theme/images/forumspro/$language/icon_disk.gif",
	'I_ICON_CLIP' => "themes/$theme/images/forumspro/$language/icon_clip.gif",
	'I_RSS' => "themes/$theme/images/forumspro/rss/feed-icon16x16.png",
	'I_TOPIC_LOCKED' => "themes/$theme/images/forumspro/$language/topic/locked.gif",
	'I_TOPIC_POST' => "themes/$theme/images/forumspro/$language/topic/post.gif",
	'I_TOPIC_REPLY' => "themes/$theme/images/forumspro/$language/topic/reply.gif",
	'I_TOPIC_PRINTER' => "themes/$theme/images/forumspro/$language/topic/printer.gif",
	'I_TOPIC_THANKS' => "themes/$theme/images/forumspro/$language/topic/thanks.gif",
	'I_USER_SEARCH' => "themes/$theme/images/forumspro/$language/user/search.gif",
	'I_USER_ONLINE' => "themes/$theme/images/forumspro/$language/user/online.gif",
	'I_USER_OFFLINE' => "themes/$theme/images/forumspro/$language/user/offline.gif",
	'I_USER_QUOTE' => "themes/$theme/images/forumspro/$language/user/quote.gif",
	'I_USER_EDIT' => "themes/$theme/images/forumspro/$language/user/edit.gif",
	'I_USER_IGNORE' => "themes/$theme/images/forumspro/$language/user/ignore.gif",
	'I_USER_KARMA_NEGATIVE' => "themes/$theme/images/forumspro/$language/user/karma_negative.gif",
	'I_USER_KARMA' => "themes/$theme/images/forumspro/$language/user/karma.gif",
	'I_USER_KARMA_POSITIVE' => "themes/$theme/images/forumspro/$language/user/karma_positive.gif",
	'I_UPDATE_ERROR' => "themes/$theme/images/forumspro/$language/update/MwA_Upd_Error.png",
	'I_UPDATE_OK' => "themes/$theme/images/forumspro/$language/update/MwA_Upd_Ok.png",
	'I_UPDATE_NEEDED' => "themes/$theme/images/forumspro/$language/update/MwA_Upd_Needed.png",
	'I_VOTE_LCAP' => "themes/$theme/images/forumspro/$language/vote/lcap.gif",
	'I_VOTE_BAR' => "themes/$theme/images/forumspro/$language/vote/bar.gif",
	'I_VOTE_RCAP' => "themes/$theme/images/forumspro/$language/vote/rcap.gif",
	'I_WHOS_ONLINE_WHOSONLINE' => "themes/$theme/images/forumspro/$language/whos_online/whosonline.gif",
	)
);