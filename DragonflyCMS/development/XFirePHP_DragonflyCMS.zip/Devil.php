<?
// XFire-PHP by XFirePlus.com
// Dynamic Signature code by TreasureCoastDesigns.com and LegendaryGamers.net

if (isset($_GET['viewsource'])) {
    highlight_file(__FILE__);
    exit;
}
define('XMLFEED', 1);
include('includes/cmsinit.inc');
$result = $db->sql_query("SELECT topic_views, topic_replies FROM ".$prefix."_bbtopics");
while( $post3 = $db->sql_fetchrow($result) ) {
$numviews = $numviews + $post3[topic_views];
$numreplies = $numreplies + $post3[topic_replies];
$numtopics++; } $numposts = $numtopics+$numreplies;

class Security{    function get_ip() { return null; }}

require_once(BASEDIR.'includes/classes/cpg_member.php');
$CLASS['member'] =& new cpg_member();
$userinfo =& $CLASS['member']->members[$CLASS['member']->user_id];
if (is_user()) {
    $slogan = $userinfo['username']." you have $userinfo[user_new_privmsg] new & $userinfo[user_unread_privmsg] unread PM's";
}else{
	$slogan = "LegendaryGamers.net - Registration Required";
}

$result = $db->sql_query("SELECT COUNT(*) FROM ".$user_prefix."_users", true);
list($users) = $db->sql_fetchrow($result);
$db->sql_freeresult($result);
$users--;

$result = $db->sql_query("SELECT title FROM ".$prefix."_stories ORDER BY sid DESC LIMIT 1", true);
list($news) = $db->sql_fetchrow($result);
$db->sql_freeresult($result);
if (strlen($news) > 34) $news = substr($news,0,31).'...';

$result = $db->sql_query("SELECT COUNT(*) FROM ".$prefix."_session WHERE guest = 0", true);
list($memonl) = $db->sql_fetchrow($result);
$db->sql_freeresult($result);

$result = $db->sql_query("SELECT COUNT(*) FROM ".$prefix."_session WHERE guest = 1", true);
list($anonl) = $db->sql_fetchrow($result);
$db->sql_freeresult($result);

//---------------------------------------------------------------------------//
$username='lgdevil';
$image = "Devil.png"; //Specify the name of the png image you want to use
$im = imagecreatefrompng($image);
//---------------------------------------------------------------------------//

/* 
You can add as many text colors as you want!
Simply uncomment the // and change the $tc to $tc2, $tc3, in the ImageString
*/

$tc = ImageColorAllocate ($im, 153, 204, 255); //Light Blue Color
$tc2 = ImageColorAllocate ($im, 255, 255, 0); // Yellow Text Color
$tc3 = ImageColorAllocate ($im, 255, 0, 0); // Red Text Color
//$tc4 = ImageColorAllocate ($im, 255, 255, 255); //White Text Color
$tc5 = ImageColorAllocate ($im, 0, 0, 0); //Black Text Color
$tc6 = imagecolorallocate ($im, 153, 255, 0);  // Lime Text Color

/* 
Disecting the ImageString 
( 2, 0, 0) 
1st # = Font Size 
2nd # = Pixels from left 
3rd # = Pixels from top 
$tc# = Color you specified with ImageColorAllocate 
*/


include('xfireparser.class.php');
// import class data and set username (top level array)
$handle = new xfire_data($username);
// import function data from class (2nd level array)
$Profile = xfire_getmain($username);
$nick = $Profile[profile][nickname];
$online_status = $Profile[profile][status];





// GET 5 MOST PLAYED GAME HOURS OF ALL TIME//
$AllTimePlayed = $Profile[games];
// sort an array by sub key
function sortAllTime($ATarray, $subValue){
global $ahours1, $ahours2, $ahours3, $ahours4, $ahours5 ;
foreach( $ATarray as $atkey => $atvalue )
$tempATList[$atkey] = $atvalue[$subValue];
// sort temp array
arsort($tempATList);
$AllTimeSlice = array_slice($tempATList, 0, 5);
$ahours1 = round($AllTimeSlice[0]/60/60);
$ahours2 = round($AllTimeSlice[1]/60/60);
$ahours3 = round($AllTimeSlice[2]/60/60);
$ahours4 = round($AllTimeSlice[3]/60/60);
$ahours5 = round($AllTimeSlice[4]/60/60);
// merge the ordered list + old values
foreach($AllTimeSlice as $atkey => $atvalue){
$resultATArray[$atkey] = $ATarray[$atkey];
}
// return resulting array
return $resultATArray;
}
$result = sortAllTime($AllTimePlayed, 'alltime');





// GET 5 MOST PLAYED GAME HOURS OF THE WEEK //
$WeeklyPlayed = $Profile[games];
// sort an array by sub key
function sortWeekly($WKarray, $subWKValue){
global $whours1, $whours2, $whours3, $whours4, $whours5 ;
foreach( $WKarray as $wkkey => $wkvalue )
$tempWKList[$wkkey] = $wkvalue[$subWKValue];
// sort temp array
arsort($tempWKList);
$WeeklySlice = array_slice($tempWKList, 0, 5);
$whours1 = round($WeeklySlice[0]/60/60);
$whours2 = round($WeeklySlice[1]/60/60);
$whours3 = round($WeeklySlice[2]/60/60);
$whours4 = round($WeeklySlice[3]/60/60);
$whours5 = round($WeeklySlice[4]/60/60);
// merge the ordered list + old values
foreach($WeeklySlice as $wkkey => $wkvalue){
$resultWKArray[$wkkey] = $WKarray[$wkkey];
}
// return resulting array
return $resultWKArray;
}
$result = sortWeekly($WeeklyPlayed, 'weektime');



// GET 5 MOST PLAYED GAME NAMES OF THE WEEK //
$GamesPlayed = $Profile[games];
// sort an array by sub key
function sortGP($GParray, $subGPValue){
global $gphours1, $gphours2, $gphours3, $gphours4, $gphours5 ;
foreach ($GParray as $gpKEY => $gpVALUE)
{$tempGPList[$gpKEY] = $gpVALUE[$subGPValue];
$nm[$gpKEY] = $gpVALUE['longname'];
$tw[$gpKEY] = $gpVALUE['shortname'];
$at[$gpKEY] = $gpVALUE['alltime'];
$ic[$gpKEY] = $gpVALUE['weektime'];
}
array_multisort($at, SORT_DESC , $tempGPList);
foreach( $GParray as $gpKEY => $gpVALUE )
$tempGPList[$gpKEY] = $gpVALUE[$subGPValue];
$GamesSlice = array_slice($tempGPList, 0, 5);
$gphours1 = $GamesSlice[0];
$gphours2 = $GamesSlice[1];
$gphours3 = $GamesSlice[2];
$gphours4 = $GamesSlice[3];
$gphours5 = $GamesSlice[4];
// merge the ordered list + old values
foreach($GamesSlice as $gpKEY => $gpVALUE){
$resultGPArray[$gpKEY] = $GParray[$gpKEY];
}
return $resultGPArray;
}
$result = sortGP($GamesPlayed, 'longname');










imageellipse ($im, 380, 127, 8, 8, $tc5);
if ($online_status == offline) {
    $status1 = " offline ";
    imagefilledellipse ($im, 380, 127, 6, 6, $tc3);
} else {
    $status1 = " online ";
    imagefilledellipse ($im, 380, 127, 6, 6, $tc6);
}

ImageString($im, 2, 360, 10, "Members: $users", $tc5); //User Count 
ImageString($im, 4, 15, 10, "$nick", $tc5);
ImageString($im, 2, 100, 10, "($username)", $tc5);
ImageString($im, 2, 385, 120, "$status1", $tc5);

ImageString($im, 2, 15, 60, "$gphours1", $tc5);
ImageString($im, 2, 15, 70, "$gphours2", $tc5);
ImageString($im, 2, 15, 80, "$gphours3", $tc5);
ImageString($im, 2, 15, 90, "$gphours4", $tc5);
ImageString($im, 2, 15, 100, "$gphours5", $tc5);

ImageString($im, 2, 350, 60, "$whours1 h", $tc5);
ImageString($im, 2, 350, 70, "$whours2 h", $tc5);
ImageString($im, 2, 350, 80, "$whours3 h", $tc5);
ImageString($im, 2, 350, 90, "$whours4 h", $tc5);
ImageString($im, 2, 350, 100, "$whours5 h", $tc5);

ImageString($im, 2, 400, 60, "$ahours1 h", $tc5);
ImageString($im, 2, 400, 70, "$ahours2 h", $tc5);
ImageString($im, 2, 400, 80, "$ahours3 h", $tc5);
ImageString($im, 2, 400, 90, "$ahours4 h", $tc5);
ImageString($im, 2, 400, 100, "$ahours5 h", $tc5);


ImageString($im, 2, 15, 120, "Site News: $news", $tc5);
header("Content-Type: image/png");
Imagepng($im,'',100);
ImageDestroy ($im);
?> 