<?php
/************************************************************************/
/* DF_Recruitment for DragonflyCMS by DJDevon3							*/
/* ============================================                         */
/* Copyright (c) 2007 TreasureCoastDesigns.com                          */
/************************************************************************/
if (!defined('CPG_NUKE')) { exit; }

/* Index.php */
define("_REAL_FIRST_NAME","Real First Name");
define("_RECRUITMENT_ADMINISTRATION_CONTROL_PANEL","Recruitment Administration Control Panel");
define("_APPLICATION_FORM","Application Form");
define("_AGE","Age");
define("_LOCATION","Location (U.S. State or Canadian Province)");
define("_VOICE","Can You Use Ventrilo");
define("_XFIRE","Xfire User Name");
define("_TIME","Your Time Zone");
define("_LEAGUE","If you have league experience please list the league and how many games you played.");
define("_DONATIONS","Can You Make Donations?");
define("_TEAM_APPLYING_FOR","Team Applying For");
define("_BEST_CLASS_OR_WEAPON","Your Best Weapon");
define("_JOIN_REASON","Why do you want to join the clan?");
define("_RECRUITMENT_REFERRAL","How did you hear about us?");
define("_PREVIOUS_CLANS","If you've been in a clan before please list their website(s)");
define("_AGREEMENT_TERMS","Have you read, and fully agree to the terms of recruitment?");
define("_YES","Yes");
define("_NO","No");
define("_EAST","Eastern");
define("_CENT","Central");
define("_WEST","Pacific");
define("_UNREGISTERED_GUEST_MESSAGE","Sorry, you must be logged in to submit a recruit application");
define("_SUBMIT_APPLICATION","Submit Application");
define("_PENDING_APPLICATIONS","Pending Applications");
define("_APPLICATION_ID","Application #");
define("_APPLICATION_USERNAME","Username");
define("_APPLICATION_TEAM","Team Application");
define("_APPLICATION_DATE","Date Applied");
define("_APPLICATION_STATUS","Status");
define("_ERROR_AGREEMENT","USER ERROR: Please read the rules of recruitment and agree to the terms.");

/* ThankYou.php */
define("_RECRUITMENT_CENTER","Recruitment Center ");

/* ADMIN adwait.inc */
define("_REVIEW_PENDING","Review Pending Clan Applications");
define("_PENDING_RECRUITS","Pending Recruits");

/* ADMIN menu.inc */
define("_VIEW_APPLICATIONS","View Applications");
define("_MESSAGE_CONFIG","Message Config");
define("_ADD_GAME","Add Game");
define("_EDIT_GAME","Edit Game");
define("_DELETE_GAME","Delete Game");
define("_ADD_STATUS","Add Status");
define("_EDIT_STATUS","Edit Status");
define("_DELETE_STATUS","Delete Status");

/* ADMIN index.php */
define("_ADMIN_APPLICATION_ID","ID#");
define("_ADMIN_DETAILS","Details");
define("_ADMIN_SUBMITTED","Submitted");
define("_ADMIN","Admin");
define("_ADMIN_IP_ADDRESS","IP Address");
define("_ADMIN_FIRST_NAME","First Name");
define("_ADMIN_LOCATION","Location");
define("_ADMIN_TIMEZONE","Timezone");
define("_ADMIN_WEAPON_CLASS","Best Weapon/Class");
define("_ADMIN_XFIRE","X-Fire Handle");
define("_ADMIN_VENT","Ventrilo Ability");
define("_ADMIN_DONATION","Donation Ability");
define("_ADMIN_JOIN_REASON","Join Reason");
define("_ADMIN_LEAGUE","League History");
define("_ADMIN_PREVIOUS_CLANS","Clan History");
define("_ADMIN_REFERRAL","Referral");
define("_NOWPLAYING","Date Applied");
define("_ADMIN_APPLICATION_AGREEMENT","Agreed to Terms");

define("_ADD","Add");
define("_EDIT","Edit");
define("_DELETE","Delete");
define("_SAVE_CHANGES","Save Changes");

/* ADMIN index.php (message config) */
define("_INTRO_TEXT","Intro Text");
define("_WELCOME_TEXT","(welcome text)");
define("_AGREEMENT_TEXT","Agreement Text");
define("_PENDING_APPLICATION_AGREEMENT","(pending application description)");
define("_PENDING_TEXT","Pending Text");
define("_THANK_YOU_TEXT","Thank You Text");
define("_CONFIRMATION_PAGE","(confirmation page)");
define("_RADIOSTATS","Radio Status");
define("_NOWPLAYING","Now Playing");
define("_SWITCHTO","Switch to");
define("_TUNEINUSING","TUNE IN USING");
define("_RADIOSTATS","Radio Status");
define("_NOWPLAYING","Now Playing");
define("_SWITCHTO","Switch to");
define("_TUNEINUSING","TUNE IN USING");
define("_RADIOSTATS","Radio Status");
define("_NOWPLAYING","Now Playing");
define("_SWITCHTO","Switch to");
define("_TUNEINUSING","TUNE IN USING");
define("_RADIOSTATS","Radio Status");
define("_NOWPLAYING","Now Playing");
define("_SWITCHTO","Switch to");
define("_TUNEINUSING","TUNE IN USING");
define("_RADIOSTATS","Radio Status");
