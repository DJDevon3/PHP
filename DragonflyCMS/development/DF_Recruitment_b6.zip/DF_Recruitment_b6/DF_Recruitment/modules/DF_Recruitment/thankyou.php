<?php
/************************************************************************/
/* DF_Recruitment for DragonflyCMS by DJDevon3							*/
/* ============================================                         */
/* Copyright (c) 2007 TreasureCoastDesigns.com                          */
/************************************************************************/

if (!defined('CPG_NUKE')) { exit; }

global  $prefix, $db, $module_name, $sitename, $userinfo, $nukeurl, $MAIN_CFG;
require('header.php');
$result = $db->sql_query("SELECT thankyou FROM ".$prefix."_recruitment_config");
list($xthankyou) = $db->sql_fetchrow($result);

if ($userinfo['user_id'] > 1) {
	if ($userinfo['user_avatar_type'] == 1) {
		$avatar = $MAIN_CFG['avatar']['path'].'/'.$userinfo['user_avatar'];
	} else if ($userinfo['user_avatar_type'] == 2) {
		$avatar = $userinfo['user_avatar'];
	} else if ($userinfo['user_avatar_type'] == 3) {
		$avatar = $MAIN_CFG['avatar']['gallery_path'].'/'.$userinfo['user_avatar'];
	}
} else {
	$avatar = 'images/avatars/no_avatar.gif';
}


    OpenTable();
    echo '<div align="center">';
	echo '<div class="title">'.$sitename.' '._RECRUITMENT_CENTER.'</div><br />';

	echo '<br /><img src="'.$avatar.'" border="0" alt="avatar" title="'.$userinfo['username'].'" /><br />';

    echo '<br /><div class="title"><b>'.$userinfo['username'].' - '.$xthankyou.'</b></div><br />';
	echo '<br /><a href="'.$nukeurl.'/'.getlink($module_name).'">Return to '._RECRUITMENT_CENTER.'</a>';

	echo '</div>';
    CloseTable();


?>