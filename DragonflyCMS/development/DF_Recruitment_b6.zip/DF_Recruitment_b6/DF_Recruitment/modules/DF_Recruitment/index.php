<?php
/************************************************************************/
/* DF_Recruitment for DragonflyCMS by DJDevon3							*/
/* ============================================                         */
/* Copyright (c) 2007 TreasureCoastDesigns.com                          */
/************************************************************************/

if (!defined('CPG_NUKE')) { exit; }
$pagetitle = 'Recruitment Center';

function recruitment() {
global  $prefix, $db, $module_name, $sitename, $userinfo, $nukeurl;
require('header.php');
$result = $db->sql_query("SELECT intro, agreement, pending_description FROM ".$prefix."_recruitment_config");
list($intro, $agreement, $pending_description) = $db->sql_fetchrow($result);
$result2 = $db->sql_query("SELECT game_id, game_name FROM ".$prefix."_recruitment_game_options");


    OpenTable();
	echo "<div style='text-align:center;'><img src='modules/".$module_name."/images/RecruitmentLogo.gif' alt='Recruitment Center' border='0' /></div><br />"; 
	echo $intro;
    if (can_admin($module_name)) {
        echo '<br /><br /><div align="right"><a href="'.adminlink($module_name).'">'._RECRUITMENT_ADMINISTRATION_CONTROL_PANEL.'</a></div>'."\n";
    }
    CloseTable();

	echo "<br />";

	OpenTable();
	echo "<fieldset><legend>"._APPLICATION_FORM."</legend>";
	echo "<form action=".getlink('DF_Recruitment&amp;mode=recruit_submit')." method='post'>";
    echo "<table border='1' cellpadding='2' cellspacing='2' align='center'><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._REAL_FIRST_NAME.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xfirstname' size='20' maxlength='20' /></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._AGE.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xage' size='2' maxlength='2' /></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._LOCATION.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xlocation' size='20' maxlength='20' /></td></tr><tr>";
    echo "<td class='row1' nowrap> &nbsp; "._TIME.": &nbsp; </td>";
    echo "<td class='row1'><SELECT name='xtimezone'><OPTION SELECTED VALUE='0'>"._EAST."<OPTION VALUE='1'>"._CENT."<OPTION VALUE='2'>"._WEST."</SELECT></td></tr><tr>";
    echo "<td class='row1' nowrap> &nbsp; "._TEAM_APPLYING_FOR.": &nbsp; </td>";
	echo "<td class='row1'><SELECT name='xgame'>";
	while (list($game_id, $game_name) = $db->sql_fetchrow($result2)) {
		echo '<OPTION VALUE="'.$game_id.'">'.$game_name.'</OPTION>';
	}
	echo "</SELECT></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._BEST_CLASS_OR_WEAPON.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xweapon' size='20' maxlength='20' /></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._XFIRE.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xxfire' size='20' maxlength='20' /></td></tr><tr>";
    echo "<td class='row1' nowrap> &nbsp; "._VOICE.": &nbsp; </td>";
    echo "<td class='row1'><SELECT name='xvent'><OPTION VALUE='0'>"._YES."<OPTION SELECTED VALUE='1'>"._NO."</SELECT></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._DONATIONS.": &nbsp; </td>";
	echo "<td class='row1'><SELECT name='xdonation'><OPTION VALUE='0'>"._YES."<OPTION SELECTED VALUE='1'>"._NO."</SELECT></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._RECRUITMENT_REFERRAL.": &nbsp; </td>";
	echo "<td class='row1'><input type='text' name='xreferral' size='20' maxlength='20' /></td></tr><tr>";
	echo "<td class='row1'> &nbsp; "._LEAGUE.": &nbsp; </td>";
	echo "<td class='row1'><textarea name='xleague' COLS='40' ROWS='6'></textarea></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._JOIN_REASON.": &nbsp; </td>";
	echo "<td class='row1'><textarea name='xreason' COLS='40' ROWS='6'></textarea></td></tr><tr>";
	echo "<td class='row1' nowrap> &nbsp; "._PREVIOUS_CLANS.":&nbsp; </td>";
	echo "<td class='row1'><textarea name='xclans' COLS='40' ROWS='6'></textarea></td>";
	echo "</tr></table>";
	echo "<br /><br />";
	echo "<table border='1' cellpadding='2' cellspacing='2'><tr>";
	echo "<td class='row1'><b>".$agreement."</b><br /><br /></td></tr><tr><td class='row1'>";
	echo ""._AGREEMENT_TERMS." &nbsp; ";
	echo "<SELECT name='xagreed'><OPTION VALUE='0'>"._YES."<OPTION SELECTED VALUE='1'>"._NO."</SELECT>";
	echo "</td></tr></table>";
	echo "<br /><br />";
	$today = strftime('%D');
	echo "<input type='hidden' name='xdate' value='".$today."' />";
	echo "<input type='hidden' name='xstatus' value='1' />";
	$ip = $_SERVER['REMOTE_ADDR'];
	echo "<input type='hidden' name='xip' value='".$ip."' />";
	echo "<input type='hidden' name='xalias' value='".$userinfo['username']."' />";
	if ($userinfo['user_id'] ==1) {
	echo ""._UNREGISTERED_GUEST_MESSAGE."";
	} else {
	echo "<input type='hidden' name='mode' value='recruit_submit' />";
	echo "<div align='center'><input type='submit' value='"._SUBMIT_APPLICATION."' /></div>";
	}
	echo "</form>";
	echo "</fieldset>";
    CloseTable();

//$result = $db->sql_query("SELECT recruit_id, alias, game, date, status FROM ".$prefix."_recruitment ORDER BY recruit_id");
$sql = "
  SELECT r.recruit_id, r.alias, g.game_name, r.date, s.status_name
  FROM      ".$prefix."_recruitment                AS r
  LEFT JOIN ".$prefix."_recruitment_game_options   AS g ON (g.game_id=r.game)
  LEFT JOIN ".$prefix."_recruitment_status_options AS s ON (s.status_id=r.status)
  ORDER BY r.date";
$result = $db->sql_query($sql);
	echo "<br />";
    OpenTable();
	echo "<div align='center' class='title'>"._PENDING_APPLICATIONS."</div><br />";
	echo $pending_description;
	echo "<br />";
	echo "<table border='0' cellpadding='2' cellspacing='2' align='center'><tr>";
	echo "<td class='cat' nowrap> &nbsp; "._APPLICATION_USERNAME." &nbsp; </td>";
	echo "<td class='cat' nowrap> &nbsp; "._APPLICATION_TEAM." &nbsp; </td>";
	echo "<td class='cat' nowrap> &nbsp; "._APPLICATION_DATE." &nbsp; </td>";
	echo "<td class='cat' nowrap> &nbsp; "._APPLICATION_STATUS." &nbsp; </td>";
	echo "</tr>";
while (list($recruit_id, $alias, $game, $date, $status) = $db->sql_fetchrow($result)) {
	echo "<tr><td class='row1'> &nbsp; ".$alias." &nbsp; </td>";
	echo "<td class='row1'> &nbsp; ".$game." &nbsp; </td>";
	echo "<td class='row1'> &nbsp; ".$date." &nbsp; </td>";
	echo "<td class='row1'> &nbsp; ".$status." &nbsp; </td></tr>";
}
	echo "</table>";
	
    CloseTable();


}

function recruit_submit ($xrecruit_id, $xalias, $xfirstname, $xage, $xlocation, $xtimezone, $xgame, $xweapon, $xxfire, $xvent, $xdonation, $xreason, $xleague, $xclans, $xreferral, $xagreed, $xdate, $xstatus, $xip) {
 global $prefix, $db, $module_name;
 $xagreed = $_POST['xagreed'];
 if ($xagreed=='0') {
    $db->sql_query("INSERT INTO ".$prefix."_recruitment SET recruit_id='$xrecruit_id', alias='$xalias', firstname='$xfirstname', age='$xage', location='$xlocation', timezone='$xtimezone', game='$xgame', weapon='$xweapon', xfire='$xxfire', vent='$xvent', donation='$xdonation', reason='$xreason', league='$xleague', clans='$xclans', referral='$xreferral', date='$xdate', agreed='$xagreed', status='$xstatus', ip='$xip'");
	url_redirect(getlink('DF_Recruitment&amp;file=thankyou'));
		} else {
	die(""._ERROR_AGREEMENT."");
		}
}


// import the mode variable (register globals off)
$mode = isset($_POST['mode']) ? $_POST['mode'] : (isset($_GET['mode']) ? $_GET['mode']:'');
switch ($mode) {

    default:
	case "recruitment":
	recruitment ();
	break;

    case "recruit_submit":
        $xrecruit_id = isset($_POST['xrecruit_id']) ? intval($_POST['xrecruit_id']) : '';
		$xalias = isset($_POST['xalias']) ? Fix_Quotes($_POST['xalias']) : '';
		$xfirstname = isset($_POST['xfirstname']) ? Fix_Quotes($_POST['xfirstname']) : '';
		$xage = isset($_POST['xage']) ? Fix_Quotes($_POST['xage']) : '';
// use intval() to ensure input is a numeric integer
//		$xgame = isset($_POST['xgame']) ? Fix_Quotes($_POST['xgame']) : '';
		$xtimezone = isset($_POST['xtimezone']) ? Fix_Quotes($_POST['xtimezone']) : '';
		$xgame = isset($_POST['xgame']) ? intval($_POST['xgame']) : 0;
		$xlocation = isset($_POST['xlocation']) ? Fix_Quotes($_POST['xlocation']) : '';
		$xweapon = isset($_POST['xweapon']) ? Fix_Quotes($_POST['xweapon']) : '';
		$xxfire = isset($_POST['xxfire']) ? Fix_Quotes($_POST['xxfire']) : '';
		$xvent = isset($_POST['xvent']) ? Fix_Quotes($_POST['xvent']) : '';
		$xdonation = isset($_POST['xdonation']) ? intval($_POST['xdonation']) : 0;
		$xreason = isset($_POST['xreason']) ? Fix_Quotes($_POST['xreason']) : '';
		$xleague = isset($_POST['xleague']) ? Fix_Quotes($_POST['xleague']) : '';
		$xclans = isset($_POST['xclans']) ? Fix_Quotes($_POST['xclans']) : '';
		$xreferral = isset($_POST['xreferral']) ? Fix_Quotes($_POST['xreferral']) : '';
		$xagreed = isset($_POST['xagreed']) ? Fix_Quotes($_POST['xagreed']) : '';
		$xdate = isset($_POST['xdate']) ? Fix_Quotes($_POST['xdate']) : '';
// use intval() to ensure input is a numeric integer
//		$xstatus = isset($_POST['xdate']) ? Fix_Quotes($_POST['xstatus']) : '';
		$xstatus = isset($_POST['xstatus']) ? intval($_POST['xstatus']) : 0;
		$xip = isset($_POST['xip']) ? Fix_Quotes($_POST['xip']) : '';
	recruit_submit ($xrecruit_id, $xalias, $xfirstname, $xage, $xlocation, $xtimezone, $xgame, $xweapon, $xxfire, $xvent, $xdonation, $xreason, $xleague, $xclans, $xreferral, $xagreed, $xdate, $xstatus, $xip);
	break;
}
?>
