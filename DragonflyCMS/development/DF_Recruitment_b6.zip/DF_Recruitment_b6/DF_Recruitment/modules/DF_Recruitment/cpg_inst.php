<?php

/************************************************************************/
/* DF_Recruitment for DragonflyCMS by DJDevon3							*/
/* ============================================                         */
/* Copyright (c) 2007 TreasureCoastDesigns.com                          */
/************************************************************************/

if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class DF_Recruitment {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function DF_Recruitment() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'DF_Recruitment';
		$this->description = 'An original Clan Recruiting Module for DragonflyCMS';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('recruitment', 'recruitment_game_options', 'recruitment_status_options', 'recruitment_config');
	}

// module installer
// 'game'   changed from VARCHAR to INT
// 'status' changed from VARCHAR to INT
	function install() {
		global $installer;
// removed key 'recruit_id' as it's already defined as primary
		$installer->add_query('CREATE', 'recruitment', "
			recruit_id int(11) NOT NULL auto_increment,
			alias varchar(20) NOT NULL default '',
			firstname text(20) NOT NULL default '',
			age varchar(2) NOT NULL default '',
			location varchar(25) NOT NULL default '',
		timezone INT(11) NOT NULL default '',
			game INT(11) NOT NULL default '',
			weapon varchar(25) NOT NULL default '',
		xfire varchar(25) NOT NULL default '1',
		vent tinyint(1) NOT NULL default '1',
		donation tinyint(1) NOT NULL default '1',
			reason text(255) NOT NULL default '',
		league text(255) NOT NULL default '',
			clans varchar(50) NOT NULL default '',
			referral varchar (50) NOT NULL default '',
			agreed tinyint(1) NOT NULL default '1',
			date varchar(20) NOT NULL default '',
			status INT(11) NOT NULL default '',
			ip varchar(25) NOT NULL default '',
			PRIMARY KEY (recruit_id)", 'recruitment');

// removed key 'game_id' as it's already defined as primary
		$installer->add_query('CREATE', 'recruitment_game_options', "
			game_id int(11) NOT NULL auto_increment,
			game_name varchar(55) NOT NULL default '',
			PRIMARY KEY (game_id)", 'recruitment_game_options');

// removed key 'status_id' as it's already defined as primary
		$installer->add_query('CREATE', 'recruitment_status_options', "
			status_id int(11) NOT NULL auto_increment,
			status_name varchar(50) NOT NULL default '',
			PRIMARY KEY (status_id)", 'recruitment_status_options');

// removed keys as there's only one record in this file
// and no look-up is performed on it using an index search
		$installer->add_query('CREATE', 'recruitment_config', "
			thankyou varchar(255) NOT NULL default '',
			intro text NOT NULL,
			agreement text NOT NULL,
			pending_description text NOT NULL", 'recruitment_config');

// replaced game name with it's ID number
// replaced status name with it's ID number (and used option 3 - Approved)
			
			$installer->add_query('INSERT', 'recruitment_game_options', "'1', 'Counter Strike: Source'");
			$installer->add_query('INSERT', 'recruitment_game_options', "'2', 'Quake 3'");
			$installer->add_query('INSERT', 'recruitment_game_options', "'3', 'Quake 4'");

			$installer->add_query('INSERT', 'recruitment_status_options', "'1', 'Pending'");
			$installer->add_query('INSERT', 'recruitment_status_options', "'2', 'Recruit'");
			$installer->add_query('INSERT', 'recruitment_status_options', "'3', 'Approved'");
			$installer->add_query('INSERT', 'recruitment_status_options', "'4', 'Denied'");

			$installer->add_query('INSERT', 'recruitment_config', "'Your application has been submitted and will be reviewed shortly...', '<div align=center class=title><b>Legendary Gamers Recruitment Center<br />This area is still under heavy construction. <br />Feel free to test it out! All submissions will be ignored/deleted for now.</b></div>', 'Terms of Recruitment<br /><br />1. Recruits will always treat other players with respect.  As a recruit and member you are expected to represent our clan in public.  Your behavior does reflect us.  If your behavior does not represent us then be expected to be shown the door.<br /><br />2. Your application must be truthful. If you do not list all previous clans for instance it would be grounds for your immediate discharge from the clan.<br /><br />3. You must be active and visible during your recruitment in our web forums, game server, and teamspeak channel.  The more visible you are the better your chances of becoming a member.  We only accept dedicated gamers here.', '<div align=center><b>Once your application has been submitted it is your responsibility to notify your potential team leader so they can review your application</b></div>'");
	
	return true;
    }


// module uninstaller
	function uninstall() {
		global $installer;
//		$installer->add_query('DROP', 'recruitment');
//		$installer->add_query('DROP', 'recruitment_game_options');
//		$installer->add_query('DROP', 'recruitment_status_options');
//		$installer->add_query('DROP', 'recruitment_config');

  // this is simpler and allows for any additional tables
  // that might be added
    foreach ($this->dbtables AS $table) {
  		$installer->add_query('DROP', $table);
    }
		return true;
	}
}
?>
