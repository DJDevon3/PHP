<?php
/***************************************************************************
   Coppermine 1.3.1 for CPG-Dragonfly™
  **************************************************************************
   Port Copyright (c) 2004-2005 CPG Dev Team
   http://dragonflycms.com/
  **************************************************************************
   v1.1 (c) by Grégory Demar http://coppermine.sf.net/
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  **************************************************************************
  Last modification notes:
  $Source: /cvs/html/modules/coppermine/anycontent.php,v $
  $Revision: 9.2 $
  $Author: djmaze $
  $Date: 2005/10/11 12:50:47 $
****************************************************************************/
if (!defined('CPG_NUKE')) { die("You can't access this file directly..."); }
starttable('100%', 'Any Content~~ Customized: Advertising');
?></tr><tr><td>
        <table class="tableb" width="100%" cellspacing="10">
            <tr> 
                <td colspan="2" align="center" valign="middle">
                <?php
                    if (can_admin()){echo'ADMIN: For info how to change this advertisment view your <a class="content" href="'.getlink("&amp;file=help#config").'"> help file regarding content of the main page. </a><br /></td></tr><tr>
                <td align="center" valign="middle"> ';
                }?>  
                <a href="http://www.allposters.com/gallery.asp?aid=779690&amp;item=96805"><img src="http://imagecache2.allposters.com/images/20/WAG2050.JPG" alt="Spirit of Bob Marley" width="100" height="150" border="0" /></a><br />
                    <font size="-1">Spirit of Bob Marley<br />
                    24 in x 36 in<br />
                    <a href="http://www.allposters.com/gallery.asp?aid=779690&amp;item=96805">Buy This Poster At AllPosters.com</a></font></td>
                <td align="center" valign="middle"> 
                    <div align="left"><b>Hey Guys Check this out! - You can add <u>hundreds of thousands</u> of copyrighted images to your site – <u>Free</u>!</b><br />
                        <br />
                        Join the <a href="http://affiliates.allposters.com/link/redirect.asp?AID=1809610441&amp;PSTID=1&amp;LTID=19&amp;LID=111&amp;TID1=123456&amp;ParentAID=1809610441" target="_blank">AllPosters.com 
                        Affiliates Program</a> and get access to hundreds of 
                        thousands of images for your site. AllPosters.com 
                        has images from popular movies, music groups, sports 
                        teams, fine art, and much more. Adding these images 
                        to your site will enhance your content.<br />
                        <br />
                        Furthermore, you get paid for improving your site 
                        with poster/print images! All of the images you use 
                        can link to AllPosters.com where your site visitors 
                        can make purchases. When they buy something, AllPosters.com 
                        pays you <b>25% - 30%</b> of the sale. If the visitor 
                        decides to purchase within 10 days of their last visit 
                        from your website, you'll still earn commission on 
                        the sale! It’s easy to sign-up, build links, and track 
                        your sales.<br />
                        <br />
                        <a href="http://affiliates.allposters.com/link/redirect.asp?AID=1809610441&amp;PSTID=1&amp;LTID=19&amp;LID=111&amp;TID1=123456&amp;ParentAID=1809610441" target="_top">Sign 
                        up today!</a>
                    </div>
                </td>
            </tr>
        </table>
</td></tr></table>
<?php
endtable();