<?PHP
#######################################
# IF YOU WISH TO USE THIS PLEASE INCLUDE THESE COMMENTS AND INFORMATION
# THANKS
#
# Written by Casey "A Sniper" Shea
# Weapons Factory Software
# http://www.wfrevolution.com/
# Email: ASniper AT WFRevolution DOT Com
# Last Updated: 12-21-2005
#
# ----Description----
# Included PHP Document for GameQ Created for query of QUAKE 4 Servers
# Use at your own risk
#
# ---- Bug Reports ----
# if for some reason you find a bug or error with this script, which is possible
# please email me with the error and i will try my best to fix it, also if for some
# reason not all the player data is being displayed, because its so hard to filter 
# everything out, please email me, and give me a server IP so that i may try to find out
# what isnt being parsed from the player names, which has been the main problem. im pretty sure
# i got most of it done but there may be a wierd ass character or two that someone will use that
# may break it.
#
# Enjoy and if you have any other questions or comments be sure to email me id love to hear them.
#######################################
// QUAKE 4
if (isset($data[0])) {
	$data = $data[0];
}
if (isset($data) && !is_array($data)) {
	if (preg_match("/^\xff\xff\x69\x6E\x66\x6F\x52\x65\x73\x70\x6F\x6E\x73\x65..{4}(.)(.)(.)/", $data, $match)) {
		$parsed_data['version'] = ord($match[1]) . ord($match[2]);
		$match[0] .= $match[3].$match[4];
		$data = substr($data, strlen($match[0]));
		
		//get variable & value
		while (preg_match("/^([a-zA-Z0-9_]+)\S([a-zA-Z0-9\x0A-\xef\^_ \.=!@#\$%&\*\(\)\[\]\?\\<\~\`\�\�\>\'\,\|\{\}\+-]*)\S/", $data, $match)) {
			$match[1] = strtolower($match[1]);
			$parsed_data[$match[1]] = $match[2];
			$data = substr($data, strlen($match[0]));
		}
		if (preg_match("/^\S{2}/", $data, $match)) {
			$data = substr($data, 2);
			
			//player info
			$si_numPlayers = 0;
			$i = 0;
			while (preg_match("/^(.)(..)(.)(.).{2}([a-zA-Z0-9\x0A-\xef\^_ \.=!@#\$%&\*\(\)\[\]\?\\<\~\`\�\�\>\'\,\|\{\}\+-]+)\S([a-zA-Z0-9\x0A-\xef\^_ \.=!@#\$%&\*\(\)\[\]\?\\<\~\`\�\�\>\'\,\|\{\}\+-]*)\S/", $data, $match)) {
				$player['id']   = ord($match[1]);
				$player['ping']	= ord($match[2]);
				//score? wtf? ffs wheres the score raven?  :(
				$player['rate'] = ord($match[3]) + (ord($match[4]) * 256);
				$player['name'] = $match[5];
				$player['clan'] = $match[6];
				$parsed_data['players'][$i] = $player;
				$data = substr($data, strlen($match[0]));
				$i++;
			}
			$output = $parsed_data;
			$player_count  = count($output['players']);
			$output['si_numPlayers'] = $player_count;
		}
	}
}
?>