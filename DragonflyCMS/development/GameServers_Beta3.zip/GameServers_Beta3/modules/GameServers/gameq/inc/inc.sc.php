<?PHP

/*
 * GameQ - Source Engine protocol (http://gameq.sf.net)
 * Copyright (C) 2004 Ben Soltoff (ben_soltoff@adelphia.net)
 * Based off the original Half Life protocol developed by Tom Buskens
 *
 * GameQ Copyright (C) 2003 Tom Buskens (tombuskens@users.sourceforge.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */
define('SOCK_TIMEOUT', '10');
/* first string (details) */
if (!empty($data[0]))
{
	$d = $data[0];

	$i = 5;
	//$output['data'] = $d;
	/* parse variables */
	$output['net_protocol']	= ord($d{$i++});
	$output['hostname']		= $this->aux->HLString($d, $i);
	$output['map']			= $this->aux->HLString($d, $i);
	$output['game_dir']		= $this->aux->HLString($d, $i);
	$output['game_type']	= $this->aux->HLString($d, $i);
	$output['appid']		= ord($d{$i++}.$d{$i++});
	$output['num_players']	= ord($d{$i++});
	$output['max_players']	= ord($d{$i++});
	$output['bot_players']	= ord($d{$i++});
	$output['dedicated']	= $d{$i++};
	$output['server_os']	= $d{$i++};
	$output['needpass']		= ord($d{$i++});
	$output['secure']		= ord($d{$i++});
	$output['version']	= $this->aux->HLSTRING($d,  $i);
}

if (!empty($data[1]))
{
	$d = $data[1];
	$challengenumber = substr($data[1], 5, 4);
	$foo = $this->aux->source_aux($challengenumber,"\xFF\xFF\xFF\xFFU",$this->svr_address,$this->svr_port);
		if (!empty($foo))
		{
			$d      = $foo[0];
			$strlen = strlen($d);
    			$i      = 5;

   	 		/* get player number */
    			$player_cnt = ord($d{$i++});

    			for ($j = 0; $j != $player_cnt && $i < $strlen; $j++)
    			{
     		   		/* player id */
   		     		$player['id'] = ord($d{$i++});
		
    		    		/* player name */
   		     		for ($start = $i; $i != $strlen && $d{$i} != "\x00"; $i++);
        				$player['name'] = htmlentities(substr($d, $start, $i - $start));
        				$i++;

        				$score = @unpack("Llint",  substr($d, $i, 4)); $i += 4;
        				$time  = @unpack("ffloat", substr($d, $i, 4)); $i += 4;

        				$player['score'] = $score['lint'];
        				$player['time']  = date("i:s", mktime(0, 0, $time['float']));
        				if($output['num_players'] > 0) {
							$output['players'][$j] = $player;
    					}
					}	

				$this->aux->sortPlayers($output, 'quake');

			}
	$foo = $this->aux->source_aux($challengenumber,"\xFF\xFF\xFF\xFFV",$this->svr_address,$this->svr_port);
		if (!empty($foo[0])) {

    			if (empty($foo[1])) {
        			$d = $foo[0];
    			}
    			else {
        			$d = $foo[1] . $foo[0];
    			}
   
    			// Remove possible second packet header
    			$d = preg_replace("/\xFE\xFF\xFF\xFF.{5}/", '', $d);

    			// Remove first packet header
    			$d = preg_replace("/^\xFF\xFF\xFF\xFF\x45.{2}/", '', $d);

    			/* process string */
    			$pieces = explode("\x00", $d);
    			$count  = count($pieces);

    			for ($i = 1; $i < $count; $i += 2) {
        			$output[$pieces[$i - 1]] = $pieces[$i];
    			}
		}
		
}


?>