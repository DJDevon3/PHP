<?php
echo "<table border='0' cellpadding='0' cellspacing='10' width='100%'>"
    ."<tr><td width='30%'>"._SERVERNAME."</td><td width='40%'>".Q3colors($data[$GSgame]['si_name'], $GSTags)."</td><td width='40%' valign='top' rowspan='15'>"
    ."<table><tr><td colspan=3>".MapPic($data[$GSgame]['custom']['id'], $data[$GSgame]['si_map'], 0, "")."</td></tr><tr><td>";

		if (GetArrVal($data[$GSgame]['si_numPlayers'])!=0){
			$cols[0] = array(_PLAYERNAME, _SCORE, _PING);

			for ($p = 0; $p <= GetArrVal($data[$GSgame]['si_numPlayers'])-1 ; $p++){
				$cols[$p+1][0] = Q3colors($data[$GSgame]['players'][$p]['name'], $GSTags);
				$cols[$p+1][1] = GetArrVal($data[$GSgame]['players'][$p]['score']);
				$cols[$p+1][2] = GetArrVal($data[$GSgame]['players'][$p]['ping']);
			}
		echo PlayerList($cols);
		}


echo "</td></tr></table>";
echo "</td></tr>"
    ."<tr><td>"._HOSTADDRESS."</td><td>".$data[$GSgame]['custom']['address'].":".$data[$GSgame]['custom']['query_port']."</td></tr>"
	."<tr><td>"._JOINGAME."</td><td>".ASElink($data[$GSgame]['custom'], "Q4")."</td></tr>"
    ."<tr><td>"._SERVERTYPE."</td><td>";
    echo " ";
    if(strstr(GetArrVal($data[$GSgame]['version']), 'win')) {
		echo _WINDOWS;
    } elseif(strstr(GetArrVal($data[$GSgame]['version']), 'lin')) {
    	echo _LINUX;
    } else {
    	echo _UNKNOWN;
    }
echo "<tr><td>"._MAPNAME."</td><td>".GetArrVal($data[$GSgame]['si_map'])."</td></tr>";
if (isset($data[$GSgame]['si_version'])){
echo "<tr><td>"._SVERSION."</td><td>".GetArrVal($data[$GSgame]['si_version'])."</td></tr>";
}
echo "<tr><td>"._PING."</td><td>".$ping."</td></tr>";
echo "<tr><td>"._GAMETYPE."</td><td>".GetArrVal($data[$GSgame]['si_gametype'])."</td></tr>"
    ."<tr><td>"._PLAYERS."</td><td>".GetArrVal($data[$GSgame]['si_numPlayers'])."/".GetArrVal($data[$GSgame]['si_maxplayers'])."</td></tr>";
if (isset($data[$GSgame]['si_usepass'])){
echo "<tr><td>"._PASSWORD."</td><td>";
    if(GetArrVal($data[$GSgame]['si_usepass'])) {
		echo _PASSREQY;
    } else {
    	echo _PASSREQN;
    }
}

if (isset($data[$GSgame]['si_timelimit'])){
echo "<tr><td>"._TIMELIMIT."</td><td>".GetArrVal($data[$GSgame]['si_timelimit'])."</td></tr>";
}
if (isset($data[$GSgame]['si_fraglimit'])){
echo "<tr><td>"._FRAGLIMIT."</td><td>".GetArrVal($data[$GSgame]['si_fraglimit'])."</td></tr>";
}
if (isset($data[$GSgame]['si_pointlimit'])){
echo "<tr><td>"._POINTLIMIT."</td><td>".GetArrVal($data[$GSgame]['si_pointlimit'])."</td></tr>";
}
if (isset($data[$GSgame]['si_capturelimit'])){
echo "<tr><td>"._CAPLIMIT."</td><td>".GetArrVal($data[$GSgame]['si_capturelimit'])."</td></tr>";
}
if (isset($data[$GSgame]['sv_punkbuster'])){
echo "<tr><td>"._PUNKBUSTER."</td><td>".Abled($data[$GSgame]['sv_punkbuster'])."</td></tr>";
}
if (isset($data[$GSgame]['si_pure'])){
echo "<tr><td>"._PURE."</td><td>".Abled($data[$GSgame]['si_pure'])."</td></tr>";
}
if (isset($data[$GSgame]['.location'])){
echo "<tr><td>"._LOCATION."</td><td>".GetArrVal($data[$GSgame]['.location'])."</td></tr>";
}
if (isset($data[$GSgame]['Location'])){
echo "<tr><td>"._LOCATION."</td><td>".GetArrVal($data[$GSgame]['Location'])."</td></tr>";
}

if (isset($data[$GSgame]['.admin'])){
	if (isset($data[$GSgame]['.email'])){
	echo "<tr><td valign='top'>"._ADMININFO."</td><td valign='top'><a href=\"mailto:".GetArrVal($data[$GSgame]['.email'])."\">".Q3Colors($data[$GSgame]['.admin'], 1)."</a>";
	} else {
	echo "<tr><td valign='top'>"._ADMININFO."</td><td valign='top'>".Q3Colors($data[$GSgame]['.admin'], 0);
	}
	if (isset($data[$GSgame]['.www'])){
		echo "<br><a href=\"";
			if(substr(strtolower(GetArrVal($data[$GSgame]['.www'])), 0, 7)=="http://") {
			 echo GetArrVal($data[$GSgame]['.www']);
			} else {
			 echo "http://".GetArrVal($data[$GSgame]['.www']);
			}
		echo "\" target=\"_blank\">"._WWW."</a>";
	}
echo "</td></tr>";
}

if (isset($data[$GSgame]['Administrator'])){
	if (isset($data[$GSgame]['Email'])){
	echo "<tr><td valign='top'>"._ADMININFO."</td><td valign='top'><a href=\"mailto:".GetArrVal($data[$GSgame]['Email'])."\">".Q3Colors($data[$GSgame]['Administrator'], 1)."</a>";
	} else {
	echo "<tr><td valign='top'>"._ADMININFO."</td><td valign='top'>".Q3Colors($data[$GSgame]['Administrator'], $GSTags);
	}
	if (isset($data[$GSgame]['URL'])){
		echo "<br><a href=\"";
			if(substr(strtolower(GetArrVal($data[$GSgame]['URL'])), 0, 7)=="http://") {
			 echo GetArrVal($data[$GSgame]['URL']);
			} else {
			 echo "http://".GetArrVal($data[$GSgame]['URL']);
			}
		echo "\" target=\"_blank\">"._WWW."</a>";
	}

echo "</td></tr>";
}

echo "</table>";

?>