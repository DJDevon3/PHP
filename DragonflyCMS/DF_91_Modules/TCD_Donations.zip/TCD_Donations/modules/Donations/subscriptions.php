<?php 
if (!defined('CPG_NUKE')) { exit; }

function Subscriptions() {
global $userinfo, $prefix, $db, $module_name, $MAIN_CFG, $nukeurl, $pagetitle;
$pagetitle .= ' '._BC_DELIM.' Subscriptions';
require('header.php');
$user_id = $userinfo['user_id'];
$username = $userinfo['username'];
require_once('modules/'.$module_name.'/menu.php');
$now_month = date("m");
$now_year = date("Y");

// SUBSCRIPTIONS FORM
OpenTable();
	$result = 'SELECT cfg_01, cfg_02, cfg_03, cfg_04, cfg_05, cfg_06, cfg_07, cfg_08, cfg_09, cfg_10, cfg_11, cfg_12, cfg_email, cfg_cancel_url, cfg_return_url, cfg_ipn_url, cfg_currency, cfg_intro, cfg_sub_intro FROM '.$prefix.'_donations_cfg';
	$rows = $db->sql_query($result);
	list($cfg_01, $cfg_02, $cfg_03, $cfg_04, $cfg_05, $cfg_06, $cfg_07, $cfg_08, $cfg_09, $cfg_10, $cfg_11, $cfg_12, $cfg_email, $cfg_cancel_url, $cfg_return_url, $cfg_ipn_url, $cfg_currency, $cfg_intro, $cfg_sub_intro) = $db->sql_fetchrow($rows);

	$sand_res = 'SELECT sandbox_enabled, sandbox_user, sandbox_buyer, sandbox_seller FROM '.$prefix.'_donations_sandbox';
	$sand_rows = $db->sql_query($sand_res);
	list($sandbox_enabled, $sandbox_user, $sandbox_buyer, $sandbox_seller) = $db->sql_fetchrow($sand_rows);

	if($sandbox_enabled==1){
		$sandbox_enabled_message = "~ Sandbox Enabled ~ <br /> All Transactions = NULL";
		$subscription_action = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		$sandbox_business = $sandbox_seller;
		$test_ipn = "1";
	} else{
		$subscription_action = "https://www.paypal.com/cgi-bin/webscr";
		$sandbox_business = $cfg_email;
		$test_ipn = "0";
	}


$cpgtpl->assign_vars(array(
'MODULE_NAME'				=> $module_name,
'CFG_SUB_INTRO'				=> $cfg_sub_intro,
'CFG_CURRENCY'				=> $cfg_currency,
'CFG_IPN_URL'				=> $cfg_ipn_url,
'SUBSCRIPTION_FORM_ACTION'	=> $subscription_action,
'SANDBOX_BUSINESS'			=> $sandbox_business,
'S_USER_ID'					=> $user_id,
'NUKEURL'					=> $nukeurl,
'PAYPAL_TEST_IPN'			=> $test_ipn,
'SANDBOX_ENABLED_MESSAGE'	=> $sandbox_enabled_message,
));


// THIS MONTHS SUBSCRIPTIONS
$sql = "
SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, s.sub_subscr_sid, s.sub_subscr_uid, s.sub_subscr_uname, s.sub_subscr_date, s.sub_period1, s.sub_amount1, s.sub_payer_email
FROM ".$prefix."_users AS u
INNER JOIN ".$prefix."_donations_subscriptions AS s ON (u.user_id=s.sub_subscr_uid)
WHERE s.sub_subscr_date <=('".$now."') AND s.sub_subscr_date >=('".$now_year."-".$now_month."-01 00:00:00') 
ORDER BY s.sub_subscr_date DESC LIMIT 10";
$result = $db->sql_query($sql);
$avatar_path = $MAIN_CFG['avatar']['path'];
$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

while(list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $sub_subscr_sid, $sub_subscr_uid, $sub_subscr_uname, $sub_subscr_date, $sub_period1, $sub_amount1, $sub_payer_email) = $db->sql_fetchrow($result)){
	$money = number_format($sub_amount1,2);
	if ($u_user_avatar == '') {
		$avatar = 'images/avatars/gallery/blank.gif';
	} else if ($u_user_avatar_type == 1) {
		$avatar = "$avatar_path/$u_user_avatar";
	} else if ($u_user_avatar_type == 2) {
		$avatar = $u_user_avatar;
	} else if ($u_user_avatar_type == 3) {
		$avatar = "$avatar_gallery/$u_user_avatar";
	} else {
		$avatar = 'images/avatars/gallery/blank.gif';
	}

	# CATEGORY TEMPLATE
	$cpgtpl->assign_block_vars('month_subscriptions', array(
	'DONATION_AVATAR' 			=> $avatar,
	'DONATION_USERNAME' 		=> $sub_subscr_uname,
	'DONATION_AMOUNT' 			=> $sub_amount1,
	'DONATION_TIMESTAMP' 		=> $sub_subscr_date,
	'DONATION_PAYER' 			=> $sub_payer_email,
	'DONATION_USER_PROFILE'		=> getlink('Your_Account&profile='.$sub_subscr_uname.''),
	));

	}


$cpgtpl->set_filenames(array('body' => 'Donations/subscriptions.html'));
$cpgtpl->display('body');

	CloseTable();
	echo "<br />";

}


?>