<?php 
if (!defined('CPG_NUKE')) { exit; }
$pagetitle = 'Donations >> Stats';
get_lang('donations');

function Monthly_Stats($req_year, $req_month, $max){
	global $prefix, $db, $cfg_01, $cfg_02, $cfg_03, $cfg_04, $cfg_05, $cfg_06, $cfg_07, $cfg_08, $cfg_09, $cfg_10, $cfg_11, $cfg_12;
	if ($req_month == 1){
		$goal = $cfg_01;
		$month_title = 'January';
		$month_num = '01';
		$next_month ='02';
		$next_year=$req_year;
	} else if($req_month == 2){
		$goal = $cfg_02;
		$month_title = 'February';
		$month_num = '02';
		$next_month ='03';
		$next_year=$req_year;
	} else if($req_month == 3){
		$goal = $cfg_03;
		$month_title = 'March';
		$month_num = '03';
		$next_month ='04';
		$next_year=$req_year;
	} else if($req_month == 4){
		$goal = $cfg_04;
		$month_title = 'April';
		$month_num = '04';
		$next_month ='05';
		$next_year=$req_year;
	} else if($req_month == 5){
		$goal = $cfg_05;
		$month_title = 'May';
		$month_num = '05';
		$next_month ='06';
		$next_year=$req_year;
	} else if($req_month == 6){
		$goal = $cfg_06;
		$month_title = 'June';
		$month_num = '06';
		$next_month ='07';
		$next_year=$req_year;
	} else if($req_month == 7){
		$goal = $cfg_07;
		$month_title = 'July';
		$month_num = '07';
		$next_month ='08';
		$next_year=$req_year;
	} else if($req_month == 8){
		$goal = $cfg_08;
		$month_title = 'August';
		$month_num = '08';
		$next_month ='09';
		$next_year=$req_year;
	} else if($req_month == 9){
		$goal = $cfg_09;
		$month_title = 'September';
		$month_num = '09';
		$next_month ='10';
		$next_year=$req_year;
	} else if($req_month == 10){
		$goal = $cfg_10;
		$month_title = 'October';
		$month_num = '10';
		$next_month ='11';
		$next_year=$req_year;
	} else if($req_month == 11){
		$goal = $cfg_11;
		$month_title = 'November';
		$month_num = '11';
		$next_month ='12';
		$next_year=$req_year;
	} else if($req_month == 12){
		$goal = $cfg_12;
		$month_title = 'December';
		$month_num = '12';
		$next_month ='01';
		$next_year=$req_year+1;
	}
	$now_month = date("m");
	$now_year = date("Y");

	$yearly_grid = "
	SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_visible, d.trans_timestamp, SUM(ROUND(d.trans_net,2)), d.trans_memo
	FROM ".$prefix."_users AS u
	INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid) 
	WHERE trans_lgstamp<= DATE_FORMAT('".$next_year."-00-00 00:00:00', '%Y-%m') AND trans_lgstamp>=DATE_FORMAT('".$req_year."-00-00 00:00:00', '%Y-%m') AND d.trans_visible='1'";
    $result = $db->sql_query($yearly_grid);
	list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_visible, $d_trans_timestamp, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result);

	$monthly_grid = "SELECT SUM(ROUND(trans_net,2)) as total, YEAR(trans_lgstamp) as year, MONTH(trans_lgstamp) as month FROM ".$prefix."_donations WHERE trans_lgstamp<= DATE_FORMAT('".$next_year."-".$next_month."-00 00:00:00', '%Y-%m') AND trans_lgstamp>=DATE_FORMAT('".$req_year."-".$month_num."-00 00:00:00', '%Y-%m') AND trans_visible='1'ORDER BY trans_lgstamp ASC";
	$rows = $db->sql_query($monthly_grid);
	while(list($total, $year, $month) = $db->sql_fetchrow($rows)){


			if($month_num=='01'){
				echo "<tr><td nowrap='nowrap' align='center'> ".$next_year." </td>";
				if($month==$now_month && $year==$now_year){
					echo "<td style='background-color:#C7DAA2;font-color:#FFFFFF;' nowrap='nowrap' align='center'>";
				} else {
					echo "<td style='background-color:#D1D1D1;' nowrap='nowrap' align='center'>";
				}
				if($total==$max){
					echo "<b>".$total."</b>";
				}else{
					echo $total;
				}
				echo "</td>";
			} else if($month_num=='12'){
				if($month==$now_month && $year==$now_year){
					echo "<td style='background-color:#C7DAA2;font-color:#FFFFFF;' nowrap='nowrap' align='center'>";
				} else {
					echo "<td style='background-color:#D1D1D1;' nowrap='nowrap' align='center'>";
				}
				if($total==$max){
					echo "<b>".$total."</b>";
				}else{
					echo $total;
				}
				echo "</td><td nowrap='nowrap' align='center'>".$d_trans_net."</td></tr>";
			} else {
				if($month==$now_month && $year==$now_year){
					echo "<td style='background-color:#C7DAA2;font-color:#FFFFFF;' nowrap='nowrap' align='center'>";
				} else {
					echo "<td style='background-color:#D1D1D1;' nowrap='nowrap' align='center'>";
				}
				if($total==$max){
					echo "<b>".$total."</b>";
				}else{
					echo $total;
				}
				echo "</td>";
			}
	}
	$db->sql_freeresult($rows);
}


function Stats() {
global $userinfo, $prefix, $db, $module_name, $MAIN_CFG, $startdate;
require('header.php');
$user_id = $userinfo['user_id'];
require_once('modules/'.$module_name.'/menu.php');
$now = date("Y")."-".date("m")."-".date("d")." ".date("G").":".date("i").":".date("s");
$now_month = date("m");
$now_year = date("Y");
if ($now_month == 12){
	$now_year=$now_year+1;
}

$result = 'SELECT cfg_01, cfg_02, cfg_03, cfg_04, cfg_05, cfg_06, cfg_07, cfg_08, cfg_09, cfg_10, cfg_11, cfg_12, cfg_email, cfg_cancel_url, cfg_return_url, cfg_ipn_url, cfg_stats, cfg_currency, cfg_intro FROM '.$prefix.'_donations_cfg';
$rows = $db->sql_query($result);
list($cfg_01, $cfg_02, $cfg_03, $cfg_04, $cfg_05, $cfg_06, $cfg_07, $cfg_08, $cfg_09, $cfg_10, $cfg_11, $cfg_12, $cfg_email, $cfg_cancel_url, $cfg_return_url, $cfg_ipn_url, $cfg_stats, $cfg_currency, $cfg_intro) = $db->sql_fetchrow($rows);



if ($cfg_stats == 0){
OpenTable();
	// IF STATS PAGE DISABLED
	$cpgtpl->assign_vars(array(
	'STATS_DISABLED'	=> _STATS_DISABLED,
	));
	$cpgtpl->set_filenames(array('body' => 'Donations/stats_disabled.html'));
	$cpgtpl->display('body');
CloseTable();
}

if ($cfg_stats==1 || can_admin($module_name)) {

	$there_result = 'SELECT trans_id FROM '.$prefix.'_donations';
	$there_rows = $db->sql_query($there_result);
	if ($db->sql_numrows($there_rows)>0){



	// TOP 5 ALL-TIME DONORS
OpenTable();
	$sql = "
	SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_visible, d.trans_timestamp, SUM(ROUND(d.trans_net,2)), d.trans_memo
	FROM ".$prefix."_users AS u
	INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid) 
	WHERE d.trans_visible='1'
	GROUP BY d.trans_uid 
	ORDER BY SUM(ROUND(d.trans_net)) DESC LIMIT 0,5";
    $result = $db->sql_query($sql);
	$avatar_path = $MAIN_CFG['avatar']['path'];
	$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

	while(list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_visible, $d_trans_timestamp, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result)){

		if ($u_user_avatar == '') {
			$avatar = 'images/avatars/gallery/blank.gif';
		} else if ($u_user_avatar_type == 1) {
			$avatar = "$avatar_path/$u_user_avatar";
		} else if ($u_user_avatar_type == 2) {
			$avatar = $u_user_avatar;
		} else if ($u_user_avatar_type == 3) {
			$avatar = "$avatar_gallery/$u_user_avatar";
		} else {
			$avatar = 'images/avatars/gallery/blank.gif';
		}

	// TOP 5 DONORS TEMPLATE
	$cpgtpl->assign_block_vars('top5_donors', array(
	'DONATION_AVATAR' 			=> $avatar,
	'DONATION_USERNAME' 		=> $d_trans_uname,
	'DONATION_AMOUNT' 			=> $d_trans_net,
	'DONATION_TIMESTAMP' 		=> $d_trans_timestamp,
	'DONATION_COMMENT' 			=> $d_trans_memo,
	'DONATION_USER_PROFILE'		=> getlink('Your_Account&profile='.$d_trans_uname.''),
	));
	}
	

	// TOP 5 DONATIONS
	$sql = "
	SELECT ROUND(d.trans_net,2) as total, u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_visible, d.trans_timestamp, d.trans_net, d.trans_memo
	FROM ".$prefix."_users AS u
	INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid)
	WHERE d.trans_visible='1'
	ORDER BY ROUND(d.trans_net) DESC LIMIT 5";
    $result = $db->sql_query($sql);
	$avatar_path = $MAIN_CFG['avatar']['path'];
	$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

	while(list($total, $u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_visible, $d_trans_timestamp, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result)){
		if ($u_user_avatar == '') {
			$avatar = 'images/avatars/gallery/blank.gif';
		} else if ($u_user_avatar_type == 1) {
			$avatar = "$avatar_path/$u_user_avatar";
		} else if ($u_user_avatar_type == 2) {
			$avatar = $u_user_avatar;
		} else if ($u_user_avatar_type == 3) {
			$avatar = "$avatar_gallery/$u_user_avatar";
		} else {
			$avatar = 'images/avatars/gallery/blank.gif';
		}


		// TOP 5 DONATIONS TEMPLATE
		$cpgtpl->assign_block_vars('top5_donations', array(
		'DONATION_AVATAR' 			=> $avatar,
		'DONATION_USERNAME' 		=> $d_trans_uname,
		'DONATION_AMOUNT' 			=> $total,
		'DONATION_TIMESTAMP' 		=> $d_trans_timestamp,
		'DONATION_COMMENT' 			=> $d_trans_memo,
		'DONATION_USER_PROFILE'		=> getlink('Your_Account&profile='.$d_trans_uname.''),
		));
	}

	$cpgtpl->set_filenames(array('body' => 'Donations/stats_top_dons.html'));
	$cpgtpl->display('body');

CloseTable();
	echo "<br />";

// DONATION GRID STATS
OpenTable();
	echo "<div class='forumlink'>Donation Stats</div><br />";

	$bold_month = "SELECT MAX(ROUND(trans_net,2)) as max FROM ".$prefix."_donations WHERE trans_visible='1' ORDER BY trans_net DESC LIMIT 0,1";
	$bold_row = $db->sql_query($bold_month);
	list($max) = $db->sql_fetchrow($bold_row);

	$result_total = "SELECT SUM(ROUND(trans_net,2)) as total FROM ".$prefix."_donations WHERE trans_visible='1'";
	$total_row = $db->sql_query($result_total);
	$row_total = $db->sql_fetchrow($total_row);
	$overall_total = $row_total['total'];
	$db->sql_freeresult($total_row);

	$max_month = "SELECT trans_lgstamp, SUM(ROUND(trans_net,2)) AS max_net FROM ".$prefix."_donations WHERE trans_visible='1'
	GROUP BY MONTH(trans_lgstamp), YEAR(trans_lgstamp)
	ORDER BY max_net DESC LIMIT 0,10";
	$max_row = $db->sql_query($max_month);
	list($month, $max) = $db->sql_fetchrow($max_row);
	$best_month = date('F Y',strtotime($month));  

	list($count) = $db->sql_ufetchrow("SELECT COUNT(trans_id) FROM ".$prefix."_donations WHERE trans_visible='1'");
/*
	$cpgtpl->assign_vars(array(
	'MODULE_NAME'				=> $module_name,
	'STATS_BEST_MONTH'			=> $best_month,
	'STATS_MAX'					=> $max,
	'STATS_COUNT'				=> $count,
	'STATS_OVERALL_TOTAL'		=> $overall_total,
	));
*/
	

	echo "<table border='0' width='100%' cellpadding='0' cellspacing='0'><tr>";
	echo "<td align='left'>Best Month: ".$best_month." ($".$max.")</td>";
	echo "<td align='right'>Total: ".$count." Donations ($".$overall_total.")</td>";
	echo "</tr></table><br />";

	echo "<table border='1' width='100%' cellpadding='1' cellspacing='1' style='border-collapse: collapse;'><tr>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Year</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Jan</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Feb</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>March</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>April</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>May</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>June</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>July</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Aug</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Sept</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Oct</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Nov</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Dec</td>";
	echo "<td class='cat' nowrap='nowrap' align='center'>Total</td>";
	echo "</tr>";

// Dragonfly's config_custom global $startdate is formatted as January 1, 1900
// Inception strips all but last 4 characters (website's start year) in the example it would list only "1900".
	$inception = substr($startdate, -4, 4);
	// Now we do a double loop.  I got it right after an hour of trying!
	// This is the grid for Donation Stats.  Loops the Monthly_Stats function per month and per year from startdate to now.
	for($y=0; $inception+$y<=date('Y'); $y++){
	$years = $inception+$y;
	$i='1';
		while($i>='1'&&$i<='12'){
		Monthly_Stats($years, $i++, $max);
		}
	}
	echo "</table>";
	CloseTable();
	echo "<br />";

// THIS MONTHS DONATIONS
	OpenTable();
	$sql = "
	SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_timestamp, d.trans_net, d.trans_memo
	FROM ".$prefix."_users AS u
	INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid)
	WHERE d.trans_timestamp <=('".$now."') AND d.trans_timestamp >=('".$now_year."-".$now_month."-01 00:00:00') AND d.trans_visible='1'
	ORDER BY d.trans_timestamp DESC LIMIT 10";
    $result = $db->sql_query($sql);
	$avatar_path = $MAIN_CFG['avatar']['path'];
	$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

	echo "<div class='forumlink'>This Month's Donations</div><br />";
	echo "<table border='0' width='100%' cellpadding='2' cellspacing='2' style='border-collapse: collapse;'><tr>";
	echo "<td class='cat' nowrap='nowrap' colspan='2'> &nbsp; User &nbsp; </td>";
	echo "<td class='cat' nowrap='nowrap'> &nbsp; Amount &nbsp; </td>";
	echo "<td class='cat' nowrap='nowrap'> &nbsp; Timestamp &nbsp; </td>";
	echo "<td class='cat' width='100%'> &nbsp; Comment &nbsp; </td>";
	echo "</tr>";
	while(list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_timestamp, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result)){
		$money = number_format($d_trans_net,2);
		if ($u_user_avatar == '') {
			$avatar = 'images/avatars/gallery/blank.gif';
		} else if ($u_user_avatar_type == 1) {
			$avatar = "$avatar_path/$u_user_avatar";
		} else if ($u_user_avatar_type == 2) {
			$avatar = $u_user_avatar;
		} else if ($u_user_avatar_type == 3) {
			$avatar = "$avatar_gallery/$u_user_avatar";
		} else {
			$avatar = 'images/avatars/gallery/blank.gif';
		}

		echo "<tr>";
		echo "<td class='forumlink' nowrap='nowrap' style='height:75px;' align='center' valign='middle'><a href='".getlink('Your_Account&profile='.$d_trans_uname.'')."'><img src='".$avatar."' alt='image error' border='0' height='75%' /></a></td>";
		echo "<td class='forumlink' nowrap='nowrap'> &nbsp; <a href='".getlink('Your_Account&profile='.$d_trans_uname.'')."'>".$d_trans_uname."</a> &nbsp; </td>";
		echo "<td class='forumlink' nowrap='nowrap'> &nbsp; ".$money." &nbsp; </td>";
		echo "<td class='forumlink' nowrap='nowrap'> &nbsp; ".$d_trans_timestamp." &nbsp; </td>";
		echo "<td class='forumlink'>".$d_trans_memo." &nbsp; </td>";
		echo "</tr>";
	}
	echo "</table>";
	CloseTable();
	echo "<br />";

// ALL PAST DONATIONS
	OpenTable();
	$sql = "
	SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_timestamp, d.trans_net, d.trans_memo
	FROM ".$prefix."_users AS u
	INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid)
	WHERE d.trans_timestamp <=('".$now_year."-".$now_month."-01 00:00:00') AND d.trans_visible='1'
	ORDER BY d.trans_timestamp DESC";
    $result = $db->sql_query($sql);
	$avatar_path = $MAIN_CFG['avatar']['path'];
	$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

	echo "<div class='forumlink'>Past Donations</div><br />";
	echo "<table border='0' width='100%' cellpadding='2' cellspacing='2' style='border-collapse: collapse;'><tr>";
	echo "<td class='cat' nowrap='nowrap' colspan='2'> &nbsp; User &nbsp; </td>";
	echo "<td class='cat' nowrap='nowrap'> &nbsp; Amount &nbsp; </td>";
	echo "<td class='cat' nowrap='nowrap'> &nbsp; Timestamp &nbsp; </td>";
	echo "<td class='cat' width='100%'> &nbsp; Comment &nbsp; </td>";
	echo "</tr>";
	while(list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_timestamp, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result)){
		if ($u_user_avatar == '') {
			$avatar = 'images/avatars/gallery/blank.gif';
		} else if ($u_user_avatar_type == 1) {
			$avatar = "$avatar_path/$u_user_avatar";
		} else if ($u_user_avatar_type == 2) {
			$avatar = $u_user_avatar;
		} else if ($u_user_avatar_type == 3) {
			$avatar = "$avatar_gallery/$u_user_avatar";
		} else {
			$avatar = 'images/avatars/gallery/blank.gif';
		}

	echo "<tr>";
	echo "<td class='forumlink' nowrap='nowrap' style='height:50px;' align='center' valign='middle'><a href='".getlink('Your_Account&profile='.$d_trans_uname.'')."'><img src='".$avatar."' alt='image error' border='0' height='50%' /></a></td>";
	echo "<td class='forumlink' nowrap='nowrap'> &nbsp; <a href='".getlink('Your_Account&profile='.$d_trans_uname.'')."'>".$d_trans_uname."</a> &nbsp; </td>";
	echo "<td class='forumlink' nowrap='nowrap'> &nbsp; ".$d_trans_net." &nbsp; </td>";
	echo "<td class='forumlink' nowrap='nowrap'> &nbsp; ".$d_trans_timestamp." &nbsp; </td>";
	echo "<td class='forumlink'>".$d_trans_memo." &nbsp; </td>";
	echo "</tr>";
	}
	echo "</table>";
	CloseTable();

	}else{
	OpenTable();
	echo "There are no donations to display.";
	CloseTable();
	}
} 
}



?>