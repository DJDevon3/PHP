<?php
if (!defined('CPG_NUKE')) { exit; }

$mode = isset($_POST['mode']) ? $_POST['mode'] : (isset($_GET['mode']) ? $_GET['mode']:'');

switch($mode) {

	default:
	index();
	break;

	case "Subscriptions":
	Subscriptions();
	break;

	case "Stats":
	Stats();
	break;

	case "FeeCalc":
	FeeCalc();
	break;

	case "FeeCalc_Submit":
		$amount = isset($_POST['amount']) ? Fix_Quotes($_POST['amount']) : '';
		$fee = isset($_POST['fee']) ? Fix_Quotes($_POST['fee']) : '';
		$total = isset($_POST['total']) ? Fix_Quotes($_POST['total']) : '';
	FeeCalc_Submit($amount, $fee, $total);
	break;

	case "Transactions":
	Transactions();
	break;
	
	case "User_Change_Visibility":
		$xtrans_id = isset($_POST['xtrans_id']) ? intval($_POST['xtrans_id']) : '';
		$xtrans_visible = isset($_POST['xtrans_visible']) ? intval($_POST['xtrans_visible']) : '';
		$xtrans_uid = isset($_POST['xtrans_uid']) ? intval($_POST['xtrans_uid']) : '';
	User_Change_Visibility($xtrans_id, $xtrans_visible, $xtrans_uid);
	break;

	case "return_ipn":
	return_ipn();
	break;

	case "SIPN":
	SIPN();
	break;

}

?>