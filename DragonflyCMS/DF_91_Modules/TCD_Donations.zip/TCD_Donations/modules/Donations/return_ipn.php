<?php
if (!defined('CPG_NUKE')) { exit; }
global $db, $prefix, $module_name, $userinfo, $nukeurl, $adminmail, $pagetitle;
$pagetitle .= 'Donations '._BC_DELIM.' IPN';
require('header.php');
$user_id = $userinfo['user_id'];
require_once('modules/'.$module_name.'/menu.php');

// 2 Step Process for getting full domain name - TRIM URL TO DNS (WWW.YOURDOMAIN.TLD)
preg_match('@^(?:http://)?([^/]+)@i',$nukeurl, $matches);
$host = $matches[1];
// STRIP WWW (IPN@YOURDOMAIN.TLD) MIGHT FAIL IF YOU HAVE (.CO.UK) DOUBLE TLD?
preg_match('/[^.]+\.[^.]+$/', $host, $matches);
$domain_name = $matches[0];

// read the post from PayPal system and add 'cmd' to return for verification process
// $req is the RAW data, includes every POST variable Paypal sent in a parsed url format.
$req = 'cmd=_notify-validate';
foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

// post back to PayPal system to validate
$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";

// Get Visitor Details for Error Logging
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (isset($referrer)){
$referrer = ''.$_SERVER['HTTP_REFERER'].'';
} else {
	$referrer = 'none';
}
$lgstamp = date("Y")."-".date("m")."-".date("d")." ".date("H").":".date("i").":".date("s");


// Switch for Sandbox Testing if enabled:
$result = 'SELECT sandbox_enabled FROM '.$prefix.'_donations_sandbox';
$rows = $db->sql_query($result);
list($sandbox_enabled) = $db->sql_fetchrow($rows);
if($sandbox_enabled==1){
$fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
}elseif ($sandbox_enabled==0){
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);
}


// Capture POST variables sent from Paypal.com and turn into local variables.
// Transaction Details
$txn_type = isset($_POST['txn_type']) ? Fix_Quotes($_POST['txn_type']) : '';
$parent_txn_id = isset($_POST['parent_txn_id']) ? Fix_Quotes($_POST['parent_txn_id']) : '';
$txn_id = isset($_POST['txn_id']) ? Fix_Quotes($_POST['txn_id']) : '';
$item_name = isset($_POST['item_name']) ? Fix_Quotes($_POST['item_name']) : '';
$item_number = isset($_POST['item_number']) ? intval($_POST['item_number']) : '1';
$payment_status = isset($_POST['payment_status']) ? Fix_Quotes($_POST['payment_status']) : '';
$payment_currency = isset($_POST['payment_currency']) ? Fix_Quotes($_POST['payment_currency']) : '';
$payment_gross = isset($_POST['payment_gross']) ? Fix_Quotes($_POST['payment_gross']) : '';
$payment_fee = isset($_POST['payment_fee']) ? Fix_Quotes($_POST['payment_fee']) : '';
$mc_gross = isset($_POST['mc_gross']) ? Fix_Quotes($_POST['mc_gross']) : '';
$mc_fee = isset($_POST['mc_fee']) ? Fix_Quotes($_POST['mc_fee']) : '';
$mc_currency = isset($_POST['mc_currency']) ? Fix_Quotes($_POST['mc_currency']) : '';
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : '';
$num_cart_items = isset($_POST['num_cart_items']) ? intval($_POST['num_cart_items']) : '';
$payment_date = isset($_POST['payment_date']) ? Fix_Quotes($_POST['payment_date']) : '';
$payment_type = isset($_POST['payment_type']) ? Fix_Quotes($_POST['payment_type']) : '';
$payment_status = isset($_POST['payment_status']) ? Fix_Quotes($_POST['payment_status']) : '';
$settle_amount = isset($_POST['settle_amount']) ? Fix_Quotes($_POST['settle_amount']) : '';
$option_name1 = isset($_POST['option_name1']) ? Fix_Quotes($_POST['option_name1']) : '';
$option_selection1 = isset($_POST['option_selection1']) ? Fix_Quotes($_POST['option_selection1']) : '';
$option_name2 = isset($_POST['option_name2']) ? Fix_Quotes($_POST['option_name2']) : '';
$option_selection2 = isset($_POST['option_selection2']) ? Fix_Quotes($_POST['option_selection2']) : '';
$exchange_rate = isset($_POST['exchange_rate']) ? Fix_Quotes($_POST['exchange_rate']) : '';
$settle_currency = isset($_POST['settle_currency']) ? Fix_Quotes($_POST['settle_currency']) : '';
$pending_reason = isset($_POST['pending_reason']) ? Fix_Quotes($_POST['pending_reason']) : '';
$reason_code = isset($_POST['reason_code']) ? Fix_Quotes($_POST['reason_code']) : '';
$invoice = isset($_POST['invoice']) ? Fix_Quotes($_POST['invoice']) : '';
$custom = isset($_POST['custom']) ? Fix_Quotes($_POST['custom']) : '';
$transaction_subject = isset($_POST['transaction_subject']) ? Fix_Quotes($_POST['transaction_subject']) : '';
$memo = isset($_POST['memo']) ? Fix_Quotes($_POST['memo']) : '';

// Buyer & Seller Information
$business = isset($_POST['business']) ? Fix_Quotes($_POST['business']) : '';
$receiver_email = isset($_POST['receiver_email']) ? Fix_Quotes($_POST['receiver_email']) : '';
$receiver_id = isset($_POST['receiver_id']) ? Fix_Quotes($_POST['receiver_id']) : '';
$payer_business_name = isset($_POST['payer_business_name']) ? Fix_Quotes($_POST['payer_business_name']) : '';
$payer_email = isset($_POST['payer_email']) ? Fix_Quotes($_POST['payer_email']) : '';
$payer_id = isset($_POST['payer_id']) ? Fix_Quotes($_POST['payer_id']) : '';
$payer_status = isset($_POST['payer_status']) ? Fix_Quotes($_POST['payer_status']) : '';

// Personal Information - We do NOT use this stuff (too easy for admin abuse) but we do want it for debugging.
$address_status = isset($_POST['address_status']) ? Fix_Quotes($_POST['address_status']) : '';
$address_street = isset($_POST['address_street']) ? Fix_Quotes($_POST['address_street']) : '';
$address_city = isset($_POST['address_city']) ? Fix_Quotes($_POST['address_city']) : '';
$address_zip = isset($_POST['address_zip']) ? Fix_Quotes($_POST['address_zip']) : '';
$address_state = isset($_POST['address_state']) ? Fix_Quotes($_POST['address_state']) : '';
$address_country = isset($_POST['address_country']) ? Fix_Quotes($_POST['address_country']) : '';
$residence_country = isset($_POST['residence_country']) ? Fix_Quotes($_POST['residence_country']) : '';
$address_country_code = isset($_POST['address_country_code']) ? Fix_Quotes($_POST['address_country_code']) : '';
$address_name = isset($_POST['address_name']) ? Fix_Quotes($_POST['address_name']) : '';
$first_name = isset($_POST['first_name']) ? Fix_Quotes($_POST['first_name']) : '';
$last_name = isset($_POST['last_name']) ? Fix_Quotes($_POST['last_name']) : '';

// Variables only admins would find useful
$charset = isset($_POST['charset']) ? Fix_Quotes($_POST['charset']) : '';
$notify_version = isset($_POST['notify_version']) ? Fix_Quotes($_POST['notify_version']) : '';
$verify_sign = isset($_POST['verify_sign']) ? Fix_Quotes($_POST['verify_sign']) : '';
$protection_eligibility = isset($_POST['protection_eligibility']) ? Fix_Quotes($_POST['protection_eligibility']) : '';
$test_ipn = isset($_POST['test_ipn']) ? Fix_Quotes($_POST['test_ipn']) : '';

// Subscription Variables
$subscr_id = isset($_POST['subscr_id']) ? Fix_Quotes($_POST['subscr_id']) : '';
$subscr_date = isset($_POST['subscr_date']) ? Fix_Quotes($_POST['subscr_date']) : '';
$subscr_effective = isset($_POST['subscr_effective']) ? Fix_Quotes($_POST['subscr_effective']) : '';
$modify = isset($_POST['modify']) ? Fix_Quotes($_POST['modify']) : '';
$period1 = isset($_POST['p1']) ? Fix_Quotes($_POST['p1']) : '';
$period2 = isset($_POST['period2']) ? Fix_Quotes($_POST['period2']) : '';
$period3 = isset($_POST['period3']) ? Fix_Quotes($_POST['period3']) : '';
$amount1 = isset($_POST['amount1']) ? Fix_Quotes($_POST['amount1']) : '';
$amount2 = isset($_POST['amount2']) ? Fix_Quotes($_POST['amount2']) : '';
$amount3 = isset($_POST['amount3']) ? Fix_Quotes($_POST['amount3']) : '';
$cycle = isset($_POST['t3']) ? Fix_Quotes($_POST['t3']) : '';
$mc_amount1 = isset($_POST['a1']) ? Fix_Quotes($_POST['a1']) : '';
$mc_amount2 = isset($_POST['mc_amount2']) ? Fix_Quotes($_POST['mc_amount2']) : '';
$mc_amount3 = isset($_POST['mc_amount3']) ? Fix_Quotes($_POST['mc_amount3']) : '';
$recurring = isset($_POST['recurring']) ? Fix_Quotes($_POST['recurring']) : '';
$reattempt = isset($_POST['reattempt']) ? Fix_Quotes($_POST['reattempt']) : '';
$retry_at = isset($_POST['retry_at']) ? Fix_Quotes($_POST['retry_at']) : '';
$recur_times = isset($_POST['recur_times']) ? Fix_Quotes($_POST['recur_times']) : '';
$username = isset($_POST['username']) ? Fix_Quotes($_POST['username']) : '';
$password = isset($_POST['password']) ? Fix_Quotes($_POST['password']) : '';

// Auction Variables
$for_auction = isset($_POST['for_auction']) ? Fix_Quotes($_POST['for_auction']) : '';
$auction_closing_date = isset($_POST['auction_closing_date']) ? Fix_Quotes($_POST['auction_closing_date']) : '';
$auction_multi_item = isset($_POST['auction_multi_item']) ? Fix_Quotes($_POST['auction_multi_item']) : '';
$auction_buyer_id = isset($_POST['auction_buyer_id']) ? Fix_Quotes($_POST['auction_buyer_id']) : '';

// Custom Variables for use in Dragonfly Module
$net = number_format(($mc_gross - $mc_fee), 2);
$adwait = isset($_POST['adwait']) ? Fix_Quotes($_POST['adwait']) : '';


function OMG_Errors($err_uid, $err_uname, $err_date, $lgstamp, $ip, $referrer, $user_agent, $item_name, $txn_id, $txn_type, $payment_type, $mc_gross, $mc_fee, $net, $payment_status, $memo, $business, $mc_currency, $payer_id, $payer_email, $notify_version, $subscr_id, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $adwait){
global $db, $prefix, $module_name, $userinfo;

$db->sql_query("INSERT INTO ".$prefix."_donations_errlog SET err_uid='$err_uid', err_uname='$err_uname', err_timestamp='$err_date', err_lgstamp='$lgstamp', err_ip='$ip', err_referrer='$referrer', err_user_agent='$user_agent', err_visible='$item_name', err_txn_id='$txn_id', err_txn_type='$txn_type', err_payment_type='$payment_type', err_gross='$mc_gross', err_fee='$mc_fee', err_net='$net', err_status='$payment_status', err_memo='$memo', err_business_email='$business', err_currency='$mc_currency', err_payer_pp_id='$payer_id',err_payer_pp_email='$payer_email', err_notify_version='$notify_version', err_subscr_id='$subscr_id', err_effective='$subscr_effective', err_period1='$period1', err_period2='$period2', err_period3='$period3', err_amount1='$amount1', err_amount2='$amount2', err_amount3='$amount3', err_mc_amount1='$mc_amount1', err_mc_amount2='$mc_amount2', err_mc_amount3='$mc_amount3', err_recurring='$recurring', err_reattempt='$reattempt', err_retry_at='$retry_at', err_recur_times='$recur_times', err_username='$username', err_password='$password', err_adwait='1'");
}

// ************************************************** BEGIN DISPLAY IPN  ************************************************** //

function Display_IPN($test_ipn, $item_name, $item_number, $business, $payment_status, $net, $mc_gross, $payment_currency, $txn_id, $receiver_id, $quantity, $num_cart_items, $payment_date, $lgstamp, $payment_type, $payment_gross, $payment_fee, $settle_amount, $memo, $payer_email, $txn_type, $payer_status, $option_name1, $option_selection1, $option_name2, $option_selection2, $for_auction, $invoice, $custom, $notify_version, $verify_sign, $payer_business_name, $payer_id, $mc_currency, $mc_fee, $settle_currency, $parent_txn_id, $pending_reason, $reason_code, $receiver_email, $subscr_id, $subscr_date, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $xuser_id, $xusername){
global $db, $prefix, $module_name;
// Switch for Sandbox within the IPN Output:
$result = 'SELECT sandbox_enabled FROM '.$prefix.'_donations_sandbox';
$rows = $db->sql_query($result);
list($sandbox_enabled) = $db->sql_fetchrow($rows);

	// DISPLAY TRANSACTION DETAILS IF SANDBOX ENABLED AND ADMIN
	if($sandbox_enabled==1){
		if (can_admin($module_name)) {
			if ($payment_status=='Completed'){
				echo "<div style='font-size:18px;color:#339900;'>Transaction Status: ".$payment_status."</div>";
			} else {
				echo "<div style='font-size:18px;color:#FF0000;'>Transaction Status: ".$payment_status."</div>";
			}
			echo "<table border='0' width='100%' cellpadding='4' cellspacing='1'>";
			if (!empty($test_ipn)){echo "<tr><td nowrap='nowrap'>test_ipn: </td><td>".$test_ipn."</td></tr>";}
			if (!empty($txn_type)){echo "<tr><td nowrap='nowrap'>txn_type: </td><td>".$txn_type."</td></tr>";}
			if (!empty($txn_id)){echo "<tr><td nowrap='nowrap'>txn_id: </td><td>".$txn_id."</td></tr>";}
			if (!empty($item_name)){echo "<tr><td nowrap='nowrap'>item_name: </td><td>".$item_name." (visibility)</td></tr>";}
			if (!empty($item_number)){echo "<tr><td nowrap='nowrap'>item_number: </td><td>".$item_number." (user id)</td></tr>";}
			if (!empty($business)){echo "<tr><td nowrap='nowrap'>business: </td><td>".$business."</td></tr>";}
			if (!empty($receiver_email)){echo "<tr><td nowrap='nowrap'>receiver_email: </td><td>".$receiver_email."</td></tr>";}
			if (!empty($receiver_id)){echo "<tr><td nowrap='nowrap'>receiver_id: </td><td>".$receiver_id."</td></tr>";}
			if (!empty($payer_business_name)){echo "<tr><td nowrap='nowrap'>payer_business_name: </td><td>".$payer_business_name."</td></tr>";}
			if (!empty($payer_email)){echo "<tr><td nowrap='nowrap'>payer_email: </td><td>".$payer_email."</td></tr>";}
			if (!empty($payer_id)){echo "<tr><td nowrap='nowrap'>payer_id: </td><td>".$payer_id."</td></tr>";}
			if (!empty($payer_status)){echo "<tr><td nowrap='nowrap'>payer_status: </td><td>".$payer_status."</td></tr>";}

			if (!empty($quantity)){echo "<tr><td nowrap='nowrap'>quantity: </td><td>".$quantity."</td></tr>";}
			if (!empty($num_cart_items)){echo "<tr><td nowrap='nowrap'>num_cart_items: </td><td>".$num_cart_items."</td></tr>";}
			if (!empty($payment_date)){echo "<tr><td nowrap='nowrap'>payment_date: </td><td>".$payment_date."</td></tr>";}
			if (!empty($lgstamp)){echo "<tr><td nowrap='nowrap'>lgstamp: </td><td>".$lgstamp."</td></tr>";}

			if (!empty($payment_type)){echo "<tr><td nowrap='nowrap'>payment_type: </td><td>".$payment_type."</td></tr>";}
			if (!empty($mc_currency)){echo "<tr><td nowrap='nowrap'>mc_currency: </td><td>".$mc_currency."</td></tr>";}
			if (!empty($mc_gross)){echo "<tr><td nowrap='nowrap'>mc_gross: </td><td>".$mc_gross."</td></tr>";}
			if (!empty($mc_fee)){echo "<tr><td nowrap='nowrap'>mc_fee: </td><td>".$mc_fee."</td></tr>";}
			if (!empty($net)){echo "<tr><td nowrap='nowrap'>net: </td><td>".$net."</td></tr>";}
			if (!empty($settle_amount)){echo "<tr><td nowrap='nowrap'>settle_amount: </td><td>".$settle_amount."</td></tr>";}
			if (!empty($memo)){echo "<tr><td nowrap='nowrap'>memo: </td><td>".$memo."</td></tr>";}
			if (!empty($option_name1)){echo "<tr><td nowrap='nowrap'>option_name1: </td><td>".$option_name1."</td></tr>";}
			if (!empty($option_selection1)){echo "<tr><td nowrap='nowrap'>option_selection1: </td><td>".$option_selection1."</td></tr>";}
			if (!empty($option_name2)){echo "<tr><td nowrap='nowrap'>option_name2: </td><td>".$option_name2."</td></tr>";}
			if (!empty($option_selection2)){echo "<tr><td nowrap='nowrap'>option_selection2: </td><td>".$option_selection2."</td></tr>";}
			if (!empty($for_auction)){echo "<tr><td nowrap='nowrap'>for_auction: </td><td>".$for_auction."</td></tr>";}
			if (!empty($invoice)){echo "<tr><td nowrap='nowrap'>invoice: </td><td>".$invoice."</td></tr>";}
			if (!empty($custom)){echo "<tr><td nowrap='nowrap'>custom: </td><td>".$custom."</td></tr>";}
			if (!empty($notify_version)){echo "<tr><td nowrap='nowrap'>notify_version: </td><td>".$notify_version."</td></tr>";}
			if (!empty($verify_sign)){echo "<tr><td nowrap='nowrap'>verify_sign: </td><td>".$verify_sign."</td></tr>";}
			if (!empty($exchange_rate)){echo "<tr><td nowrap='nowrap'>exchange_rate: </td><td>".$exchange_rate."</td></tr>";}
			if (!empty($settle_currency)){echo "<tr><td nowrap='nowrap'>settle_currency: </td><td>".$settle_currency."</td></tr>";}
			if (!empty($parent_txn_id)){echo "<tr><td nowrap='nowrap'>parent_txn_id: </td><td>".$parent_txn_id."</td></tr>";}
			if (!empty($pending_reason)){echo "<tr><td nowrap='nowrap'>pending_reason: </td><td>".$pending_reason."</td></tr>";}
			if (!empty($reason_code)){echo "<tr><td nowrap='nowrap'>reason_code: </td><td>".$reason_code."</td></tr>";}

			if (!empty($subscr_id)){echo "<tr><td nowrap='nowrap' colspan='2' align='center'> - SUBSCRIPTION DETAILS - </td></tr>";}
			if (!empty($subscr_id)){echo "<tr><td nowrap='nowrap'>subscr_id: </td><td>".$subscr_id."</td></tr>";}
			if (!empty($subscr_date)){echo "<tr><td nowrap='nowrap'>subscr_date: </td><td>".$subscr_date."</td></tr>";}
			if (!empty($subscr_effective)){echo "<tr><td nowrap='nowrap'>subscr_effective: </td><td>".$subscr_effective."</td></tr>";}
			if (!empty($modify)){echo "<tr><td nowrap='nowrap'>modify: </td><td>".$modify."</td></tr>";}
			if (!empty($cycle)){echo "<tr><td nowrap='nowrap'>period1: </td><td>".$cycle."</td></tr>";}
			if (!empty($period1)){echo "<tr><td nowrap='nowrap'>period1: </td><td>".$period1."</td></tr>";}
			if (!empty($period2)){echo "<tr><td nowrap='nowrap'>period2: </td><td>".$period2."</td></tr>";}
			if (!empty($period3)){echo "<tr><td nowrap='nowrap'>period3: </td><td>".$period3."</td></tr>";}
			if (!empty($amount1)){echo "<tr><td nowrap='nowrap'>amount1: </td><td>".$amount1."</td></tr>";}
			if (!empty($amount2)){echo "<tr><td nowrap='nowrap'>amount2: </td><td>".$amount2."</td></tr>";}
			if (!empty($amount3)){echo "<tr><td nowrap='nowrap'>amount3: </td><td>".$amount3."</td></tr>";}
			if (!empty($mc_amount1)){echo "<tr><td nowrap='nowrap'>mc_amount1: </td><td>".$mc_amount1."</td></tr>";}
			if (!empty($mc_amount2)){echo "<tr><td nowrap='nowrap'>mc_amount2: </td><td>".$mc_amount2."</td></tr>";}
			if (!empty($mc_amount3)){echo "<tr><td nowrap='nowrap'>mc_amount3: </td><td>".$mc_amount3."</td></tr>";}
			if (!empty($recurring)){echo "<tr><td nowrap='nowrap'>recurring: </td><td>".$recurring."</td></tr>";}
			if (!empty($reattempt)){echo "<tr><td nowrap='nowrap'>reattempt: </td><td>".$reattempt."</td></tr>";}
			if (!empty($retry_at)){echo "<tr><td nowrap='nowrap'>retry_at: </td><td>".$retry_at."</td></tr>";}
			if (!empty($recur_times)){echo "<tr><td nowrap='nowrap'>recur_times: </td><td>".$recur_times."</td></tr>";}
			if (!empty($username)){echo "<tr><td nowrap='nowrap'>username: </td><td>".$username."</td></tr>";}
			if (!empty($password)){echo "<tr><td nowrap='nowrap'>password: </td><td>".$password."</td></tr>";}
			//if (!empty($xuser_id)){echo "<tr><td nowrap='nowrap'>xuser_id: </td><td>".$xuser_id."</td></tr>";}
			//if (!empty($xusername)){echo "<tr><td nowrap='nowrap'>xusername: </td><td>".$xusername."</td></tr>";}
			echo "</table>";
			// DISPLAY TRANSACTION DETAILS IF SANDBOX ENABLED AND NOT ADMIN
		} else {
			echo "<div style='font-size:18px;color:#FF0000;'>Sandbox: Enabled<br /><br />";
			echo "This module is currently unavailable because some genius has Sandbox enabled.<br /><br />";
			echo '<a href="'.getlink('Donations').'">Return to Donations Index</a><br /><br />';
			echo "</div>";
		}

	// TRANSACTION DETAILS IF MODULE IS LIVE - USERS SEE THIS FOR GOOD TRANSACTIONS
	} else if ($sandbox_enabled==0){
		$result = 'SELECT user_id, username FROM '.$prefix.'_users WHERE user_id='.$item_number.'';
		$rows = $db->sql_query($result);
		list($xuser_id, $xusername) = $db->sql_fetchrow($rows);

		if ($payment_status=='Completed'){
			echo "<div style='font-size:18px;color:#339900;'>Transaction Status: ".$payment_status."</div>";
			if ($memo=='Test IPN'){
				echo "This is what a real transaction would look like if you weren't using IPN Test.<br />";
				echo "For even better debugging please set Sandbox to enabled.";
			}
		} else {
			echo "<div style='font-size:18px;color:#FF6600;'>Transaction Status: ".$payment_status."</div>";
			if ($memo=='Test IPN'){
				echo "If you see this it means the impossible has happened.  Local IPN Test should never fail. WTF?";
			}
		}
		echo "<br /><br />";
		echo "<table border='0' cellpadding='4' cellspacing='1'>";
		echo "<tr><td nowrap='nowrap'>Transaction ID: </td><td>".$txn_id."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Username: </td><td>".$xusername."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Date/Time: </td><td>".$payment_date."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Visible: </td><td>";
		if ($item_name==1){
		echo "Yes";
		}else{
		echo "No";
		}
		echo "</td></tr>";
		echo "<tr><td nowrap='nowrap'>Donation From: </td><td>".$payer_email."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Gross: </td><td>".$mc_gross."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Paypal Fee: </td><td>".$mc_fee."</td></tr>";
		if (!empty($net)){echo "<tr><td nowrap='nowrap'>Net: </td><td>".$net."</td></tr>";}
		echo "<tr><td nowrap='nowrap'>Currency: </td><td>".$mc_currency."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Your Paypal Account ID: </td><td>".$payer_id."</td></tr>";
		echo "<tr><td nowrap='nowrap'>Your Paypal Account Status: </td><td>".$payer_status."</td></tr>";
		if (!empty($pending_reason)){echo "<tr><td nowrap='nowrap'>Pending Reason: </td><td>".$pending_reason."</td></tr>";}
		if (!empty($reason_code)){echo "<tr><td nowrap='nowrap'>Reason Code: </td><td>".$reason_code."</td></tr>";}
		if (!empty($notify_version)){echo "<tr><td nowrap='nowrap'>Paypal Version: </td><td>".$notify_version."</td></tr>";}
		echo "<tr><td nowrap='nowrap'>Transaction Comment: </td><td>".$memo."</td></tr>";
		echo "</table>";
		echo "<br /><div style='font-size:14px;color:#000000;'>We have received your donation and added it to your account profile.</div><br />";
	}
}

// **************************************************  END DISPLAY IPN  ************************************************** //



$result = 'SELECT cfg_flat_file FROM '.$prefix.'_donations_cfg';
$rows = $db->sql_query($result);
list($cfg_flat_file) = $db->sql_fetchrow($rows);

// CONNECTION ERROR TO PAYPAL SERVER. (!fp = no handshake)
if (!$fp){

	// MAIL ERROR LOG TO ADMIN
	$mail_Body = $errstr; //error string from fsockopen
	$emailtext = "SERVER CONNECTION ERROR \n";
	$emailtext .= "\n ----------------------------------------------------------- \n";
	// Email's admin that a connection to PayPal's server (live or sandbox) could not be established
	mail(''.$adminmail.'','IPN - CONNECT ERROR', "IP: ".$ip."\n"."Timestamp: ".$lgstamp."\n"."Referrer: ".$referrer."\n". "User Agent: ".$user_agent."\n\n".$emailtext."\n\n".$mail_Body,'From: IPN@'.$domain_name.'');

	if ($cfg_flat_file==1){
	$fh = fopen("modules/Donations/IPN-LOG-ERROR.txt", 'a'); //open file and create if does not exist
	fwrite($fh, "\n ----------------------------------------------------------- \n"); // Plain-text line break
	fwrite($fh, "HTTP ERROR \n"); // Log Entry Type
	fwrite($fh, $errstr); //write data
	fclose($fh); //close file
	}

} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
$res = fgets ($fp, 1024);

// *************************************************  VERIFIED TRANSACTIONS *************************************************  //

	if (strcmp ($res, "VERIFIED") == 0) {
		// Use for production site.  1=1 is for local testing
		// if(strcmp ($res, "VERIFIED") == 0 || 1 == 1) {
		$trans_lgstamp = date("Y")."-".date("m")."-".date("d")." ".date("H").":".date("i").":".date("s");

		// MAIL SUCCESSFUL TRANSACTION DETAILS TO ADMIN
		$email_break = "\n ----------------------------------------------------------- \n";
		$mail_Body = $req;
		$emailtext = "TRANSACTION: VERIFIED SUCCESSFUL \n";
		$emailtext .= "This is everything PayPal sent to your IPN including all unknown variables.\n";
		$emailtext .= $email_break;
		foreach ($_POST as $key => $value){
			$emailtext .= $key . " = " .$value ."\n\n";
		}
		mail(''.$adminmail.'','IPN - VERIFIED',"IP: ".$ip."\n"."Timestamp: ".$lgstamp."\n"."Referrer: ".$referrer."\n". "User Agent: ".$user_agent."\n".$email_break."\n".$emailtext."\n".$email_break."\n".$mail_Body, 'From: IPN@'.$domain_name.'');

		if ($cfg_flat_file==1){
		//write to file
		$fh = fopen("modules/Donations/IPN-LOG-VERIFIED.txt", 'a'); //open file and create if does not exist
		fwrite($fh, "\n ----------------------------------------------------------- \n");//Just for spacing in log file
		fwrite($fh, "Verified \n"); // Log Entry Type
		fwrite($fh, $req);//write data
		fclose($fh);//close file
		}

		//CHECK DB FOR DUPLICATE ID
		if( $txn_id ) {
		$sql = "SELECT trans_txn_id FROM ".$prefix."_donations WHERE trans_txn_id='$txn_id'";
		$Recordset1 = $db->sql_query($sql);
		$row_Recordset1 = $db->sql_fetchrow($Recordset1); 
		$duplicate_id = $db->sql_numrows($Recordset1);
		$db->sql_freeresult($Recordset1);
		}

		// VERIFIED + NO DUPLICATE ID = GOOD TRANSACTION
		if ($duplicate_id == 0){

			// AS LONG AS THE TRANSACTION IS VALID WE'LL SWITCH BETWEEN txn_type LISTENERS.

			// CART TRANSACTIONS (we don't accept the cart type - just in case we'll do error logging on it)
			if ($txn_type == "_cart"){
				$result = 'SELECT user_id, username FROM '.$prefix.'_users WHERE user_id='.$item_number.'';
				$rows = $db->sql_query($result);
				list($xuser_id, $xusername) = $db->sql_fetchrow($rows);

				$db->sql_query("INSERT INTO ".$prefix."_donations SET trans_uid='$item_number', trans_uname='$xusername', trans_timestamp='".strftime('%Y-%m-%d %H:%M:%S',strtotime($payment_date))."', trans_lgstamp='$trans_lgstamp', trans_visible='$item_name', trans_txn_id='$txn_id', trans_txn_type='$txn_type', trans_payment_type='$payment_type', trans_gross='$mc_gross', trans_fee='$mc_fee', trans_net='$net', trans_status='$payment_status', trans_memo='$memo', trans_business_email='$business', trans_currency='$mc_currency', trans_payer_pp_id='$payer_id', trans_payer_pp_email='$payer_email', trans_notify_version='$notify_version'");

				OpenTable();
				echo "<table border='0' cellpadding='0' cellspacing='0'><tr><td>";
				echo "<td nowrap='nowrap'><img src='images/button_pass.png' alt=SUCCESS border='0'></td>";
				echo "<td width='100%' class='forumlink' align='center' valign='middle'>";
				echo "Your Purchase is Verified!<br /><br />";
				echo '<a href="'.getlink('Donations').'">Return to Storefront Index</a></td>';
				echo "<td nowrap='nowrap'><img src='images/button_pass.png' alt=SUCCESS border='0'></td>";
				echo "</tr></table>";
				CloseTable();
				echo "<br /><br />";

			// DONATION TRANSACTIONS - Donations should be verified by your IPN as web_accept (_donations is legacy)
			}else if ( $txn_type == "_donations"  ||  $txn_type == "web_accept"  ) {

				$result = 'SELECT user_id, username FROM '.$prefix.'_users WHERE user_id='.$item_number.'';
				$rows = $db->sql_query($result);
				list($xuser_id, $xusername) = $db->sql_fetchrow($rows);

				if ($test_ipn==0){
					$db->sql_query("INSERT INTO ".$prefix."_donations SET trans_uid='$item_number', trans_uname='$xusername', trans_timestamp='".strftime('%Y-%m-%d %H:%M:%S',strtotime($payment_date))."', trans_lgstamp='$trans_lgstamp', trans_visible='$item_name', trans_txn_id='$txn_id', trans_txn_type='$txn_type', trans_payment_type='$payment_type', trans_gross='$mc_gross', trans_fee='$mc_fee', trans_net='$net', trans_status='$payment_status', trans_memo='$memo', trans_business_email='$business', trans_currency='$mc_currency', trans_payer_pp_id='$payer_id', trans_payer_pp_email='$payer_email', trans_notify_version='$notify_version'");
				}

				OpenTable();
				echo "<table border='0' cellpadding='0' cellspacing='0'><tr><td>";
				echo "<td nowrap='nowrap'><img src='images/button_pass.png' alt=SUCCESS border='0'></td>";
				echo "<td width='100%' class='forumlink' align='center' valign='middle'>";
				echo "Your Donation is Verified!<br /><br />";
				if ($test_ipn==1){
					echo "(but it won't be added to the database because Sandbox is enabled)<br /><br />";
				}
				echo '<a href="'.getlink('Donations').'">Return to Donations Index</a></td>';
				echo "<td nowrap='nowrap'><img src='images/button_pass.png' alt=SUCCESS border='0'></td>";
				echo "</tr></table>";
				CloseTable();
				echo "<br /><br />";

				OpenTable();
				Display_IPN($test_ipn, $item_name, $item_number, $business, $payment_status, $net, $mc_gross, $payment_currency, $txn_id, $receiver_id, $quantity, $num_cart_items, $payment_date, $lgstamp, $payment_type, $payment_gross, $payment_fee, $settle_amount, $memo, $payer_email, $txn_type, $payer_status, $option_name1, $option_selection1, $option_name2, $option_selection2, $for_auction, $invoice, $custom, $notify_version, $verify_sign, $payer_business_name, $payer_id, $mc_currency, $mc_fee, $settle_currency, $parent_txn_id, $pending_reason, $reason_code, $receiver_email, $subscr_id, $subscr_date, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $xuser_id, $xusername);
				CloseTable();

			// SUBSCRIPTION TRANSACTIONS
			}else if (
				$txn_type == "_s-xclick" ||
				$txn_type == "_xclick-subscriptions" ||
				$txn_type == "subscr_signup" ||  
				$txn_type == "subscr_cancel" || 
				$txn_type == "subscr_modify" || 
				$txn_type == "subscr_payment" || 
				$txn_type == "recurring_payment_profile_created" || 
				$txn_type == "recurring_payment"
			){

				$subscr_date = date("Y")."/".date("m")."/".date("d");

				echo "Subscription Type";
				$db->sql_query("INSERT INTO ".$prefix."_donations_subscriptions SET subscr_uid='$item_number', subscr_uname='$xusername', subscr_id='$subscr_id', subscr_txn_type='$txn_type', subscr_date='$subscr_date', subscr_effective='$subscr_effective', period1='$period1', period2='$period2', period3='$period3', amount1='$amount1', amount2='$amount2', amount3='$amount3', mc_amount1='$mc_amount1', mc_amount2='$mc_amount2', mc_amount3='$mc_amount3', recurring='$recurring', reattempt='$reattempt', retry_at='$retry_at', recur_times='$recur_times', username='$username', password='$password', txn_id='$txn_id', payer_email='$payer_email', subscr_date='$subscr_date'");
			}

		// PREVENT DUPLICATE LIVE TRANSACTIONS
		}else{
			OpenTable();
			echo "<div class='forumlink' align='center'>";
			echo "We have already received this Transaction ID!<br /><br />";
			echo "It's possible you or Paypal double posted the results to us.<br />";
			echo "In any case we've received your donation. :)<br /><br />";
			echo '<a href="'.getlink('Donations').'">Return to Donations Index</a><br /><br />';
			echo "</div>";
			CloseTable();
			echo "<br /><br />";
		}

// *************************************************  INVALID TRANSACTIONS *************************************************  //

	}else if (strcmp ($res, "INVALID") == 0) {

		// MAIL ERROR LOG TO ADMIN
		$mail_Body = $req;
		$emailtext = "TRANSACTION: INVALID \n";
		$emailtext .= "This is everything PayPal sent to your IPN including all unknown variables.\n";
		$emailtext .= "\n ----------------------------------------------------------- \n";
		foreach ($_POST as $key => $value){
		$emailtext .= $key . " = " .$value ."\n\n";
		}
		// Emails admin on transaction failure.  Usually from Sandbox but can happen with live failures or unwanted page viewing.
		// $emailtext is the nicely formatted variables in the email
		// $mail_Body is the raw parsed url.  Might as well mail that along in case something fishy happens in transit.
		mail(''.$adminmail.'','IPN - INVALID', "IP: ".$ip."\n"."Timestamp: ".$lgstamp."\n"."Referrer: ".$referrer."\n". "User Agent: ".$user_agent."\n\n".$emailtext."\n\n".$mail_Body,'From: IPN@'.$domain_name.'');

		if ($cfg_flat_file==1){
			//write to file
			$fh = fopen("modules/Donations/IPN-LOG-INVALID.txt", 'a');//open file and create if does not exist
			fwrite($fh, "\n ----------------------------------------------------------- \n");//Just for spacing in log file
			fwrite($fh, "INVALID \n"); // Log Entry Type
			fwrite($fh, $lgstamp."\n");//timestamp
			fwrite($fh, $req."\n");//write data
			fclose($fh);//close file
		}


		if($sandbox_enabled==0){

			// LIVE ENVIRONMENT INVALID!!!
			if (can_admin($module_name)) {
				OpenTable();
				Display_IPN($test_ipn, $item_name, $item_number, $business, $payment_status, $net, $mc_gross, $payment_currency, $txn_id, $receiver_id, $quantity, $num_cart_items, $payment_date, $lgstamp, $payment_type, $payment_gross, $payment_fee, $settle_amount, $memo, $payer_email, $txn_type, $payer_status, $option_name1, $option_selection1, $option_name2, $option_selection2, $for_auction, $invoice, $custom, $notify_version, $verify_sign, $payer_business_name, $payer_id, $mc_currency, $mc_fee, $settle_currency, $parent_txn_id, $pending_reason, $reason_code, $receiver_email, $subscr_id, $subscr_date, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $xuser_id, $xusername);
				CloseTable();
			} else {
				// PRESENT THE USER WITH AN INVALID TRANSACTION ERROR MESSAGE AND LOG EVERYTHING YOU CAN
				OpenTable();
				echo "<div class='forumlink' align='center'>";
				echo "Invalid Transaction!<br /><br />";
				echo "The error has been logged and admin notified.<br />";
				echo "</div>";
				CloseTable();
				echo "<br />";

				$err_uid = $userinfo['user_id'];
				$err_uname = $userinfo['username'];
				$err_date = date("Y")."-".date("m")."-".date("d")." ".date("H").":".date("i").":".date("s");

				// ERROR LOG ALL KNOWN PAYPAL VARIABLES USED FOR DONATIONS AND SUBSCRIPTIONS
				OMG_Errors($err_uid, $err_uname, $err_date, $lgstamp, $ip, $referrer, $user_agent, $item_name, $txn_id, $txn_type, $payment_type, $mc_gross, $mc_fee, $net, $payment_status, $memo, $business, $mc_currency, $payer_id, $payer_email, $notify_version, $subscr_id, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $adwait);
			}


		// INVALID IPN + SANDBOX ENABLED = DEVELOPER PLAYGROUND
		} else if ($sandbox_enabled==1){
			$err_uid = $userinfo['user_id'];
			$err_uname = $userinfo['username'];
			$err_date = date("Y")."-".date("m")."-".date("d")." ".date("H").":".date("i").":".date("s");

			if (can_admin($module_name)) {

				$result = 'SELECT user_id, username FROM '.$prefix.'_users WHERE user_id='.$item_number.'';
				$rows = $db->sql_query($result);
				list($xuser_id, $xusername) = $db->sql_fetchrow($rows);

				OpenTable();
				echo "<div class='forumlink' align='center'>";
				echo "<br /><font style='color:#990000'><b> ~ Sandbox Enabled ~ <br /> All Transactions = NULL</b></font><br /><br />";
				echo "</div>";
				CloseTable();
				echo "<br />";

				OMG_Errors($err_uid, $err_uname, $err_date, $lgstamp, $ip, $referrer, $user_agent, $item_name, $txn_id, $txn_type, $payment_type, $mc_gross, $mc_fee, $net, $payment_status, $memo, $business, $mc_currency, $payer_id, $payer_email, $notify_version, $subscr_id, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $adwait);

				OpenTable();
				Display_IPN($test_ipn, $item_name, $item_number, $business, $payment_status, $net, $mc_gross, $payment_currency, $txn_id, $receiver_id, $quantity, $num_cart_items, $payment_date, $lgstamp, $payment_type, $payment_gross, $payment_fee, $settle_amount, $memo, $payer_email, $txn_type, $payer_status, $option_name1, $option_selection1, $option_name2, $option_selection2, $for_auction, $invoice, $custom, $notify_version, $verify_sign, $payer_business_name, $payer_id, $mc_currency, $mc_fee, $settle_currency, $parent_txn_id, $pending_reason, $reason_code, $receiver_email, $subscr_id, $subscr_date, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $xuser_id, $xusername);
				CloseTable();

				// INVALID IPN + SANDBOX ENABLED + NOT ADMIN = PUBLIC/REGS HITTING IPN PAGE WHEN NOT SUPPOSED TO
				// BEST TO LOG THE SHIT OUT OF THIS TOO IN CASE OF BOTS FILLING UP ERROR PAGES WITH ILLEGAL HITS
				// ROBOTS.TXT RULE?
			} else {

				OMG_Errors($err_uid, $err_uname, $err_date, $lgstamp, $ip, $referrer, $user_agent, $item_name, $txn_id, $txn_type, $payment_type, $mc_gross, $mc_fee, $net, $payment_status, $memo, $business, $mc_currency, $payer_id, $payer_email, $notify_version, $subscr_id, $subscr_effective, $period1, $period2, $period3, $amount1, $amount2, $amount3, $mc_amount1, $mc_amount2, $mc_amount3, $recurring, $reattempt, $retry_at, $recur_times, $username, $password, $adwait);

				OpenTable();
				echo "<div class='forumlink' align='center'>";
				echo "<b>Sandbox: Enabled</b><br />";
				echo "This page is temporarily offline for testing or maintenance.<br />";
				echo "It should be back soon.<br />";
				echo "</div>";
				CloseTable();
			}
		}
	}
}
fclose ($fp);
}
?>