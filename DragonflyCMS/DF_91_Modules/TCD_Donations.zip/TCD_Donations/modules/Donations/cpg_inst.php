<?php

/************************************************************************/
/* Donations for DragonflyCMS by Devil							    */
/* ============================================                         */
/* Copyright (c) 2009 LegendaryGamers.net                               */
/************************************************************************/

if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class Donations {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function Donations() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'Donations';
		$this->description = 'Donation Management';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('donations', 'donations_subscriptions', 'donations_cfg', 'donations_sandbox', 'donations_style', 'donations_errlog');
	}


	function install() {
	global $installer;

		$installer->add_query('CREATE', 'donations', "
		trans_id						int(3)			NOT NULL auto_increment,
		trans_uid						int(4)			NOT NULL,
		trans_uname						varchar(50)		NOT NULL,
		trans_timestamp					datetime		NOT NULL default '0000-00-00 00:00:00',
		trans_lgstamp					datetime		NOT NULL default '0000-00-00 00:00:00',
		trans_visible					tinyint(1)		NOT NULL default '1',
		trans_txn_id					varchar(20)		NOT NULL,
		trans_txn_type					varchar(15)		NOT NULL,
		trans_payment_type				varchar(15)		NOT NULL,
		trans_gross						varchar(6)		NOT NULL,
		trans_fee						varchar(6)		NOT NULL default '0.00',
		trans_net						varchar(6)		NOT NULL,
		trans_status					varchar(50)		NOT NULL,
		trans_memo						text			NOT NULL,
		trans_business_email			varchar(50)		NOT NULL,
		trans_currency					varchar(3)		NOT NULL default 'USD',
		trans_payer_pp_id				varchar(20)		NOT NULL,
		trans_payer_pp_email			varchar(50)		NOT NULL,
		trans_notify_version			varchar(10)		NOT NULL,
		PRIMARY KEY (trans_id)", 'donations');

		$installer->add_query('CREATE', 'donations_subscriptions', "
		sub_subscr_sid					int(3)			NOT NULL auto_increment,
		sub_subscr_uid					int(4)			NOT NULL,
		sub_subscr_uname				varchar(20)		NOT NULL,
		sub_subscr_id					varchar(20)		NOT NULL,
		sub_subscr_txn_type				varchar(20)		NOT NULL,
		sub_subscr_date					datetime		NOT NULL default '0000-00-00 00:00:00',
		sub_subscr_effective			varchar(50)		NOT NULL,
		sub_period1						varchar(50)		NOT NULL,
		sub_period2						varchar(50)		NOT NULL,
		sub_period3						varchar(50)		NOT NULL,
		sub_amount1						varchar(5)		NOT NULL,
		sub_amount2						varchar(5)		NOT NULL,
		sub_amount3						varchar(5)		NOT NULL,
		sub_mc_amount1					varchar(5)		NOT NULL,
		sub_mc_amount2					varchar(5)		NOT NULL,
		sub_mc_amount3					varchar(5)		NOT NULL,
		sub_recurring					varchar(255)	NOT NULL,
		sub_reattempt					varchar(255)	NOT NULL,
		sub_retry_at					varchar(255)	NOT NULL,
		sub_recur_times					varchar(255)	NOT NULL,
		sub_username					varchar(255)	NOT NULL,
		sub_password					varchar(255)	NOT NULL,
		sub_payer_email					varchar(255)	NOT NULL,
		sub_visible						tinyint(1)		NOT NULL default '1',
		sub_active						tinyint(1)		NOT NULL default '1',
		PRIMARY KEY (sub_subscr_sid)", 'donations_subscriptions');

		$installer->add_query('CREATE', 'donations_cfg', "
		cfg_01							varchar(6)		NOT NULL,
		cfg_02							varchar(6)		NOT NULL,
		cfg_03							varchar(6)		NOT NULL,
		cfg_04							varchar(6)		NOT NULL,
		cfg_05							varchar(6)		NOT NULL,
		cfg_06							varchar(6)		NOT NULL,
		cfg_07							varchar(6)		NOT NULL,
		cfg_08							varchar(6)		NOT NULL,
		cfg_09							varchar(6)		NOT NULL,
		cfg_10							varchar(6)		NOT NULL,
		cfg_11							varchar(6)		NOT NULL,
		cfg_12							varchar(6)		NOT NULL,
		cfg_email						varchar(50)		NOT NULL,
		cfg_cancel_url					varchar(100)	NOT NULL,
		cfg_return_url					varchar(100)	NOT NULL,
		cfg_ipn_url						varchar(100)	NOT NULL,
		cfg_stats						int(1)			NOT NULL,
		cfg_flat_file					int(1)			NOT NULL,
		cfg_currency					varchar(5)		NOT NULL default 'USD',
		cfg_intro						text			NOT NULL,
		cfg_sub_intro					text			NOT NULL", 'donations_cfg');

		$installer->add_query('CREATE', 'donations_sandbox', "
		sandbox_enabled					tinyint(1)		NOT NULL default '0',
		sandbox_user					varchar(100)	NOT NULL,
		sandbox_buyer					varchar(100)	NOT NULL,
		sandbox_seller					varchar(100)	NOT NULL,
		sandbox_api_account				varchar(100)	NOT NULL,
		sandbox_api_username			varchar(100)	NOT NULL,
		sandbox_api_pass				varchar(100)	NOT NULL,
		sandbox_api_signature			varchar(100)	NOT NULL", 'donations_sandbox');

		$installer->add_query('CREATE', 'donations_style', "
		style_name						varchar(50)		NOT NULL,
		style_image_url					varchar(255)	NOT NULL,
		style_cpp_header_image			varchar(255)	NOT NULL,
		style_cpp_headerback_color		varchar(6)		NOT NULL,
		style_cpp_headerborder_color	varchar(6)		NOT NULL,
		style_cpp_payflow_color			varchar(6)		NOT NULL,
		style_cs						tinyint(1)		NOT NULL default '0',
		style_lc						varchar(50)		NOT NULL,
		style_no_note					tinyint(1)		NOT NULL", 'donations_style');

		$installer->add_query('CREATE', 'donations_errlog', "
		err_id							int(3)			NOT NULL auto_increment,
		err_uid							int(4)			NOT NULL,
		err_uname						varchar(50)		NOT NULL,
		err_timestamp					datetime		NOT NULL default '0000-00-00 00:00:00',
		err_lgstamp						datetime		NOT NULL default '0000-00-00 00:00:00',
		err_ip							varchar(50)		NOT NULL,
		err_referrer					varchar(100)	NOT NULL,
		err_user_agent					varchar(255)	NOT NULL,
		err_visible						varchar(1)		NOT NULL,
		err_txn_id						varchar(20)		NOT NULL,
		err_txn_type					varchar(15)		NOT NULL,
		err_payment_type				varchar(15)		NOT NULL,
		err_gross						varchar(6)		NOT NULL,
		err_fee							varchar(6)		NOT NULL,
		err_net							varchar(6)		NOT NULL,
		err_status						varchar(50)		NOT NULL,
		err_memo						text			NOT NULL,
		err_business_email				varchar(50)		NOT NULL,
		err_currency					varchar(3)		NOT NULL,
		err_payer_pp_id					varchar(20)		NOT NULL,
		err_payer_pp_email				varchar(50)		NOT NULL,
		err_notify_version				varchar(10)		NOT NULL,
		err_subscr_id					varchar(20)		NOT NULL,
		err_effective					varchar(50)		NOT NULL,
		err_period1						varchar(50)		NOT NULL,
		err_period2						varchar(20)		NOT NULL,
		err_period3						varchar(50)		NOT NULL,
		err_amount1						varchar(4)		NOT NULL,
		err_amount2						varchar(50)		NOT NULL,
		err_amount3						varchar(50)		NOT NULL,
		err_mc_amount1					varchar(4)		NOT NULL,
		err_mc_amount2					varchar(3)		NOT NULL,
		err_mc_amount3					varchar(255)	NOT NULL,
		err_recurring					varchar(255)	NOT NULL,
		err_reattempt					varchar(255)	NOT NULL,
		err_retry_at					varchar(255)	NOT NULL,
		err_recur_times					varchar(255)	NOT NULL,
		err_username					varchar(255)	NOT NULL,
		err_password					varchar(255)	NOT NULL,
		err_adwait						tinyint(1)		NOT NULL default '1',
		PRIMARY KEY (err_id)", 'donations_errlog');

		$installer->add_query('INSERT', 'donations_cfg', "'180','180','180','180','180','180','180','180','180','180','180','180','devon@treasurecoastdesigns.com','index.php?name=Donations','/index.php?name=Donations','index.php?name=Donations&file=return_ipn', '1', '1', 'USD','For those of you who can, we ask that you make a contribution.  <br />Every little bit counts and is appreciated.<br /><br />For your donation to register in your account: <br /><b>You must click on Return to Merchant after your order is complete!</b>','If your subscription fails twice in a row for any reason it will be cancelled automatically.  If you wish to cancel your subscription we ask that you do it here instead of on PayPal\'s site so that we can process the cancellation properly for our own records.  No need to make our Donation module fail unnecessarily.'");

		$installer->add_query('INSERT', 'donations_sandbox', "'1', 'devon@treasurecoastdesigns.com', 'buyer_1262553076_per@treasurecoastdesigns.com', 'seller_1262277295_biz@treasurecoastdesigns.com', 'seller_1262277295_biz@treasurecoastdesigns.com', 'seller_1262277295_biz_api1.treasurecoastdesigns.com', '1262277300', 'AQU0e5vuZCvSg-XJploSa.sGUDlpAOHB9CxADK2eOa4TfjAxCcjVFlF6'");

		$installer->add_query('INSERT', 'donations', "'1', '306', 'nuccia', '2007-09-07 14:55:04', '2007-09-07 14:55:14', '1', '6T107117LB207652A', 'web_accept', 'instant', '300.00', '0.00', '300.00', 'Completed', 'Thank you for all your hard work', 'devon@treasurecoastdesigns.com', 'USD', 'unknown', 'devon@treasurecoastdesigns.com', '1.0' ");
		
	return true;
    }


// module uninstaller
	function uninstall() {
	global $installer;
    foreach ($this->dbtables AS $table) {
  		$installer->add_query('DROP', $table);
    }
		return true;
	}
}
?>
