<?php
if (!defined('CPG_NUKE')) { exit; }

function User_Change_Visibility($xtrans_id, $xtrans_visible, $xtrans_uid) {
	global $prefix, $db;

    $db->sql_query("UPDATE ".$prefix."_donations SET trans_visible='".$xtrans_visible."' WHERE trans_id='".$xtrans_id."' AND trans_uid='".$xtrans_uid."'");
	url_redirect(getlink('Donations&amp;mode=Transactions'));  
}

function FeeCalc_Submit($amount, $fee, $total) {
url_redirect(getlink('Donations&amp;mode=FeeCalc&amp;amount='.$amount.'')); 
}

?>