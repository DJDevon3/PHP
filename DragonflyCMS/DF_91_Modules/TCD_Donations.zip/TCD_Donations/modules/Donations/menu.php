<?php
if (!defined('CPG_NUKE')) { exit; }

$menu_result = 'SELECT cfg_stats FROM '.$prefix.'_donations_cfg';
$rows = $db->sql_query($menu_result);
list($cfg_stats) = $db->sql_fetchrow($rows);

OpenTable();
echo '<table width="100%"><tr>';
echo '<td align="center"><font class="option"><a href="'.getlink().'">Donations</a></font></td>';
echo '<td align="center"><font class="option"><a href="'.getlink('&amp;mode=Subscriptions').'">Subscriptions</a></font></td>';
echo '<td align="center"><font class="option"><a href="'.getlink('&amp;mode=FeeCalc').'">Fee Calculator</a></font></td>';

if ($cfg_stats==1 || can_admin($module_name)){
echo '<td align="center"><font class="option"><a href="'.getlink('&amp;mode=Stats').'">Stats</a></font></td>';
}

if ($user_id>1){
echo '<td align="center"><font class="option"><a href="'.getlink('&amp;mode=Transactions').'">Your Transactions</a></font></td>';
}

if (can_admin($module_name)) {
echo '<td align="center"><font class="option"><a href="'.adminlink($module_name).'">Admin Index</a></font></td>';
}

echo '</tr>';
echo '</table>';
CloseTable();



?>