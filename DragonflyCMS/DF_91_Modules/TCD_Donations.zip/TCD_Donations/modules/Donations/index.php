<?php 
if (!defined('CPG_NUKE')) { exit; }
$pagetitle = 'Donations';
get_lang('donations');

function index() {
	global $userinfo, $prefix, $db, $module_name, $MAIN_CFG, $nukeurl, $pagetitle;
	require('header.php');
	$user_id = $userinfo['user_id'];
	require_once('modules/'.$module_name.'/menu.php');
	$now_month = date("m");
	$now_year = date("Y");
	

OpenTable();
	$result = 'SELECT cfg_01, cfg_02, cfg_03, cfg_04, cfg_05, cfg_06, cfg_07, cfg_08, cfg_09, cfg_10, cfg_11, cfg_12, cfg_email, cfg_cancel_url, cfg_return_url, cfg_ipn_url, cfg_currency, cfg_intro FROM '.$prefix.'_donations_cfg';
	$rows = $db->sql_query($result);
	list($cfg_01, $cfg_02, $cfg_03, $cfg_04, $cfg_05, $cfg_06, $cfg_07, $cfg_08, $cfg_09, $cfg_10, $cfg_11, $cfg_12, $cfg_email, $cfg_cancel_url, $cfg_return_url, $cfg_ipn_url, $cfg_currency, $cfg_intro) = $db->sql_fetchrow($rows);

	$sand_res = 'SELECT sandbox_enabled, sandbox_user, sandbox_buyer, sandbox_seller FROM '.$prefix.'_donations_sandbox';
	$sand_rows = $db->sql_query($sand_res);
	list($sandbox_enabled, $sandbox_user, $sandbox_buyer, $sandbox_seller) = $db->sql_fetchrow($sand_rows);

	if($sandbox_enabled==1){
		$sandbox_enabled_message = "~ Sandbox Enabled ~ <br /> All Transactions = NULL";
		$donation_start_form = "<form action='https://www.sandbox.paypal.com/cgi-bin/webscr' name='Donation' method='post'>";
		$sandbox_business = "<input type='hidden' name='business' value='".$sandbox_seller."'>";
	} else{
		$donation_start_form = "<form action='https://www.paypal.com/cgi-bin/webscr' name='Donation' method='post'>";
		$sandbox_business = "<input type='hidden' name='business' value='".$cfg_email."'>";
	}


// DONATION FORM
$cpgtpl->assign_vars(array(
'MODULE_NAME'				=> $module_name,
'CFG_INTRO'					=> $cfg_intro,
'CFG_CURRENCY'				=> $cfg_currency,
'CFG_IPN_URL'				=> $cfg_ipn_url,
'DONATION_FORM_START'		=> $donation_start_form,
'SANDBOX_BUSINESS'			=> $sandbox_business,
'D_USER_ID'					=> $user_id,
'NUKEURL'					=> $nukeurl,
'SANDBOX_ENABLED_MESSAGE'	=> $sandbox_enabled_message,
));

	

// THIS MONTHS DONATIONS
$sql = "
SELECT u.user_id, u.username, u.user_avatar, u.user_avatar_type, d.trans_id, d.trans_uid, d.trans_uname, d.trans_timestamp, d.trans_visible, d.trans_net, d.trans_memo
FROM ".$prefix."_users AS u
INNER JOIN ".$prefix."_donations AS d ON (u.user_id=d.trans_uid)
WHERE d.trans_timestamp <=('".$now."') AND d.trans_timestamp >=('".$now_year."-".$now_month."-01 00:00:00') AND d.trans_visible='1' 
ORDER BY d.trans_timestamp DESC LIMIT 10";
$result = $db->sql_query($sql);
$avatar_path = $MAIN_CFG['avatar']['path'];
$avatar_gallery = $MAIN_CFG['avatar']['gallery_path'];

while(list($u_user_id, $u_username, $u_user_avatar, $u_user_avatar_type, $d_trans_id, $d_trans_uid, $d_trans_uname, $d_trans_timestamp, $d_trans_visible, $d_trans_net, $d_trans_memo) = $db->sql_fetchrow($result)){
	$money = number_format($d_trans_net,2);
	if ($u_user_avatar == '') {
		$avatar = 'images/avatars/gallery/blank.gif';
	} else if ($u_user_avatar_type == 1) {
		$avatar = "$avatar_path/$u_user_avatar";
	} else if ($u_user_avatar_type == 2) {
		$avatar = $u_user_avatar;
	} else if ($u_user_avatar_type == 3) {
		$avatar = "$avatar_gallery/$u_user_avatar";
	} else {
		$avatar = 'images/avatars/gallery/blank.gif';
	}

	# CATEGORY TEMPLATE
	$cpgtpl->assign_block_vars('month_donations', array(
	'DONATION_AVATAR' 			=> $avatar,
	'DONATION_USERNAME' 		=> $d_trans_uname,
	'DONATION_AMOUNT' 			=> $money,
	'DONATION_TIMESTAMP' 		=> $d_trans_timestamp,
	'DONATION_COMMENT' 			=> $d_trans_memo,
	'DONATION_USER_PROFILE'		=> getlink('Your_Account&profile='.$d_trans_uname.''),
	));

	}

$cpgtpl->set_filenames(array('body' => 'Donations/index.html'));
$cpgtpl->display('body');

CloseTable();

}
include_once ('modules/Donations/functions.php');
include_once ('modules/Donations/transactions.php');
include_once ('modules/Donations/subscriptions.php');
include_once ('modules/Donations/feecalc.php');
include_once ('modules/Donations/stats.php');
include_once ('modules/Donations/cases.php');

?>