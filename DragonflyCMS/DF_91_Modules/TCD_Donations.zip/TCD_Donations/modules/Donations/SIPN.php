<?php
if (!defined('CPG_NUKE')) { exit; }
$pagetitle = 'Donations';
global $db, $prefix, $module_name, $userinfo;
require('header.php');

//To Make live uncomment line below with comment of live then comment the line above it
//Email address to send emails:
$email="devon@treasurecoastdesigns.com";
//add 'cmd' as required to get VERIFIED response
$req = 'cmd=_notify-validate';
//put post into NVP format
foreach ($_POST as $key => $value) 
{
 $value = urlencode(stripslashes($value));
 $req .= "&$key=$value";
}
// setup headers for request to paypal
$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
//Open socket
$fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);//Test
//$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);//Live
 
if (!$fp)// failed to connect to url
{
 //write to file
 $fh = fopen("modules/Donations/SIPN_Sandbox_Log.txt", 'a');//open file and create if does not exist
 fwrite($fh, "\r\n/////////////////////////////////////////\r\n HTTP ERROR \r\n");//Just for spacing in log file
 fwrite($fh, $errstr);//write data
 fclose($fh);//close file
 
 //email
 $mail_From = "From: IPN@tester.com";
 $mail_To = $email;
 $mail_Subject = "HTTP ERROR";
 $mail_Body = $errstr;//error string from fsockopen
 mail($mail_To, $mail_Subject, $mail_Body, $mail_From);
} 
else//successful connect to url
{
 fputs ($fp, $header . $req);//send request
 while (!feof($fp)) //while not end of file
 {
  $res = fgets ($fp, 1024);//get response
  if (strcmp ($res, "VERIFIED") == 0) 
  {
   //write to file
   $fh = fopen("modules/Donations/SIPN_Sandbox_Log.txt", 'a');//open file and create if does not exist
   fwrite($fh, "\r\n/////////////////////////////////////////\r\n Verified \r\n");//Just for spacing in log file
   fwrite($fh, $req);//write data
   fclose($fh);//close file
 
   //email
   $mail_From = "From: IPN@tester.com";
   $mail_To = $email;
   $mail_Subject = "VERIFIED IPN";
   $mail_Body = $req;
   mail($mail_To, $mail_Subject, $mail_Body, $mail_From);
  }
  else if (strcmp ($res, "INVALID") == 0) 
  {
   //write to file
   $fh = fopen("modules/Donations/SIPN_Sandbox_Log.txt", 'a');//open file and create if does not exist
   fwrite($fh, "\r\n/////////////////////////////////////////\r\n Invalid \r\n");//Just for spacing in log file
   fwrite($fh, $req);//write data
   fclose($fh);//close file
 
   //email
   $mail_From = "From: IPN@tester.com";
   $mail_To = $email;
   $mail_Subject = "INVALID IPN";
   $mail_Body = $req;
   mail($mail_To, $mail_Subject, $mail_Body, $mail_From);
  }
 }
 fclose ($fp);//close file pointer
}
?>
