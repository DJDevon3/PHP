<?php 
if (!defined('CPG_NUKE')) { exit; }


function Transactions(){
global $userinfo, $prefix, $db, $module_name, $userinfo, $pagetitle;
$pagetitle .= ' '._BC_DELIM.' Transactions';
require('header.php');
$user_id = $userinfo['user_id'];
$username = $userinfo['username'];
require_once('modules/'.$module_name.'/menu.php');

	// SUBSCRIPTIONS
	if ($user_id==1){
		OpenTable();
		echo "<table border='0' width='100%' cellpadding='2' cellspacing='2'><tr><td>";
		echo "Guests do not have permission to view transaction history.<br />Please Login or Register to setup a transaction history.";
		echo "</td></tr></table>";
		CloseTable();
	} else {

		$result = $db->sql_query("SELECT sub_subscr_sid, sub_subscr_uid, sub_subscr_id, sub_subscr_date, sub_active, sub_period1, sub_period2, sub_period3, sub_amount1, sub_amount2, sub_amount3, sub_mc_amount1, sub_mc_amount2, sub_mc_amount3, sub_recurring, sub_reattempt, sub_retry_at, sub_recur_times, sub_payer_email FROM ".$prefix."_donations_subscriptions WHERE sub_subscr_uid='".$user_id."' ORDER BY sub_subscr_date DESC");
		$numresult = $db->sql_numrows($result);
		if ($numresult) {
			OpenTable();
			// If 1 use the word donation, if more use the word donations.
			if ($numresult==1){
				$sub_or_subs=true;
			} else {
				$sub_or_subs=false;
			}

			while (list($sub_subscr_sid, $sub_subscr_uid, $sub_subscr_id, $sub_subscr_date, $sub_active, $sub_period1, $sub_period2, $sub_period3, $sub_amount1, $sub_amount2, $sub_amount3, $sub_mc_amount1, $sub_mc_amount2, $sub_mc_amount3, $sub_recurring, $sub_reattempt, $sub_retry_at, $sub_recur_times, $sub_payer_email) = $db->sql_fetchrow($result)) {

				if ($sub_active==1) {
					$sub_visible=true;
				} else {
					$sub_visible=false;
				}
		
				$cpgtpl->assign_block_vars('subscriptions', array(
				'SUB_SID' 				=> $sub_subscr_sid,
				'SUB_UID' 				=> $sub_subscr_uid,
				'SUB_ID' 				=> $sub_subscr_id,
				'SUB_DATE' 				=> $sub_subscr_date,
				'SUB_PERIOD1' 			=> $sub_period1,
				'SUB_PERIOD2' 			=> $sub_period2,
				'SUB_PERIOD3' 			=> $sub_period3,
				'SUB_AMOUNT1' 			=> $sub_amount1,
				'SUB_AMOUNT2' 			=> $sub_amount2,
				'SUB_AMOUNT3' 			=> $sub_amount3,
				'SUB_MC_AMOUNT1' 		=> $sub_mc_amount1,
				'SUB_MC_AMOUNT2' 		=> $sub_mc_amount2,
				'SUB_MC_AMOUNT3' 		=> $sub_mc_amount3,
				'SUB_RECURRING' 		=> $sub_recurring,
				'SUB_REATTEMPT' 		=> $sub_reattempt,
				'SUB_RETRY_AT' 			=> $sub_retry_at,
				'SUB_RECUR_TIMES' 		=> $sub_recur_times,
				'SUB_PAYER' 			=> $sub_payer_email,
				'SUB_VISIBLE' 			=> $sub_visible,
				'SUB_URL'				=> getlink('Donations&amp;mode=Transactions'),
				));
			}

			$result2 = $db->sql_query("SELECT round(sum(sub_amount3),2) as total FROM ".$prefix."_donations_subscriptions WHERE sub_subscr_uid='".$user_id."'");
			list($sub_amount3) = $db->sql_fetchrow($result2);

			$cpgtpl->assign_vars(array(
			'MODULE_NAME'				=> $module_name,
			'DONATION_S'				=> $sub_or_subs,
			'NUM_SUBSCRIPTIONS'			=> $numresult,
			'NUM_SUB_TOTAL'				=> $total,
			));

			$cpgtpl->set_filenames(array('body' => 'Donations/transactions_subs.html'));
			$cpgtpl->display('body');

			CloseTable();
		} else {
			OpenTable();
			echo "You do not have any subscriptions.";
			CloseTable();
		}
	}

	// DONATIONS
	if ($user_id > 1){

		$result = $db->sql_query("SELECT trans_id, trans_uid, trans_lgstamp, trans_visible, trans_net, trans_memo, trans_currency FROM ".$prefix."_donations WHERE trans_uid='".$user_id."' ORDER BY trans_lgstamp DESC");
		$numresult = $db->sql_numrows($result);
		if ($numresult) {
			OpenTable();
			if ($numresult==1){
				$don_or_dons=true;
			} else {
				$don_or_dons=false;
			}

			while (list($trans_id, $trans_uid, $trans_lgstamp, $trans_visible, $trans_net, $trans_memo, $trans_currency) = $db->sql_fetchrow($result)) {

				if ($trans_visible==1) {
					$visible=true;
				} else {
					$visible=false;
				}
		
				$cpgtpl->assign_block_vars('transactions', array(
				'TRANS_NET' 			=> $trans_net,
				'TRANS_CURRENCY' 		=> $trans_currency,
				'TRANS_TIMESTAMP' 		=> $trans_lgstamp,
				'TRANS_COMMENT' 		=> $trans_memo,
				'TRANS_ID' 				=> $trans_id,
				'TRANS_USER_ID' 		=> $trans_uid,
				'TRANS_VISIBLE' 		=> $visible,
				'TRANS_URL'				=> getlink('Donations&amp;mode=Transactions'),
				));
			}

			$result2 = $db->sql_query("SELECT round(sum(trans_gross),2) as total FROM ".$prefix."_donations where trans_uid='".$user_id."'");
			list($total) = $db->sql_fetchrow($result2);

			$cpgtpl->assign_vars(array(
			'MODULE_NAME'				=> $module_name,
			'DONATION_S'				=> $don_or_dons,
			'NUM_DONATIONS'				=> $numresult,
			'NUM_USER_TOTAL'			=> $total,
			));

			$cpgtpl->set_filenames(array('body' => 'Donations/transactions.html'));
			$cpgtpl->display('body');

			CloseTable();
		} else {
			OpenTable();
			echo "You do not have any donations.";
			CloseTable();
		}
	}


}


?>