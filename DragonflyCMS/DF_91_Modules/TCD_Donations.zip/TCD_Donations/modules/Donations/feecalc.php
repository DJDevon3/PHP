<?php 
if (!defined('CPG_NUKE')) { exit; }


function FeeCalc() {
	global $module_name, $userinfo, $pagetitle;
	$pagetitle .= ' '._BC_DELIM.' Fee Calculator';
	require('header.php');
	$user_id = $userinfo['user_id'];
	$username = $userinfo['username'];
	require_once('modules/'.$module_name.'/menu.php');
	$amount = isset($_GET['amount']) ? Fix_Quotes($_GET['amount']) : '';
	$fee = isset($_POST['fee']) ? Fix_Quotes($_POST['fee']) : '';
	$total = isset($_POST['total']) ? Fix_Quotes($_POST['total']) : '';
	if(!empty($amount)){
		$percentage_fee = number_format($amount * .02988, '2', '.', ',');
		$total_fee = $percentage_fee + 0.30;
		$amount_left = $amount - $total_fee;
		$total2 = round($amount + $total_fee,2);
		//echo "percentage_fee: ".$percentage_fee."<br />";
		//echo "total_fee: ".$total_fee."<br />";
	} else {
		$total2='';
		$fee_amount='';
	}

OpenTable();

// CALCULATOR
$cpgtpl->assign_vars(array(
'MODULE_NAME'			=> $module_name,
'CALC_AMOUNT'			=> $amount,
'CALC_FEE'				=> $total_fee,
'CALC_TOTAL'			=> $amount_left,
'CALC_TOTAL2'			=> $total2,
'FEECALC_GETLINK'		=> getlink('Donations&amp;mode=FeeCalc'),
));

$cpgtpl->set_filenames(array('body' => 'Donations/fee_calculator.html'));
$cpgtpl->display('body');

CloseTable();
echo "<br />";

}


?>