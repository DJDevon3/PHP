<?php

/***********************************************************************
  Comment Plug-in for DragonFly Modules
  =====================================
  Copyright (c) 2006 by Mark Roper  http://www.markroper.co.uk

  This program is free software. You can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License.

  Usage:-
  
  1. Drop this file in your module's folder.
  
  2. Call it in a program like this:-

        $cmmtlink = '&file=whatever&op=whatever';
        $cmmtkey  = $id;
        require('modules/'.$module_name.'/comment.php');

     Note:-

        $cmmtlink = this variable holds whatever you'd put in getlink()
                    to call the program in your module within which this
                    code is used, only you know what that is ;)
                    
        $cmmtkey  = the ID number of the record in your module that
                    these comments are to be linked to.
    
  ***********************************************************************/

if (!defined('CPG_NUKE')) { exit; }

global $prefix, $user_prefix, $db, $module_name, $userinfo;

// define the name of the table in which to store comments.
// yours WILL be different from this!
define('CMMT_TABLE', $prefix.'_paypal_user_reviews');

// determines whether the person running this program
// has admin access to the module and so can edit / delete comments.
define('CMMT_ADMIN', can_admin($module_name));

// you'll probably want to put these language defines
// in your module's language file.
/*define('CMMT_COMMENTS', 'Comments');
define('CMMT_ADD', 'Add');
define('CMMT_EDIT', 'Edit');
define('CMMT_DELETE', 'Delete');
define('CMMT_RESET', 'Reset');
define('CMMT_UPDATE', 'Update');
define('CMMT_ADDCOMMENT', 'Add Comment');
define('CMMT_EDITCOMMENT', 'Edit Comment');
define('CMMT_DELETECOMMENT', 'Delete Comment');*/

// create the comment table if it doesn't exist.
// you'll probably want to put this in your module's cpg_inst.php
/*$sql = '
  CREATE TABLE IF NOT EXISTS '.CMMT_TABLE." (
    cmmtid   INT(10) NOT NULL auto_increment,
    cmmtkey  INT(10) NOT NULL default '0',
    cmmtuser INT(10) NOT NULL default '0',
    cmmttext TEXT    NOT NULL default '',
    cmmtdate INT(10) NOT NULL default '0',
    PRIMARY KEY (cmmtid),
    KEY (cmmtkey, cmmtid)
  )";
$res =$db->sql_query($sql);*/

require_once('includes/nbbcode.php');

$cmmtop = (isset($_GET['cmmtop']) && !empty($_GET['cmmtop'])) ? Fix_Quotes($_GET['cmmtop']) : ( (isset($_POST['cmmtop']) && !empty($_POST['cmmtop'])) ? Fix_Quotes($_POST['cmmtop']) : '' ) ;

if ($cmmtop=='')
{
  OpenTable();

  $sql = "
    SELECT c.*, u.username
    FROM ".$prefix."_paypal_user_reviews AS c
    JOIN ".$user_prefix."_users AS u ON (u.user_id=c.cmmtuser)
    WHERE c.cmmtkey=$pp_pid";
  $res = $db->sql_query($sql);
	if($db->sql_numrows($res))
	{
		echo '
      <b>'.CMMT_COMMENTS.'</b><br /><br />
			<table class="forumline" width="100%" border="0" cellspacing="1" cellpadding="4">
			';
		while ( $comment = $db->sql_fetchrow($res) )
		{
			echo '
				<tr>
					<td class="row1" valign="top">'.$comment['username'].' - '.formatDateTime($comment['cmmtdate'],_DATESTRING).'</td>
					<td class="row1" align="right" valign="top">
				';
			if (CMMT_ADMIN)
      {
				echo '
          [ <a href="'.getlink("&amp;do=pd&amp;pp_pid='.$pp_pid.'&cmmtop=edit&cmmtid=".$comment['cmmtid']).'">'.CMMT_EDIT.'</a> ] &nbsp;
          [ <a href="'.getlink("&amp;do=pd&amp;pp_pid='.$pp_pid.'&cmmtop=delete&cmmtid=".$comment['cmmtid']).'">'.CMMT_DELETE.'</a> ]
          ';
			}
      else
      {
				echo ' &nbsp; ';
			}
			echo '</td></tr><tr><td class="row2" align="left" valign="top" colspan="2">'.set_smilies(decode_bbcode($comment['cmmttext'], 1)).'</td></tr>';
		}
		echo '</table><br /><br />';
	}
  $db->sql_freeresult($res);

  if ( is_user() )
	{
		echo '
			<center>
      <form method="post" action="'.getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.'').'" name="addComment">
			<input type="hidden" name="cmmtop" value="save" />
			<b>'.CMMT_ADDCOMMENT.'</b> [ '.$userinfo['username'].' ]
			<br /><br />
      <table>
      <tr><td colspan="2">'.bbcode_table('cmmttext', 'addComment', 0).'</td></tr>
      <tr><td><textarea cols="40" rows="8" name="cmmttext" id="cmmttext"></textarea></td><td>'.smilies_table('inline', 'cmmttext', 'addComment').'</td></tr>
      </table>
      <br /><br />
			<input type="submit" name="_submit" value="'.CMMT_ADD.'" /> &nbsp; <input type="reset" name="_reset" value="'.CMMT_RESET.'" />
			</form>	
			</center>
			';
  }

  CloseTable();
}
	
elseif ($cmmtop=='save')
{
  $ctx = Fix_Quotes($_POST['cmmttext']);
  $sql = "INSERT INTO ".$prefix."_paypal_user_reviews SET cmmtkey=$pp_pid, cmmtuser=".is_user().", cmmttext='$ctx', cmmtdate=".gmtime();
 	$res = $db->sql_query($sql);
	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
}

elseif ($cmmtop=='edit')
{
	if (CMMT_ADMIN)
	{
   	$cmt = intval($_GET['cmmtid']);
    $sql = 'SELECT cmmttext FROM '.$prefix.'_paypal_user_reviews WHERE cmmtid='.$cmt;
  	$res = $db->sql_query($sql);
  	if($db->sql_numrows($res)==1)
  	{
			list($cmmttext) = $db->sql_fetchrow($res);
      $db->sql_freeresult($res);
      OpenTable();
			echo '
        <center>
				<form method="post" action="'.getlink($cmmttlink).'" name="editComment">
				<input type="hidden" name="cmmtop" value="update" />
				<input type="hidden" name="cmmtid" value="'.$cmt.'" />
				<b>'.CMMT_EDITCOMMENT.'</b>
				<br /><br />
        <table>
        <tr><td colspan="2">'.bbcode_table('cmmttext', 'editComment', 0).'</td></tr>
        <tr><td><textarea cols="40" rows="8" name="cmmttext" id="cmmttext">'.$cmmttext.'</textarea></td><td>'.smilies_table('inline', 'cmmttext', 'editComment').'</td></tr>
        </table>
				<br /><br />
				<input type="submit" value="'.CMMT_UPDATE.'" /> &nbsp; '._GOBACK.'
				</form>	
				</center>
				';
			CloseTable();
    }
  	else
  	{
      $db->sql_freeresult($res);
    	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
  	}
	}
	else
	{
  	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
	}
}

elseif ($cmmtop=='update')
{
 	$cmt = intval($_POST['cmmtid']);
  $ctx = Fix_Quotes($_POST['ctext']);
	$sql = "UPDATE ".$prefix."_paypal_user_reviews SET cmmttext='$ctx' WHERE cmmtid=$cmt";
	$res = $db->sql_query($sql);
	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
}

elseif ($cmmtop=='delete')
{
 	if (CMMT_ADMIN)
 	{
   	$cmt = intval($_GET['cmmtid']);
    $sql = 'SELECT cmmttext FROM '.$prefix.'_paypal_user_reviews WHERE cmmtid='.$cmt;
   	$res = $db->sql_query($sql);
   	if($db->sql_numrows($res)==1)
   	{
 			list($cmmttext) = $db->sql_fetchrow($res);
      $db->sql_freeresult($res);
      OpenTable();
 			echo '
 			  <center>
 				<form method="post" action="'.getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.'').'" name="deleteComment">
 				<input type="hidden" name="cmmtop" value="confirm" />
 				<input type="hidden" name="cmmtid" value="'.$cmt.'" />
 				<b>'.CMMT_DELETECOMMENT.'</b>
 				<br /><br />
        '.set_smilies(decode_bbcode($cmmttext, 1)).'
 				<br /><br />
 				<input type="submit" value="'.CMMT_DELETE.'" /> &nbsp; '._GOBACK.'
 				</form>	
 				</center>
 				';
 			CloseTable();
    }
   	else
   	{
      $db->sql_freeresult($res);
    	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
   	}
 	}
 	else
 	{
  	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
 	}
}

elseif ($cmmtop=='confirm')
{
 	if (CMMT_ADMIN)
  {
   	$cmt = intval($_POST['cmmtid']);
		$db->sql_query('DELETE FROM '.$prefix.'_paypal_user_reviews WHERE cmmtid='.$cmt);
  }
	url_redirect(getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''));
}

?>
