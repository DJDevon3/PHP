<?php
/*********************************************
  Paypal_Store for DragonflyCMS
  ********************************************
	Helping to create a better internet for all.
	DJDevon3
	TreasureCoastDesigns.com
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$module_name = basename(dirname(__FILE__));
require_once(CORE_PATH.'nbbcode.php');



require_once(BASEDIR.'/modules/'.$module_name.'/cache.inc');
pp_cache_load_cat_list_all();

# functions start
function getparent($parentid, $title) {
	global $prefix, $db;
        list($cid, $ptitle, $pparentid) = $db->sql_ufetchrow('SELECT pp_cid, pp_title, parentid FROM '.$prefix.'_paypal_categories WHERE pp_cid='.$parentid,SQL_BOTH);
        if ($ptitle != '') {
           $title = ($title != '') ? $ptitle.'/'.$title : $ptitle;
        }
	# if ($pparentid!=0) { $title = getparent($pparentid, $ptitle); }
	if ($pparentid!=0) { $title = getparent($pparentid, $title); }
	return $title;
}

function getparentlink($parentid,$title) {
	global $prefix, $db;
	$result = $db->sql_query("select pp_cid, pp_title, parentid from ".$prefix."_paypal_categories where pp_cid=$parentid",false,__FILE__,__LINE__);
	list($cid, $ptitle, $pparentid) = $db->sql_fetchrow($result);
	if ($ptitle!="") $title = '<a href="'.getlink("&amp;do=cat&amp;pp_cid=$cid").'">'.$ptitle.'</a> '._BC_DELIM.' '.$title;
	if ($pparentid>0) $title = getparentlink($pparentid, $title);
	return $title;
}

function pp_get_current_cat_info($category_id) {
	global $categories_list_all;
	if (!empty($category_id)) {
		$viewing_cat = array();
		# loop through the parent [0] and then subs [1]
		foreach($categories_list_all as $base_cat_id => $categories) {	
			# loop through the categories
			foreach($categories as $cat_id => $category) {
				if ($cat_id == $category_id) {
					# this is the category we're looking for
					# we'll check if it's set from where it was called
					$viewing_cat[$category_id] = $category;
				}
			}
		}
		return $viewing_cat;
	} else {
		cpg_error('There was no category id set - cannot load category (pp_get_current_cat_info)', _ERROR);
	}
}

function pp_build_subcat_list($category_id) {
	global $categories_list_all;
	$viewing_cat = pp_get_current_cat_info($category_id);
	$subcategories = array();
	# set the top level category
	$subcategories[$viewing_cat[$category_id]['pp_cid']] = $viewing_cat[$category_id]['pp_title'];	
	# check to see if the category has subcategories
	if(isset($viewing_cat[$category_id]['subcategories_all'])) {
		# loop through the subcategories
		foreach($viewing_cat[$category_id]['subcategories_all'] as $subcat_id) {
			# pad the category with 3 spaces for each level
			# assign the subcategory to the subcategories array
			$subcategories[$categories_list_all[1][$subcat_id]['pp_cid']] = str_repeat('&nbsp;&nbsp;&nbsp;', ($categories_list_all[1][$subcat_id]['indent']+1)).$categories_list_all[1][$subcat_id]['pp_title'];
		}
	}
	return $subcategories;
}