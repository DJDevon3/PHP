<?php
/*********************************************
  Paypal_Store for DragonflyCMS
  ********************************************
	Helping to create a better internet for all.
	DJDevon3
	TreasureCoastDesigns.com
**********************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class Paypal_Store {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function Paypal_Store() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'Paypal_Store';
		$this->description = 'Paypal Storefront for your DragonflyCMS powered website';
		$this->author = 'DJDevon3';
		$this->website = 'www.TreasureCoastDesigns.com';
		$this->dbtables = array('paypal_cart_info','paypal_subscription_info','paypal_payment_info', 'paypal_categories', 'paypal_products', 'paypal_user_reviews', 'paypal_shipping', 'paypal_cart_sessions', 'paypal_cart_register');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'paypal_cart_info', "
		cart_id int(20) NOT NULL auto_increment,
		txn_id varchar(30) NOT NULL,
		item_name varchar(255) NOT NULL,
		item_number varchar(50) NOT NULL,
		option_name1 varchar(50) NOT NULL,
		option_select1 varchar(20) NOT NULL,
		option_name2 varchar(50) NOT NULL,
		option_select2 varchar(20) NOT NULL,
		quantity char(3) NOT NULL,
		invoice varchar(255) NOT NULL,
		custom varchar(255) NOT NULL,
    PRIMARY KEY  (cart_id)", 'paypal_cart_info');

		
		$installer->add_query('CREATE', 'paypal_subscription_info', "
		subscriber_id int(20) NOT NULL auto_increment,
		subscr_id varchar(255) NOT NULL,
		sub_event varchar(50) NOT NULL,
		subscr_date varchar(255) NOT NULL,
		subscr_effective varchar(255) NOT NULL,
		period1 varchar(255) NOT NULL,
		period2 varchar(255) NOT NULL,
		period3 varchar(255) NOT NULL,
		amount1 varchar(255) NOT NULL,
		amount2 varchar(255) NOT NULL,
		amount3 varchar(255) NOT NULL,
		mc_amount1 varchar(255) NOT NULL,
		mc_amount2 varchar(255) NOT NULL,
		mc_amount3 varchar(255) NOT NULL,
		recurring varchar(255) NOT NULL,
		reattempt varchar(255) NOT NULL,
		retry_at varchar(255) NOT NULL,
		recur_times varchar(255) NOT NULL,
		username varchar(255) NOT NULL,
		custom varchar(255) NOT NULL,
		txn_id varchar(50) NOT NULL,
		payer_email varchar(255) NOT NULL,
		date_creation date NOT NULL default '0000-00-00',
    PRIMARY KEY  (subscriber_id)", 'paypal_subscription_info');

		
		$installer->add_query('CREATE', 'paypal_payment_info', "
		payment_id int(20) NOT NULL auto_increment,
		first_name varchar(255) NOT NULL,
		last_name varchar(255) NOT NULL,
		payer_email varchar(255) NOT NULL,
		street varchar(255) NOT NULL,
		city varchar(255) NOT NULL,
		state varchar(255) NOT NULL,
		zipcode varchar(11) NOT NULL,
		memo varchar(255) NOT NULL,
		item_name varchar(255) NOT NULL,
		item_number varchar(255) NOT NULL,
		option_name1 varchar(50) NOT NULL,
		option_select1 varchar(20) NOT NULL,
		option_name2 varchar(50) NOT NULL,
		option_select2 varchar(20) NOT NULL,
		quantity char(3) NOT NULL,
		payment_date varchar(50) NOT NULL,
		payment_type varchar(10) NOT NULL,
		txn_id varchar(30) NOT NULL,
		mc_gross varchar(6) NOT NULL,
		mc_fee varchar(5) NOT NULL,
		payment_status varchar(15) NOT NULL,
		pending_reason varchar(10) NOT NULL,
		txn_type varchar(10) NOT NULL,
		tax varchar(10) NOT NULL,
		mc_currency varchar(5) NOT NULL,
		reason_code varchar(20) NOT NULL,
		custom varchar(255) NOT NULL,
		country varchar(20) NOT NULL,
		date_creation date NOT NULL default '0000-00-00',
    PRIMARY KEY  (payment_id)", 'paypal_payment_info');
			
		$installer->add_query('CREATE', 'paypal_categories', "
			pp_cid int(10) NOT NULL auto_increment,
			pp_title varchar(255) NOT NULL,
			pp_description text NOT NULL,
			ppc_weight int(11) NOT NULL default '1',
			parentid int(11) NOT NULL default '0',
			cat_order int(11) NOT NULL default '0',
			hits int(11) NOT NULL default '0',
			PRIMARY KEY (pp_cid),
			KEY pp_cid (pp_cid)", 'paypal_categories');

		$installer->add_query('CREATE', 'paypal_products', "
			pp_pid int(10) NOT NULL auto_increment,
			pp_active int(1) NOT NULL default '1',
			pp_type int(1) NOT NULL,
			ppp_weight int(10) NOT NULL default '0',
			pp_title varchar(255) NOT NULL,
			pp_thumbnail varchar(255) NOT NULL,
			pp_image1 varchar(255) NOT NULL,
			pp_image2 varchar(255) NOT NULL,
			pp_image3 varchar(255) NOT NULL,
			pp_image4 varchar(255) NOT NULL,
			pp_image5 varchar(255) NOT NULL,
			pp_description text NOT NULL,
			pp_description_full text NOT NULL,
			pp_quantity varchar (5) NOT NULL,
			pp_currency_code varchar (10) NOT NULL,
			pp_tax varchar (10) NOT NULL,
			pp_value varchar (255) NOT NULL,
			pp_sku varchar (50) NOT NULL,
			pp_optiontype varchar (255) NOT NULL,
			pp_optionname varchar (255) NOT NULL,
			pp_ddchoices varchar (255) NOT NULL,
			ppp_cid int(10) NOT NULL,
			trial_one_act int(1) NOT NULL,
			trial_one_amount int(3) NOT NULL,
			trial_one_cycle varchar(1) NOT NULL,
			trial_one_cost varchar(7) NOT NULL,
			sub_cost varchar(255) NOT NULL,
			sub_amount int(3) NOT NULL,
			sub_cycle varchar(1) NOT NULL,
			sub_recurring varchar(1) NOT NULL,
			group_active varchar(1) NOT NULL,
			group_id varchar(255) NOT NULL,
			featured int(1) NOT NULL,
			PRIMARY KEY (pp_pid),
			KEY pp_value (pp_value)", 'paypal_products');

		$installer->add_query('CREATE', 'paypal_user_reviews', "
			cmmtid int(10) NOT NULL auto_increment,
			cmmtkey int(10) NOT NULL default '0',
			cmmtuser int(10) NOT NULL default '0',
			cmmttext text NOT NULL default '',
			cmmtdate int(10) NOT NULL default '0',
			PRIMARY KEY (cmmtid),
			KEY cmmtkey (cmmtkey)", 'paypal_user_reviews');

		$installer->add_query('CREATE', 'paypal_shipping', "
			pp_sid int(10) NOT NULL auto_increment,
			pp_option varchar(255) NOT NULL,
			pp_option2 text NOT NULL,
			PRIMARY KEY (pp_sid),
			KEY pp_option (pp_option)", 'paypal_shipping');
			
		$installer->add_query('CREATE', 'paypal_cart_sessions', "
			entry_id int(20) NOT NULL auto_increment,
			cart_session varchar(255) NOT NULL,
			item_number int(17) NOT NULL,
			item_name varchar(255) NOT NULL,
			item_quantity int(17) NOT NULL,
			options varchar(255) NOT NULL,
			cost varchar(255) NOT NULL,
			tax varchar(255) NOT NULL,
			shipping varchar(255) NOT NULL,
    	PRIMARY KEY  (entry_id)", 'paypal_cart_sessions');
		
		$installer->add_query('CREATE', 'paypal_cart_register', "
			reg_id int(20) NOT NULL auto_increment,
			cart_session varchar(255) NOT NULL,
			start_sess varchar(255) NOT NULL,
			end_sess varchar(255) NOT NULL,
    	PRIMARY KEY  (reg_id)", 'paypal_cart_register');
			
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_perpage', '5'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_email', 'yourname@domain.com'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_address', 'Street Address'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_phone', 'Support Contact'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_business_name', 'Company Site Name'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_image_path', '/modules/Paypal_Store/images'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_maintenance', '1'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_donation', 'donation.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_subscribe', 'subscribe.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_addtocart', 'addtocart.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_buynow', 'buynow.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_viewcart', 'viewcart.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_checkout', 'checkout.gif'");
			$installer->add_query('INSERT', 'config_custom', "'paypal_store', 'pp_continue_shopping', 'continue_shopping.gif'");


	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'paypal_cart_info');
		$installer->add_query('DROP', 'paypal_subscription_info');
		$installer->add_query('DROP', 'paypal_payment_info');
		$installer->add_query('DROP', 'paypal_categories');
		$installer->add_query('DROP', 'paypal_products');
		$installer->add_query('DROP', 'paypal_user_reviews');
		$installer->add_query('DROP', 'paypal_shipping');
		$installer->add_query('DROP', 'paypal_cart_sessions');
		$installer->add_query('DROP', 'paypal_cart_register');
		$installer->add_query('DELETE', 'config_custom', "cfg_name='paypal_store'");

		return true;
	}
}
?>