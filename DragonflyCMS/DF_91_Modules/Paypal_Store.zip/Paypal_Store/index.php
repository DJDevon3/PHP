<?php
/*********************************************
  Paypal_Store for DragonflyCMS
  ********************************************
	Helping to create a better internet for all.
	DJDevon3
	TreasureCoastDesigns.com
**********************************************/
if (!defined('CPG_NUKE')) { exit; }
$pagetitle .= _PAYPAL_STORE;
$module_name = basename(dirname(__FILE__));

$do = (isset($_GET['do']) ? $_GET['do'] : (isset($_POST['do']) ? $_POST['do'] : ''));
$pp_pid = (isset($_GET['pp_pid']) ? intval($_GET['pp_pid']) : (isset($_POST['pp_pid']) ? intval($_POST['pp_pid']) : 0));

require_once(BASEDIR.'/modules/'.$module_name.'/functions.php');

function index() {
  global $MAIN_CFG, $prefix, $db, $module_name, $userinfo, $nukeurl;
	require('header.php');
	
	# Check if user has items in a cart
	if(isset($_COOKIE['ps_cart_sess'])){
				 $user_cart_session = $_COOKIE['ps_cart_sess'];
				 $check_cart = $db->sql_query("SELECT COUNT(*) FROM ".$prefix."_paypal_cart_sessions WHERE cart_session='$user_cart_session'");
				 list($cartitems) = $db->sql_fetchrow($check_cart);

				 $db->sql_freeresult($check_cart);
				 }
	
	

	$cartitems = '';
	$domain = $MAIN_CFG['server']['domain'];
	$pp_donate = $MAIN_CFG['paypal_store']['pp_donation'];
	$pp_subscribe = $MAIN_CFG['paypal_store']['pp_subscribe'];
	$pp_addtocart = $MAIN_CFG['paypal_store']['pp_addtocart'];
	$pp_buynow = $MAIN_CFG['paypal_store']['pp_buynow'];
	$pp_viewcart = $MAIN_CFG['paypal_store']['pp_viewcart'];
	$pp_checkout = $MAIN_CFG['paypal_store']['pp_checkout'];
	$pp_email = $MAIN_CFG['paypal_store']['pp_email'];
	$pp_business_name = $MAIN_CFG['paypal_store']['pp_business_name'];
	$pp_image_path = $MAIN_CFG['paypal_store']['pp_image_path'];
	$pp_maintenance = $MAIN_CFG['paypal_store']['pp_maintenance'];
	
	

	# How many products are actually in the store
	$result = $db->sql_query("SELECT COUNT(*) FROM ".$prefix."_paypal_products where pp_active='1'");
	list($total_products) = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);
	# How many categories do we have total
	$cats = $db->sql_query("SELECT COUNT(*) FROM ".$prefix."_paypal_categories");
	list($total_cats) = $db->sql_fetchrow($cats);
	$db->sql_freeresult($cats);
	

	$cpgtpl->assign_vars(array(
	'PP_HOME' 				=> '<a href="index.php?name='.$module_name.'"><img src="modules/'.$module_name.'/images/PayPalStorefront.gif" alt="Graphical Image Missing" border="0" /></a>',
	'PP_IMAGE_PATH' 		=> $pp_image_path,
	'PP_EMAIL'				=> $pp_email,
	'PP_BUSINESS_NAME' 		=> $pp_business_name,
	'PP_VIEWCART' 			=> $pp_viewcart,
	'PP_CHECKOUT' 			=> $pp_checkout,
	'PP_CART_ITEMS' 		=> $cartitems,
	'TOTAL_CATS' 			=> $total_cats,
	'TOTAL_PRODUCTS' 		=> $total_products,
	'L_NOPRODUCTS'			=> _PAYPALSTORE_PRODUCT_NOPRODUCTS,
	'SKU' 					=> _SKU,
	'QUANTITY' 				=> _QUANTITY,
	));
	


	# let's check to see if there are any products 
	# before we query the database for them
	if ($pp_maintenance){ echo '<div class="table1" align="center">Our store is currently in maintenance mode. <br />Please come back later.</div>';
	}else {

# Assign variables for categories 
	$result_c = $db->sql_query('SELECT pp_cid, pp_title, pp_description, ppc_weight, parentid, cat_order, hits FROM '.$prefix.'_paypal_categories WHERE parentid = 0 ORDER BY ppc_weight ASC');
	while(list($pp_cid, $pp_title, $pp_description, $ppc_weight, $parentid, $cat_order, $hits) = $db->sql_fetchrow($result_c)){
			
			# CATEGORY TEMPLATE
			$cpgtpl->assign_block_vars('pp_categories', array(
			'URL'   => getlink('&amp;c=$pp_cid'),
			'PP_CID' 			=> $pp_cid,
			'PP_TITLE' 			=> $pp_title,
			'PP_DESCRIPTION' 	=> $pp_description,
			'PPC_WEIGHT' 		=> $ppc_weight,
			'PARENTID' 			=> $parentid,
			'CAT_ORDER' 		=> $cat_order,
			'HITS' 				=> $hits,
			'PP_VIEWCART_URL'   => getlink('&amp;do=ViewCart'),
			'PP_URL'   => getlink('&amp;do=cat&amp;pp_cid='.$pp_cid.''),
			));	
	}
	# lets grab all the info for the featured products if any
	$result3 = $db->sql_query("SELECT * FROM ".$prefix."_paypal_products WHERE featured='1'");
	while(list($pp_pid, $pp_active, $pp_type, $ppp_weight, $pp_title, $pp_thumbnail, $pp_image1, $pp_image2, $pp_image3, $pp_image4, $pp_image5, $pp_description, $pp_description_full, $pp_quantity, $pp_currency_code, $pp_tax, $pp_value, $pp_sku, $pp_optiontype, $pp_optionname, $pp_ddchoices, $ppp_cid, $trial_one_act, $trial_one_amount, $trial_one_cycle, $trial_one_cost, $sub_cost, $sub_amount, $sub_cycle, $sub_recurring, $groupactive, $groupid, $featured) = $db->sql_fetchrow($result3)) {
	
	  if($pp_type == 1 && $pp_active==1){
			$button_form = "<form action='https://www.paypal.com/cgi-bin/webscr' method='post'>"
			."<img src='https://www.paypal.com/en_US/i/scr/pixel.gif' width='1' height='1' alt='' border='0' />"
			."Please enter the amount agreed upon for your service.<br /><br />We also appreciate donations for Open-Source development.<br /><br />"
			."<input type='text' size='4' maxlength='10' name='amount' value='0'><br /><br />"
			."<input type='hidden' name='cmd' value='_xclick'>"
			."<input type='hidden' name='bn' value='PP-DonationsBF'>"
			."<input type='hidden' name='lc' value='US'>"
			."<input type='hidden' name='business' value='$pp_email'>"
			."<input type='hidden' name='item_name' value='$pp_title'>"
			."<input type='hidden' name='item_number' value='$pp_sku'>"
			."<input type='hidden' name='tax_$pp_pid' value='$pp_tax'>"
			."<input type='hidden' name='currency_code' value='$pp_currency_code'>"
			."<input type='hidden' name='add' value='$pp_quantity'>"
			."<input type='hidden' name='no_shipping' value='1'>"
			."<input type='hidden' name='cn' value='Optional Note'>"
			."<input type='hidden' name='page_style' value='Primary'>"
			."<input type='hidden' name='return' value='$nukeurl'>"
			."<input type='image' src='modules/".$module_name."/images/buttons/$pp_donate' border='0' name='submit' alt='Submit'>";

		 # assign the products to block_vars 'pp_donations'
		$cpgtpl->assign_block_vars('pp_donations', array(
			'PP_DONATE'		=> $pp_donate,
			'PP_PID' 			=> $pp_pid,
			'PP_ACTIVE' 		=> $pp_active,
			'PP_TITLE' 			=> $pp_title,
			'PPP_WEIGHT' 		=> $ppp_weight,
			'PP_IMAGE_PATH' 	=> $pp_image_path,
			'PP_THUMBNAIL' 		=> $pp_thumbnail,
			'PP_DESCRIPTION' 	=> $pp_description,
			'PP_TAX' 			=> $pp_tax,
			'PP_OPTIONTYPE' 	=> $pp_optiontype,
			'PP_OPTIONNAME' 	=> $pp_optionname,
			'PP_DDCHOICES' 		=> $pp_ddchoices,
			'PP_BUTTON_FORM'   => $button_form,
			'PRODUCTVIEW' 		=> getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''),
		));	
		}
		if($pp_type == 2 && $pp_active==1){
		$button_form = "<b>$pp_value&nbsp;$pp_currency_code</b><br /><br />"._QUANTITY."$pp_quantity<br /><br />"
								 ."<form action='".getlink('&amp;do=AddCart')."' method='post'>"
								 ."<img src='https://www.paypal.com/en_US/i/scr/pixel.gif' width='1' height='1' alt='' border='0' />"
								 ."<input type='hidden' name='item_name' value='$pp_title'>"
								 ."<input type='hidden' name='item_number' value='$pp_pid'>"
								 ."<input type='hidden' name='amount' value='$pp_value'>"
								 ."<input type='hidden' name='tax' value='$pp_tax'>"
								 ."<input type='hidden' name='add' value='$pp_quantity'>"
							 	 ."<input type='image' src='modules/".$module_name."/images/buttons/$pp_addtocart' border='0' name='submit' alt='Submit'>";
		
		# assign the products to block_vars 'pp_products'
		$cpgtpl->assign_block_vars('pp_products', array(
			'PP_ADDTOCART'		=> $pp_addtocart,
			'PP_BUYNOW' 		=> $pp_buynow,
			'PP_PID' 			=> $pp_pid,
			'PP_ACTIVE' 		=> $pp_active,
			'PP_TITLE' 			=> $pp_title,
			'PP_SKU' 			=> $pp_sku,
			'PPP_WEIGHT' 		=> $ppp_weight,
			'PP_IMAGE_PATH' 	=> $pp_image_path,
			'PP_THUMBNAIL' 		=> $pp_thumbnail,
			'PP_DESCRIPTION' 	=> $pp_description,
			'PP_TAX' 			=> $pp_tax,
			'PP_OPTIONTYPE' 	=> $pp_optiontype,
			'PP_OPTIONNAME' 	=> $pp_optionname,
			'PP_DDCHOICES' 		=> $pp_ddchoices,
			'PP_BUTTON_FORM'	=> $button_form,
			'ADMIN_EDIT'		=> adminlink('&amp;mode=Products&amp;pp_pid='.$pp_pid.''),
			'PRODUCTVIEW' 		=> getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''),
		));	
		}
		if($pp_type == 3 && $pp_active==1){
			if (!is_user()){
				 $user_id = 0;
				 }else{
				 $user_id = $userinfo['user_id'];
				 }
			# Had to be a way of displaying something different
			# Depending on what type of subscription
			if ($trial_one_act == 0) {
				  if ($sub_amount > 1){
				 		 $s = "s";
				 		 }else{
				 		 $s = "";
				 		 }			
			   	if ($sub_cycle == "D"){
						 $duration = "Day$s";
						 }elseif($sub_cycle == "W"){
						 $duration = "Week$s";
						 }elseif($sub_cycle == "M"){
						 $duration = "Month$s";
						 }else{
						 $duration = "Year$s";
						 }
					if ($sub_recurring == 1){
						 $recur_discription == "Recurring";
						 }else{
						 $recur_discription == "Non-Recurring";
						 }
						 # Button code for no trial subsription
				  $button_form = "<b>$sub_cost&nbsp;$pp_currency_code</b><br />For $sub_amount &nbsp;$duration<br />$recur_discription<br />"
					."<form action='https://www.paypal.com/cgi-bin/webscr' method='post'>"
					."<img src='https://www.paypal.com/en_US/i/scr/pixel.gif' width='1' height='1' alt='' border='0' />"
					."<input type='hidden' name='cmd' value='_xclick-subscriptions'>"
					."<input type='hidden' name='rm' value='2'>"
					."<input type='hidden' name='business' value='$pp_email'>"
					."<input type='hidden' name='item_name' value='$pp_title'>"
					."<input type='hidden' name='item_number' value='$pp_pid'>"
					."<input type='hidden' name='return' value='http://$domain/index.php?name=$module_name&do=ThankYou'>"
					."<input type='hidden' name='notify_url' value='http://$domain/ps_ipn.php'>"
					."<input type='hidden' name='cancel_url' value='http://$domain/index.php?name=$module_name&do=Cancel'>"
					."<input type='hidden' name='no_shipping' value='1'>"
					."<input type='hidden' name='no_note' value='1'>"
					."<input type='hidden' name='currency_code' value='$pp_currency_code'>"
					."<input type='hidden' name='1c' value='US'>"
					."<input type='hidden' name='bn' value='PP-SubscriptionsBF'>"
					."<input type='hidden' name='a3' value='$sub_cost'>"
					."<input type='hidden' name='p3' value='$sub_amount'>"
					."<input type='hidden' name='t3' value='$sub_cycle'>"
					."<input type='hidden' name='src' value='1'>"
					."<input type='hidden' name='sra' value='1'>"
					."<input type='hidden' name='custom' value='$user_id'>"
					."<input type='image' src='modules/".$module_name."/images/buttons/$pp_subscribe' border='0' name='submit' alt='Submit'>";
												 
					$cpgtpl->assign_block_vars('pp_products', array(
					'PP_ADDTOCART'		=> $pp_addtocart,
					'PP_SUBSCRIBE' 		=> $pp_subscribe,
					'PP_PID' 			=> $pp_pid,
					'PP_ACTIVE' 		=> $pp_active,
					'PP_TITLE' 		=> $pp_title,
					'PP_SKU' 		=> $pp_sku,
					'PPP_WEIGHT' 		=> $ppp_weight,
					'PP_IMAGE_PATH' 	=> $pp_image_path,
					'PP_THUMBNAIL' 		=> $pp_thumbnail,
					'PP_DESCRIPTION' 	=> $pp_description,
					'PP_TAX' 			=> $pp_tax,
					'PP_OPTIONTYPE' 	=> $pp_optiontype,
					'PP_OPTIONNAME' 	=> $pp_optionname,
					'PP_DDCHOICES' 		=> $pp_ddchoices,
					'PP_BUTTON_FORM'   => $button_form,
					'ADMIN_EDIT'		=> adminlink('&amp;mode=Products&amp;pp_pid='.$pp_pid.''),
					'PRODUCTVIEW' 		=> getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''),
					));
						
				}else{
				    # Had to be a way of displaying something different
						# Depending on what type of subscription
						if ($trial_one_cost == 0){
				 		 $toc = "Free";
				 		 }else{
				 		 $toc = $trial_one_cost;
				 		 }
						if ($trial_one_amount > 1){
				 		 	 $ts = "s";
				 		 	 }else{
				 		 	 $ts = "";
				 		 	 }						
			   	  if ($trial_one_cycle == "D"){
						 	 $duration_trial = "Day$ts";
						 	 }elseif($trial_one_cycle == "W"){
						 	 $duration_trial = "Week$ts";
						 	 }elseif($trial_one_cycle == "M"){
						 	 $duration_trial = "Month$ts";
						 	 }else{
						 	 $duration_trial = "Year$ts";
						 	 }
						 if ($sub_amount > 1){
						 		$long = $sub_amount;
				 		 		$s = "s";
				 		 		}else{
								$long = "";
				 		 		$s = "";
				 		 		}			
			   		 if ($sub_cycle == "D"){
						 		$duration = "Day$s";
						 		}elseif($sub_cycle == "W"){
						 		$duration = "Week$s";
						 		}elseif($sub_cycle == "M"){
						 		$duration = "Month$s";
						 		}else{
						 		$duration = "Year$s";
						 		}
							 if ($sub_recurring == 1){
							 $each = "Every";
						 	 $recur_discription = "Recurring";
						 	 }else{
							 $each = "";
						 	 $recur_discription = "Non-Recurring";
						 	 }
						#Do the trial first	
						$button_form = "-<b>Subscribe $trial_one_amount&nbsp;$duration_trial<br />For&nbsp;$toc</b>-<br /><br /><b>$sub_cost&nbsp;$pp_currency_code</b><br />$each&nbsp;$long &nbsp;$duration<br />$recur_discription<br />"
						."<form action='https://www.paypal.com/cgi-bin/webscr' method='post'>"
						."<img src='https://www.paypal.com/en_US/i/scr/pixel.gif' width='1' height='1' alt='' border='0' />"
						."<input type='hidden' name='cmd' value='_xclick-subscriptions'>"
						."<input type='hidden' name='rm' value='2'>"
						."<input type='hidden' name='business' value='$pp_email'>"
						."<input type='hidden' name='item_name' value='$pp_title'>"
						."<input type='hidden' name='item_number' value='$pp_pid'>"
						."<input type='hidden' name='return' value='http://$domain/index.php?name=$module_name&do=ThankYou'>"
						."<input type='hidden' name='notify_url' value='http://$domain/ps_ipn.php'>"
						."<input type='hidden' name='cancel_url' value='http://$domain/index.php?name=$module_name&do=Cancel'>"
						."<input type='hidden' name='no_shipping' value='1'>"
						."<input type='hidden' name='no_note' value='1'>"
						."<input type='hidden' name='currency_code' value='$pp_currency_code'>"
						."<input type='hidden' name='1c' value='US'>"
						."<input type='hidden' name='bn' value='PP-SubscriptionsBF'>"
						."<input type='hidden' name='a1' value='$trial_one_cost'>"
						."<input type='hidden' name='p1' value='$trial_one_amount'>"
						."<input type='hidden' name='t1' value='$trial_one_cycle'>"
						."<input type='hidden' name='a3' value='$sub_cost'>"
						."<input type='hidden' name='p3' value='$sub_amount'>"
						."<input type='hidden' name='t3' value='$sub_cycle'>"
						."<input type='hidden' name='src' value='1'>"
						."<input type='hidden' name='sra' value='1'>"
						."<input type='hidden' name='custom' value='$user_id'>"
						."<input type='image' src='modules/".$module_name."/images/buttons/$pp_subscribe' border='0' name='submit' alt='Submit'>";
												 
						# assign the products to block_vars 'pp_products'
						$cpgtpl->assign_block_vars('pp_products', array(
						'PP_ADDTOCART'		=> $pp_addtocart,
						'PP_SUBSCRIBE' 		=> $pp_subscribe,
						'PP_PID' 			=> $pp_pid,
						'PP_ACTIVE' 		=> $pp_active,
						'PP_TITLE' 		=> $pp_title,
						'PP_SKU' 		=> $pp_sku,
						'PPP_WEIGHT' 		=> $ppp_weight,
						'PP_IMAGE_PATH' 	=> $pp_image_path,
						'PP_THUMBNAIL' 		=> $pp_thumbnail,
						'PP_DESCRIPTION' 	=> $pp_description,
						'PP_TAX' 			=> $pp_tax,
						'PP_OPTIONTYPE' 	=> $pp_optiontype,
						'PP_OPTIONNAME' 	=> $pp_optionname,
						'PP_DDCHOICES' 		=> $pp_ddchoices,
						'PP_BUTTON_FORM'   => $button_form,
						'ADMIN_EDIT'		=> adminlink('&amp;mode=Products&amp;pp_pid='.$pp_pid.''),
						'PRODUCTVIEW' 		=> getlink('&amp;do=pd&amp;pp_pid='.$pp_pid.''),
						));	
			
				}
		
		}
		
	}
}

# set the template name and display the page
$cpgtpl->set_filenames(array('body' => 'Paypal_Store/index_body.html'));
$cpgtpl->display('body');
}

function Cancel() {
				 global $MAIN_CFG, $db, $prefix, $user_prefix;
				 require('header.php');
				 ###### Need to finish this as a template !!!
				 OpenTable();
				 echo "<div align='center'>Ahhh, You stopped the payment!!</div>";
				 CloseTable();
}

switch($do) {	
	
		default:
		index();
		break;

		case "pd":
		require("modules/$module_name/product_details.inc");
		pd(intval($_GET['pp_pid']));
		break;

		case "cat":
		require("modules/$module_name/categories.inc");
		break;
			
		case "Cancel":
		Cancel();
		break;
		
		case "ThankYou":
		require("modules/$module_name/ps_returns.inc");
		messageThankYou();
		break;
		
		case "AddCart":
		$item_name = isset($_POST['item_name']) ? Fix_Quotes($_POST['item_name']) : '';
		$item_number = isset($_POST['item_number']) ? intval($_POST['item_number']) : '';
		$amount = isset($_POST['amount']) ? Fix_Quotes($_POST['amount']) : '';
		$tax = isset($_POST['tax']) ? Fix_Quotes($_POST['tax']) : '';
		$add = isset($_POST['add']) ? Fix_Quotes($_POST['add']) : '';
		require("modules/$module_name/ps_cart.inc");
		addPsCart($item_name,$item_number,$amount,$tax,$add);
		break;
		
		case "ViewCart":
		require("modules/$module_name/ps_cart.inc");
		viewPsCart();
		break;
		
		case "UpdateCart":
		require("modules/$module_name/ps_cart.inc");
		updatePsCart();
		break;
		
}