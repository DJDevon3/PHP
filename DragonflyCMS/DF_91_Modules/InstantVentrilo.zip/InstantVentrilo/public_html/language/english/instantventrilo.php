<?php
/************************************************************************/
/* InstantVentrilo 1.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) InstantVentrilo.com                                      */
/* Made for displaying a ventrilo server status by plugging into InstantVentrilo.com output code       */
/* ============================================                         */
/************************************************************************/

/* HELPFUL LANGUAGE DEFINITIONS */
define("_MODULEMESSAGE","Instant Ventrilo for DragonflyCMS by <a href=\"http://www.LegendaryGamers.net\" target=\"_blank\">Legendary Gamers</a>");
define("_MODULEMESSAGE2","an easy way to manage the status display of your ventrilo server");
define("_THEMECP","InstantVentrilo");
define("_OTHERMETHOD","You can also use the following link from Ventrilo.com if you prefer more information on your Vent Server");

define("_COLORSELECTION","<b>Color Selection:</b> Select a color on the left, then click a button on the right to set the color.");
define("_IVON","On");
define("_IVOFF","Off");
define("_SAVECHANGES","Save Configuration");
define("_IVDEBUG","This is the string used in the query.");

/* FIELDS */
define("_STYLE","Style");
define("_OUTPUT","Output Method");
define("_DISPLAYIP","Display server IP and PORT?");
define("_DISPLAYCHANNEL","Display Empty Channels?");
define("_DISPLAYHELP","Display help link?");
define("_IP","IP");
define("_PORT","Port");
define("_WIDTH","Width");
define("_SELECT_BACKGROUND","Background");
define("_SERVER_NAME_BACKGROUND","Server Name Background ");
define("_SERVER_NAME_TEXT","Server Name");
define("_INFO_BACKGROUND","Info Background");
define("_INFO_TEXT","Info Text");
define("_HELP_BACKGROUND","Help Background");
define("_HELP_TEXT","Help Text");
define("_CHANNEL_BACKGROUND","Channel Background");
define("_CHANNEL_TEXT","Channel Text");
define("_USERNAME_BACKGROUND","Username Background");
define("_USERNAME_TEXT","Username Text");

?>