<?php
/************************************************************************/
/* InstantVentrilo 1.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) InstantVentrilo.com                                      */
/* Made for displaying a ventrilo server status by plugging into InstantVentrilo.com output code       */
/* ============================================                         */
/************************************************************************/

if (!defined('CPG_NUKE')) { exit; }
    require_once('header.php');

$result = $db->sql_query("SELECT ip, port, showchannels, showhelp, width, bgcolor, style, showinfo, servernamebg, servernametext, infobg, infotext, helpbg, helptext, channelbg, channeltext, usernamebg, usernametext, method FROM ".$prefix."_instantventrilo");
    list($ip, $port, $showchannels, $showhelp, $width, $bgcolor, $style, $showinfo, $servernamebg, $servernametext, $infobg, $infotext, $helpbg, $helptext, $channelbg, $channeltext, $usernamebg, $usernametext, $method) = $db->sql_fetchrow($result);

	echo "<br>";
    OpenTable();
    echo '<div style="margin-bottom:20px;" align="center">';
    echo '<script type="text/javascript" src="http://view.light-speed.com/ventrilo.php?IP='.$ip.'&PORT='.$port.'&CHANNEL_WNOUSER='.$showchannels.'&HELP='.$showhelp.'&WIDTH='.$width.'&BGCOLOR='.$bgcolor.'&STYLE='.$style.'&SHOW_IP_PORT='.$showinfo.'&SN_BGCOLOR='.$servernamebg.'&SN_COLOR='.$servernametext.'&INFO_BGCOLOR='.$infobg.'&INFO_COLOR='.$infotext.'&HELP_BGCOLOR='.$helpbg.'&HELP_COLOR='.$helptext.'&CHANNEL_BGCOLOR='.$channelbg.'&CHANNEL_COLOR='.$channeltext.'&UN='.$usernametext.'&UN_BG='.$usernamebg.'&METHOD='.$method.'"></script>';
    echo '</div>';
	CloseTable();


?>