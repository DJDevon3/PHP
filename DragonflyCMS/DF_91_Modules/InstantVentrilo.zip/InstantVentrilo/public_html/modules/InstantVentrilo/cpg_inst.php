<?php
/************************************************************************/
/* InstantVentrilo 1.0 FOR DRAGONFLYCMS                             */
/* ============================================                         */
/* Copyright (c) InstantVentrilo.com                                      */
/* Made for displaying a ventrilo server status by plugging into InstantVentrilo.com output code       */
/* ============================================                         */
/************************************************************************/
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class InstantVentrilo {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function InstantVentrilo() {
		$this->radmin = true;
		$this->version = '1.0';
		$this->modname = 'InstantVentrilo';
		$this->description = 'Ventrilo Server Status Module';
		$this->author = 'Devil';
		$this->website = 'www.LegendaryGamers.net';
		$this->dbtables = array('instantventrilo');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'instantventrilo', "
			ip varchar(15) NOT NULL default '',
			port varchar(5) NOT NULL default '',
			showchannels tinyint(1) NOT NULL default '',
			showhelp tinyint(1) NOT NULL default '',
			width varchar(5) NOT NULL default '',
			bgcolor varchar(6) NOT NULL default '',
			style varchar(2) NOT NULL default '',
			showinfo tinyint(1) NOT NULL default '',
			servernamebg varchar(6) NOT NULL default '',
			servernametext varchar(6) NOT NULL default '',
			infobg varchar(6) NOT NULL default '',
			infotext varchar(6) NOT NULL default '',
			helpbg varchar(6) NOT NULL default '',
			helptext varchar(6) NOT NULL default '',
			channelbg varchar(6) NOT NULL default '',
			channeltext varchar(6) NOT NULL default '',
			usernamebg varchar(6) NOT NULL default '',
			usernametext varchar(6) NOT NULL default '',
			method varchar(2) NOT NULL default '',
			PRIMARY KEY (ip),
			KEY ip (ip)", 'instantventrilo');

			$installer->add_query('INSERT', 'instantventrilo', "'64.237.62.226', '4299', '0', '0', '150', '000000', '1', '1', '000000', 'FFFF00', '999900', 'FFFF00', '333000', 'FFFF00', '333000', 'FFFF00', 'FFFF00', '333000', 'js'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'instantventrilo');	
		return true;
	}
}
?>