<?php
/************************************************************************/
/* SPEED_TEST 1.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// SUPPORT
// This is a Dragonfly port by DJDevon3
// All support should be found at TreasureCoastDesigns.com
// I am not liable for any products or services affected by means of the script.
// The user must assume the entire risk of usage.
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
/* Module Index*/
define("_SPEED_TEST","Speed Test");
define("_ST_START","Start test");
define("_ST_BROKEN","Feature currently broken sorry");
/* Admin */
define("_SPEED_TEST_AD","Speed Test Administration");
define("_ST_ISP","DomainName.tld");
define("_ST_START_IMAGE","Start Button Image");
define("_ST_START_IMAGE_PATH","modules/Speed_Test/images/");
define("_ST_PROGRESS_IMAGE","Progress Bar Image");
define("_ST_PROGRESS_IMAGE_PATH","modules/Speed_Test/images/");
define("_ST_GRAPH_IMAGE","Result Bar Image");
define("_ST_GRAPH_PATH","modules/Speed_Test/images/");
define("_ST_BAR_HEIGHT","Result Bar Height");
define("_ST_BAR_WIDTH","Result Bar Width");
define("_ST_POP","Popup Window");
define("_ST_POP_WIDTH","Popup Window Width");
define("_ST_POP_HEIGHT","Popup Window Height");
define("_ST_FLOOD_CONTROL","Flood Control");
define("_ST_METER_DISPLAY","Initial Meter");
define("_ST_METER_EXPLAIN","(Large Packet Sample) Slower but more accurate test");
define("_STLOG","Log Results");
define("_ST_GEO_IP","Server Geo Location");
define("_ST_GEO_IP_EXPLAIN","Geolocation scraped from NetIP.de (Server IP not displayed)");
define("_ST_PAYLOAD_SIZE","Default Data Payload in Kb");
define("_ST_MESSAGE1","Message 1");
define("_ST_MESSAGE2","Message 2");
define("_ST_ON","ON");
define("_ST_OFF","OFF");
define("_ST_SAVE","Save");
define("_ST_WELCOME","Welcome to our internet connectivity speed test");

/* Error */
define("_ST_ERROR","Initialization Failure Please Notify Admin");

/* Results */
define("_ST_YOURRESULTS","Your current Bandwidth/Speed Rating is");
define("_ST_WHATMEAN_","Your \"real world\" download speed is");
define("_ST_MBPERSEK","MB/sec.");
define("_ST_KBPERSEK","KB/sec.");
define("_ST_YOURCURRENTRESULTS","YOU");
define("_ST_REPEATTEST","RE-TEST");
define("_ST_CLOSEWINDOW","CLOSE WINDOW");
define("_ST_WINDOWTITLE","Results");

/* Initialmeter*/
define("_ST_WINDOWTITLEINITIAL","Step 1 of 2");
define("_ST_INITIALNOTE1","Step 1 of 2 (JavaScript required)");
define("_ST_INITIALNOTE2","This should only take a few seconds.");

/* Meter*/
define("_ST_WINDOWTITLEMETER","Step 2 of 2");
define("_ST_METERNOTE1","Step 2 of 2 (JavaScript required)");
define("_ST_METERNOTE2","This should only take a few seconds.");
