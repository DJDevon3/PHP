<?php
/************************************************************************/
/* SPEED_TEST 2.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// LAST UPDATE: 8/26/2010
// ----------------------------------------------------------------------
$services = array(
	  "56.0" => array ("name" => "56k Dial-Up "
         , "image" => "modules/".$module_name."/images/red.gif"
        )
    , "128.0" => array ("name" => "128k ISDN "
         , "image" => "modules/".$module_name."/images/red.gif"
        )
    , "256.0" => array ("name" => "256k ADSL "
         , "image" => "modules/".$module_name."/images/purple.gif"
        )
    , "512.0" => array ("name" => "512k ADSL "
         , "image" => "modules/".$module_name."/images/purple.gif"
        )
    , "768.0" => array ("name" => "768k DSL / Cable"
         , "image" => "modules/".$module_name."/images/blue.gif"
        )
    , "1000.0" => array ("name" => "1 Mb DSL / Cable"
         , "image" => "modules/".$module_name."/images/blue.gif"
        )
    , "2000.0" => array ("name" => "2 Mb DSL / Cable"
         , "image" => "modules/".$module_name."/images/bronze.gif"
        )
    , "3000.0" => array ("name" => "3 Mb DSL / Cable"
         , "image" => "modules/".$module_name."/images/bronze.gif"
        )
    , "6000.0" => array ("name" => "6 Mb DSL / Cable"
         , "image" => "modules/".$module_name."/images/bronze.gif"
        )
	, "8000.0" => array ("name" => "1 MB Cable"
         , "image" => "modules/".$module_name."/images/silver.gif"
        )
	, "16000.0" => array ("name" => "2 MB Cable / Fiber"
         , "image" => "modules/".$module_name."/images/silver.gif"
        )
	, "24000.0" => array ("name" => "3 MB Cable / Fiber"
         , "image" => "modules/".$module_name."/images/silver.gif"
        )
	, "32000.0" => array ("name" => "4 MB Cable / Fiber"
         , "image" => "modules/".$module_name."/images/gold.gif"
        )
	, "40000.0" => array ("name" => "5 MB Cable / Fiber"
         , "image" => "modules/".$module_name."/images/gold.gif"
        )
	, "48000.0" => array ("name" => "6 MB Cable / Fiber"
         , "image" => "modules/".$module_name."/images/gold.gif"
        )
	, "56000.0" => array ("name" => "7 MB Fiber"
         , "image" => "modules/".$module_name."/images/gold.gif"
        )
    );
