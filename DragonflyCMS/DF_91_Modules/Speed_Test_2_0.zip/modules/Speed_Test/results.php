<?php
/************************************************************************/
/* SPEED_TEST 2.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// LAST UPDATE: 8/26/2010
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
require_once('services.php');
global $prefix, $db, $module_name, $Default_Theme, $nukeurl;
$result = $db->sql_query("SELECT start_image, progress_image, graph_image, popup, bar_height, bar_width, pop_width, pop_height, meter_display, stlog, geoip, flood_control, payload_size, message1, message2 FROM ".$prefix."_speedtest");
list($start_image, $progress_image, $graph_image, $popup, $bar_height, $bar_width, $pop_width, $pop_height, $meter_display, $stlog, $geoip, $flood_control, $payload_size, $message1, $message2) = $db->sql_fetchrow($result);

if ($popup==1){
echo "<html>";
echo "<head>";
echo "<title> ".$nukeurl." >> Speed Test Result</title>";
echo '<link rel="stylesheet" href="themes/'.$Default_Theme.'/style/style.css">';
echo "</head>";
echo "<body>";
} else {
require_once('header.php');
}


$ip = $_SERVER['REMOTE_ADDR'];
$name = gethostbyaddr($ip);
$date = date('Y/m/d');

$Kilobits = round($_GET['kbps'], 2);
$Bits = round($Kilobits * 1024, 0);
$Bytes = round($Bits / 8, 0);
//$Kilobits = round($Bytes / 128, 0);
$Kilobytes = round($Kilobits / 8, 2);
$Megabits = round($Kilobits / 1024, 2);
$Megabytes = round($Megabits / 8, 2);
$Gigabits = round($Megabits / 1024, 8);
$Gigabytes = round($Gigabits / 8, 8);

function percent($num_amount, $num_total) {
$count1 = $num_amount / $num_total;
$count2 = $count1 * 100;
$count = number_format($count2, 0);
return $count.'<br />';
}
if ($popup==0){
OpenTable();
}

if ($Kilobits > 1 && $Kilobits < 256){
	$SPEED_COLOR = '<font style="color:red;font-size:22px;">'.$Kilobits.' '._ST_KBPERSEK.'</font>';
}else if ($Kilobits > 256 && $Kilobits < 768){
    $SPEED_COLOR = '<font style="color:purple;font-size:22px;">'.$Kilobits.' '._ST_KBPERSEK.'</font>';
}else if ($Kilobits > 768 && $Kilobits < 1000){
    $SPEED_COLOR = '<font style="color:blue;font-size:22px;">'.$Kilobytes.' '._ST_KBPERSEK.'</font>';
}else if ($Kilobytes > 250 && $Megabytes < 1){
    $SPEED_COLOR= '<font style="color:orange;font-size:22px;">'.$Kilobytes.' '._ST_KBPERSEK.'</font>';
}else if ($Megabytes > 1 && $Megabytes < 4){
    $SPEED_COLOR = '<font style="color:white;font-size:22px;">'.$Megabytes.' '._ST_MBPERSEK.'</font>';
}else if ($Megabytes > 4 && $Megabytes < 15){
    $SPEED_COLOR = '<font style="color:yellow;font-size:22px;">'.$Megabytes.' '._ST_MBPERSEK.'</font>';
}else {
    $SPEED_COLOR = '<font style="color:black;font-size:22px;">'.$Megabytes.' '._ST_MBPERSEK.'</font>';
}


if ($popup == 1){
    $close_window = '<a href="javascript:window.close()">'._ST_CLOSEWINDOW.'</a>';
}else{
    $close_window = '';
}

if ($meter_display == 1){
    $retest = "<a href='?name=".$module_name."&amp;file=initialmeter'>"._ST_REPEATTEST."</a>";
}else{
    $retest = "<a href='?name=".$module_name."&amp;file=meter'>"._ST_REPEATTEST."</a>";
}

$test_results = $db->sql_query("SELECT test_num, speed, date, ip, name FROM ".$prefix."_speedtest_results WHERE date='".$date."' AND ip='".$ip."'");
list($result_test_num, $result_speed, $result_date, $result_ip, $result_name) = $db->sql_fetchrow($test_results);

if ($db->sql_numrows($test_results)>$flood_control) {
	$logging = "You've completed ".$flood_control." Speed Tests today.<br />You may continue but we will not record your score.";
}else{
	if ($stlog=='1'){
		$logging = 'Result Logged';
		$result = $db->sql_query("INSERT INTO ".$prefix."_speedtest_results (speed, date, ip, name) VALUES ('$Kilobits', '$date', '$ip', '$name')");
	} else {
		$logging = 'Result Logged';
	}
}

$cpgtpl->assign_vars(array(
'MODULE_NAME'				=> $module_name,
'RESULT_BITS'				=> $Bits,
'RESULT_BYTES'				=> $Bytes,
'RESULT_KILOBITS'			=> $Kilobits,
'RESULT_KILOBYTES'			=> $Kilobytes,
'RESULT_MEGABITS'			=> $Megabits,
'RESULT_MEGABYTES'			=> $Megabytes,
'RESULT_GIGABITS'			=> $Gigabits,
'RESULT_GIGABYTES'			=> $Gigabytes,
'SPEED_COLOR' 				=> $SPEED_COLOR,
'ST_LINK_PATH' 				=> $linkpath,
'ST_REPEATTEST' 			=> $retest,
'ST_CLOSE_WINDOW' 			=> $close_window,
'ST_LOGGING' 				=> $logging,
'ST_BAR_HEIGHT' 			=> $bar_height,
'_ST_WHATMEAN_' 			=> _ST_WHATMEAN_,
'_ST_CLOSEWINDOW' 			=> _ST_CLOSEWINDOW,
'_ST_YOURCURRENTRESULTS' 	=> _ST_YOURCURRENTRESULTS,
));

// YOUR SPEED
$service_speeds = array();
foreach(array_keys($services) as $service){
    array_push ($service_speeds, $service);
}
$max_in_array = max ($service_speeds);
if ($Megabits > 8){
	$ST_FILE_SIZE = $Megabytes .' Megabytes';
}else if ($Megabits > 1){
	$ST_FILE_SIZE = $Megabits .' Megabits';
}else{
	$ST_FILE_SIZE = $Kilobits .' Kilobits';
}
// MERGE YOUR SPEED INTO SERVICES ARRAY
$end = array("".$Kilobits."" => array ("name" => "<b>YOU ".$ST_FILE_SIZE."</b> ", "image" => "modules/".$module_name."/images/".$graph_image.""));
$result = array_merge((array)$services, (array)$end);
ksort($result);

// DISPLAY THE SERVICES ARRAY (BAR GRAPH)
foreach(array_keys($result) as $service){
	$name = $result[$service]["name"];
	$image = $result[$service]["image"];
	$Percent_Scale = percent($service, $max_in_array);
	$Total_Width = ($bar_width / 100) * $Percent_Scale;

	$cpgtpl->assign_block_vars('bargraph_grid', array(
	'GRID_SERVICE' 			=> $service,
	'GRID_BAR_HEIGHT' 		=> $bar_height,
	'GRID_BAR_WIDTH' 		=> $Total_Width,
	'GRID_IMAGE' 			=> $image,
	'GRID_NAME' 			=> $name,
	'GRID_FILE_SIZE' 		=> $ST_FILE_SIZE,
	));
}

$cpgtpl->set_filenames(array('body' => 'Speed_Test/results.html'));
$cpgtpl->display('body');

if ($popup==0){
CloseTable();
}
if ($popup==1){
echo "</body></html>";
}

?>
