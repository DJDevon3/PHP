<?php
/************************************************************************/
/* SPEED_TEST 2.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// LAST UPDATE: 8/26/2010
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
require_once('header.php');

global $prefix, $db, $module_name;
$result = $db->sql_query("SELECT start_image, popup, pop_width, pop_height, meter_display, geoip, message1, message2 FROM ".$prefix."_speedtest");
list($start_image, $popup, $pop_width, $pop_height, $meter_display, $geoip, $message1, $message2) = $db->sql_fetchrow($result);

// Geolocation scraped from NetIP.de  No call made if Geolocation disabled in admin panel.
// Call made via NetIP() function.
if ($geoip==1){
include('GeoIP.inc');
NetIP();
}

if ($popup==1){
	if ($meter_display==1){
	$initial_meter = "<a href=\"?name=".$module_name."&amp;file=initialmeter\" onclick=\"OpenMeter('?name=".$module_name."&amp;file=initialmeter');return false\"><img src=\"modules/".$module_name."/images/".$start_image."\" border=\"0\" alt=\""._ST_START."\" title=\""._ST_START."\" /></a>\n";
	} else {
	$initial_meter = "<a href=\"?name=".$module_name."&amp;file=meter\" onclick=\"OpenMeter('?name=".$module_name."&amp;file=meter');return false\"><img src=\"modules/".$module_name."/images/".$start_image."\" border=\"0\" alt=\""._ST_START."\" title=\""._ST_START."\" /></a>\n";
	}
} else {
	if ($meter_display==1){
	$initial_meter = "<a href=\"index.php?name=".$module_name."&amp;file=initialmeter\"><img src=\"modules/".$module_name."/images/".$start_image."\" border=\"0\" alt=\""._ST_START."\" title=\""._ST_START."\" /></a>\n";
	} else {
	$initial_meter = "<a href=\"index.php?name=".$module_name."&amp;file=meter\"><img src=\"modules/".$module_name."/images/".$start_image."\" border=\"0\" alt=\""._ST_START."\" title=\""._ST_START."\" /></a>\n";
	}
}

OpenTable();
$cpgtpl->assign_vars(array(
'MODULE_NAME'			=> $module_name,
'ST_START_IMAGE'		=> $start_image,
'ST_POP_WIDTH'			=> $pop_width,
'ST_POP_HEIGHT'			=> $pop_height,
'ST_METER_DISPLAY'		=> $initial_meter,
'ST_GEO_DOMAIN'			=> $GEO_DOMAIN,
'ST_GEO_COUNTRY'		=> $GEO_COUNTRY,
'ST_GEO_STATE'			=> $GEO_STATE,
'ST_GEO_CITY'			=> $GEO_CITY,
'ST_MESSAGE_1'			=> $message1,
'ST_MESSAGE_2'			=> $message2
));
$cpgtpl->set_filenames(array('body' => 'Speed_Test/index.html'));
$cpgtpl->display('body');
CloseTable();



?>