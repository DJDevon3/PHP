<?php
/************************************************************************/
/* SPEED_TEST 2.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// LAST UPDATE: 8/26/2010
// ----------------------------------------------------------------------
if (!defined('ADMIN_MOD_INSTALL')) { exit; }

class Speed_Test {
	var $description;
	var $radmin;
	var $modname;
	var $version;
	var $author;
	var $website;
	var $dbtables;
// class constructor
	function Speed_Test() {
		$this->radmin = true;
		$this->version = '2.0';
		$this->modname = 'Speed_Test';
		$this->description = 'Bandwidth Speed Test 2.0';
		$this->author = 'DJDevon3';
		$this->website = 'TreasureCoastDesigns.com';
		$this->dbtables = array('speedtest', 'speedtest_results');
	}

// module installer
	function install() {
		global $installer;
		$installer->add_query('CREATE', 'speedtest', "
			start_image		varchar(50) NOT NULL default '',
			progress_image	varchar(50) NOT NULL default '',
			graph_image		varchar(50) NOT NULL default '',
			popup			int(1) NOT NULL default '1',
			bar_height		int(4) NOT NULL default '15',
			bar_width		int(4) NOT NULL default '600',
			pop_width		int(4) NOT NULL default '0',
			pop_height		int(4) NOT NULL default '0',
			meter_display	int(1) NOT NULL default '0',
			stlog			int(1) NOT NULL default '0',
			geoip			int(1) NOT NULL default '0',
			flood_control	int(3) NOT NULL default '3',
			payload_size	int(7) NOT NULL default '512',
			message1		TEXT NOT NULL default '',
			message2		TEXT NOT NULL default '' ", 'speedtest');

		$installer->add_query('CREATE', 'speedtest_results', "
			test_num		int(10) NOT NULL auto_increment,
			speed			varchar(10) NOT NULL default '',
			date			varchar(10) NOT NULL default '',
			ip				varchar(50) NOT NULL default '',
			name			varchar(50) NOT NULL default '',
			PRIMARY KEY (test_num)", 'speedtest_results');

			$installer->add_query('INSERT', 'speedtest', "'English_Start.png', 'ProgressBar.gif', 'YOU.gif', '1', '15', '600', '800', '630', '1', '1', '1', '3', '512', 'Welcome to our internet connectivity speed test.<br />Speed Test will check the bandwidth of your Internet connection and compare it against DSL, cable modem, and other broadband connections.', '<b>What is Speed Test?</b><br />When the test begins our server will send you a 4MB file. The amount of time it takes to receive the file is calculated. At this time we do not measure upload speed.<br /><br /><b>Why use Speed Test?</b><br />Users perform this test to see what the actual throughput is from their computer to this website.  It can be a good troubleshooting tool for connectivity issues to websites.<br /><br /><b>What can affect Speed Test results?</b><br /><ul><li>Distance between you and the physical location of our server.</li><li>Performing other downloads at the same time that this test is executed.</li><li>Using programs which might overtax your CPU while the test is being conducted.</li><li>Using programs which use your bandwidth while this test is being conducted.</li><li>Low signal strength from or to your ISP.  This can include physical defects on the line from the pole to your house, wiring inside your house, or poor quality cables.</li><li>Signal loss is primarily caused by stray electromagnetic energy seeping from wiring, poor circuits, and/or poor connection of cable splitters or phone adapters. This could cause packet collision and error correction to take place thereby limiting the throughput to your computer.</li><li>If our web server is overloaded from too many visitors or simultaneous downloads of large files.</li></ul><b>U.S. and Canada Dial-up users:</b><br /> Please note, 56K modems are limited to 53K due to government regulations.'");

	return true;
    }

// module uninstaller
	function uninstall() {
		global $installer;
		$installer->add_query('DROP', 'speedtest');	
		$installer->add_query('DROP', 'speedtest_results');	
		return true;
	}
}
?>