<?php
/************************************************************************/
/* SPEED_TEST 2.0 FOR DRAGONFLYCMS                             */
/************************************************************************/
// Dragonfly port and modifications by: 
// DJDevon3 - http://www.TreasureCoastDesigns.com 
//
// Originally created for PHPNUKE and CPGNUKE by:
// Madis, DJMaze, Maku, VinDSL
// ----------------------------------------------------------------------
// MODIFICATION 
// Owners may alter or modify this add-on at their own risk,
// but only for their own use. Although users may modify the code for their use,
// modified code may not be resold or distributed, without express written consent.
//
// DISPLAY OF COPYRIGHT NOTICES REQUIRED
// All copyright notices used within the script that the script generate,
// MUST remain intact, including any images, trademarks, logos. Furthermore, these notices must remain visible.
// This license does not imply license to resell or
// redistribute any of these items singularly or wholely without permission.
//
// LAST UPDATE: 8/26/2010
// ----------------------------------------------------------------------
if (!defined('CPG_NUKE')) { exit; }
get_lang('speed_test');
$pagetitle .= _SPEED_TEST;
require_once('services.php');
global $prefix, $db, $module_name, $Default_Theme;
$result = $db->sql_query("SELECT progress_image, payload_size FROM ".$prefix."_speedtest");
list($progress_image, $payload_size) = $db->sql_fetchrow($result);
?>

<html>
    <head>
        <title><?php echo $isp; ?> <? echo ""._ST_WINDOWTITLEMETER."" ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Expires" content="Fri, Jun 12 1981 08:20:00 GMT" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Cache-Control" content="no-cache" />
<link rel="stylesheet" href="themes/<?php echo $Default_Theme; ?>/style/style.css">
    </head>
<body>
	<?php         
		echo "<table border='0' cellpadding='0' cellspacing='0' align='center'><tr valign='middle'>";
		echo "<td height='450' align='center' class='title'>"._ST_METERNOTE1."";
		echo "<br /><br />";
		echo ""._ST_METERNOTE2."";
		echo "<br /><br />";
		echo "<img src='modules/".$module_name."/images/".$progress_image."' border='0' alt='' />";
		echo "</td></tr></table>";
	?>

<script language="javascript" type="text/javascript">
<!--
    time      = new Date();
    starttime = time.getTime();
// -->
</script>

<?php

    $data_file = "modules/".$module_name."/payload.bin";
    $fd = fopen ($data_file, "rb");
    if (isset($_GET['kbps'])) {
        $test_kbytes = ($_GET['kbps'] / 8) * 10;
        if ($test_kbytes > 3000) {
            $test_kbytes = 3000;
        }
    } else {
        $test_kbytes = $payload_size;
    }

    $contents = fread ($fd, $test_kbytes * 1024);

    echo "<!-- $contents -->";
    fclose ($fd);

?>

<script language="javascript" type="text/javascript">
<!--
    time         = new Date();
    endtime      = time.getTime();
    if (endtime == starttime)
        {downloadtime = 0
        }
    else
    {downloadtime = (endtime - starttime)/1000;
    }

    kbytes_of_data = <?php echo $test_kbytes; ?>;
    linespeed      = kbytes_of_data/downloadtime;
    kbps           = (Math.round((linespeed*8)*10*1.024))/10;

    <?php
            $nexturl = "?name=".$module_name."&file=results&kbps=' + kbps + '&downloadtime=' + downloadtime + '&KB=' + kbytes_of_data + '&recorded=1";
    ?>

    nextpage='<?php echo $nexturl; ?>';
    document.location.href=nextpage
// -->
</script>
</body>
</html>
